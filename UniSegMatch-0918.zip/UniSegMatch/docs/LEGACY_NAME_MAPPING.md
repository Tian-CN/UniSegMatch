# Legacy filename mapping

The original workspace retained multiple generations of the same experiment. The public repository intentionally exposes only the final main implementation plus the separately executed controlled ablations.

| Original workspace | Clean release |
|---|---|
| `train_US_XIONG_SWIN_MATCH_train1_samseg_npy_ssl_v5.py` | `python train.py --dataset efast ...` |
| `train_ISIC2017_SWIN_MATCH_train1_samseg_npy_ssl_v5.py` | `python train.py --dataset isic2017 ...` |
| `engine_match_samseg_isic2017_v5.py` | `engine.py` |
| `config_setting_US_XIONG_match_samseg_npy_v5.py` and final eFAST config | `configs/base.py` + `configs/efast.py` |
| `config_setting_ISIC2017_match_samseg_npy_v5.py` | `configs/base.py` + `configs/isic2017.py` |
| `dataset_us_xiong_npy_match_samseg_v5.py` | `datasets/efast.py` |
| `dataset_isic2017_npy_match_samseg.py` | `datasets/isic2017.py` |
| `models/vmunet/swinvmunet_match_v2.py` | `models/vmunet/unisegmatch.py` |
| `models/vmunet/swinvmamba_match_v2.py` | `models/vmunet/fp_backbone.py` |
| `models/vmunet/swinvmamba_match.py` | `models/vmunet/backbone.py` |
| `ablations/engine_ablation.py` | `ablations/engine.py` |
| `ablations/datasets/dataset_ablation.py` | `ablations/dataset.py` |
| `ablations/run_ablation.py` | `ablations/run_ablation.py` (cleaned paths/CLI) |

Historical `v1`-`v4` files are excluded because the final training entry points supersede them. The earlier `ePG` / `eUni` / `eSSM` scripts are also not merged into the clean runner: inspection shows that they combine older loss engines with older model variants, so treating them as simple flags would silently change those experiments. They are development-generation component ablations rather than the final main implementation. The later, self-contained controlled ablation workspace is retained under `ablations/`.

The old internal name `US_XIONG` is replaced by the public dataset name `eFAST`. The skin-lesion dataset is consistently named `ISIC 2017` / `isic2017` (not `ICIS`).

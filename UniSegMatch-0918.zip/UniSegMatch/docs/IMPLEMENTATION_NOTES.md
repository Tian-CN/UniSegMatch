# Implementation and reproducibility notes

This repository was cleaned from a development workspace containing multiple historical training engines, dataset loaders, configuration copies, and component-ablation branches. The release policy is:

1. expose one main entry point (`train.py`);
2. retain the final executed `v5` training mathematics;
3. keep the controlled ablation protocol separate when it genuinely differed from main training;
4. remove only duplication, obsolete entry points, machine-specific paths, unused arguments, and non-semantic artifacts;
5. document behavior that could otherwise be mistaken for a cleanup bug.

## Main training behavior intentionally preserved

### EMA global-step accumulation

The final main engine accumulated the loop-local index with:

```python
step += i
```

rather than incrementing by one. The EMA warm-up function consumes this `step`, so replacing it with `step += 1` would change the executed optimization trajectory. The clean release therefore preserves `step += i` in `engine.py` and comments it explicitly.

The controlled ablation code is different: it used `step += 1`, and that behavior is preserved in `ablations/engine.py`.

### Strong-view augmentation

The final main eFAST and ISIC 2017 loaders generate strong views with independent horizontal/vertical flips plus brightness, contrast, and color perturbations. Those spatial flips are not separately propagated to the teacher pseudo-label tensors. This is preserved because it was part of the final executed loader.

The later controlled eFAST ablation workspace intentionally used **photometric-only** strong augmentation; it is kept in `ablations/dataset.py`.

### ISIC 2017 target/evaluation stream

The final ISIC 2017 loader uses `data_test.npy` both as the unlabeled target image stream and as the evaluation image list paired with `mask_test.npy`. See `DATA_LAYOUT.md`. This release does not reinterpret that protocol.

## Cleanup changes that do not alter normal training mathematics

- merged the final eFAST and ISIC launch scripts into `train.py`; the original final eFAST launcher targeted the one-labeled-subject layout, while the clean CLI can also point the same engine at a compatible `train20` layout;
- renamed the public dataset identifiers to `efast` and `isic2017`;
- merged the final v5 evaluation functions into `engine.py` instead of importing an older engine module;
- changed path handling so legacy absolute paths can be resolved portably;
- added explicit file/manifest validation and clearer errors;
- made binary confusion-matrix evaluation robust by fixing the label set to `[0, 1]`;
- removed historical no-op `pass` statements produced by an earlier source-stripping step;
- removed unused legacy function parameters and duplicate modules;
- delayed the heavy VMamba/Mamba import until training starts, so `--help` and data validation can run without the full GPU stack;
- reduced the transformation helper module to the CutMix function actually used by the released loaders.

## Controlled ablation protocol

The controlled eFAST runner preserves its own experiment choices: no EMA teacher, photometric-only strong augmentation, `step += 1`, foreground-IoU checkpoint selection, and the seven variants exposed by the original runner. It should not be silently substituted for the main full-method training loop.

Earlier files named `ePG`, `eUni`, and `eSSM` were inspected separately. They are not mere duplicate filenames: some alter the loss composition and `eSSM`-related runs switch to earlier VM-UNet/VMamba model variants. Because those scripts belong to an earlier experiment generation, they were not folded into the final clean runner as flags; doing so would imply equivalence that the source does not support.

## Validation status of this cleaned release

The release is subjected to repository-wide Python syntax compilation, CLI smoke checks, legacy-name/path scans, and local-import checks before packaging. A new numerical training reproduction is **not** claimed by those checks; numerical reproduction requires the original data, cached pseudo-labels, VMamba weights, CUDA, and a compatible `mamba-ssm` environment.

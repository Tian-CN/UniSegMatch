# Data layout

UniSegMatch uses small `.npy` object arrays as manifests. Each entry is a path to an image or mask; image data are not stored in the repository.

The loader accepts absolute paths, repository-relative paths, split-relative paths, and legacy paths containing a `/data/` suffix. For a public release, repository-relative or portable absolute paths are preferable.

## eFAST

Default directory convention:

```text
data_splits/
└── efast/
    ├── train1/
    │   ├── S0/
    │   ├── S1/
    │   └── ... S24/
    └── train20/
        ├── S0/
        ├── S1/
        └── ... S24/
```

Each `S*` directory must contain:

| Manifest | Meaning in the released code |
|---|---|
| `data_train.npy` | labeled training images |
| `mask_train.npy` | ground-truth masks for `data_train.npy` |
| `data_train2.npy` | image stream used for cached dual pseudo-label supervision |
| `mask_train2.npy` | cached **SAM** pseudo masks for `data_train2.npy` |
| `mask_train3.npy` | cached **SegGPT** pseudo masks for `data_train2.npy` |
| `data_test.npy` | unlabeled consistency-learning image stream |
| `mask_test.npy` | masks retained with that stream; not read by the unlabeled `__getitem__` path |
| `data_val.npy` | validation/evaluation images |
| `mask_val.npy` | validation/evaluation ground-truth masks |

Within each row group, array lengths must agree. Different training streams are shuffled independently and are consumed together with Python `zip`; the effective epoch length is therefore the shortest loader.

## ISIC 2017

Default directory convention:

```text
data_splits/
└── isic2017/
    ├── data_train.npy
    ├── mask_train.npy
    ├── data_test.npy
    ├── mask_test.npy
    ├── mask2_test.npy
    └── mask3_test.npy
```

| Manifest | Meaning in the released code |
|---|---|
| `data_train.npy` | labeled training images |
| `mask_train.npy` | labeled training ground truth |
| `data_test.npy` | target image list used by both unlabeled consistency learning and evaluation |
| `mask_test.npy` | evaluation ground truth for `data_test.npy` |
| `mask2_test.npy` | cached SAM pseudo masks for `data_test.npy` |
| `mask3_test.npy` | cached SegGPT pseudo masks for `data_test.npy` |

**Protocol note.** The final submitted implementation uses the same `data_test.npy` image list as an unlabeled target stream during training and as the image list paired with `mask_test.npy` during evaluation. This behavior has been preserved for exact code-level reproducibility rather than silently converted to a different split protocol.

## Validate manifests

Run this before training:

```bash
python tools/validate_split.py --dataset efast --data-dir data_splits/efast/train1/S0 --check-files
python tools/validate_split.py --dataset isic2017 --data-dir data_splits/isic2017 --check-files
```

Without `--check-files`, the tool checks only required manifest presence and aligned lengths. With it, every stored path is resolved and checked on disk.

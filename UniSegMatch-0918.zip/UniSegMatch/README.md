# UniSegMatch

Clean code release for the **UniSegMatch** medical-image segmentation experiments.
The repository contains the final training/evaluation implementation for the **eFAST** and **ISIC 2017** datasets, together with the controlled eFAST ablation runner used to isolate pseudo-label and gating components.

This release is reorganized from the experiment workspace: historical `v1`-`v4`, duplicated files, machine-specific paths, and development-only entry points have been removed. The final submitted training behavior is preserved unless a change is explicitly listed in [`docs/IMPLEMENTATION_NOTES.md`](docs/IMPLEMENTATION_NOTES.md).

## Repository layout

```text
UniSegMatch/
├── train.py                    # single public training/evaluation entry point
├── engine.py                   # final main training objective + evaluation
├── losses.py
├── utils.py
├── configs/
│   ├── base.py
│   ├── efast.py
│   └── isic2017.py
├── datasets/
│   ├── common.py               # portable NPY-manifest path resolution
│   ├── efast.py
│   ├── isic2017.py
│   └── transforms.py
├── models/vmunet/              # UniSegMatch / VM-UNet model implementation
├── ablations/
│   ├── run_ablation.py         # controlled eFAST ablation runner
│   ├── engine.py
│   └── dataset.py
├── tools/validate_split.py     # pre-run data-manifest checker
├── docs/
├── requirements.txt
├── LICENSE
└── NOTICE
```

## Installation

Linux/WSL with an NVIDIA GPU is recommended. Install a CUDA-compatible PyTorch build for your machine first, then install the remaining dependencies:

```bash
pip install -r requirements.txt
```

The backbone requires a compatible `mamba-ssm` selective-scan implementation. `thop` is optional and is used only for FLOP reporting.

## Pretrained backbone

Place the VMamba checkpoint at

```text
pre_trained_weights/vmamba_small_e238_ema.pth
```

or pass another location with `--pretrained`.

## Data preparation

This source release does **not** redistribute eFAST/ISIC images, annotations, cached SAM/SegGPT pseudo-labels, or pretrained weights. Training consumes NPY manifests containing paths to those files.

See [`docs/DATA_LAYOUT.md`](docs/DATA_LAYOUT.md) for the exact filenames and stream semantics. Before launching a GPU run, validate a split directory:

```bash
python tools/validate_split.py --dataset efast --data-dir data_splits/efast/train1/S0 --check-files
python tools/validate_split.py --dataset isic2017 --data-dir data_splits/isic2017 --check-files
```

## Training and evaluation

### eFAST

One-labeled-subject setting, fold 0:

```bash
python train.py --dataset efast --regime 1 --fold 0
```

Twenty-labeled-subject setting, fold 0 (the clean CLI applies the same final engine to a compatible `train20` split layout):

```bash
python train.py --dataset efast --regime 20 --fold 0
```

The source package contained a dedicated final launcher for the one-labeled-subject setting; `--regime 20` is a path/layout convenience in this cleaned CLI rather than a claim that a separate final-version train20 launcher existed in the submitted workspace.

To use a split directory outside the default layout:

```bash
python train.py \
  --dataset efast \
  --data-dir /path/to/split \
  --pretrained /path/to/vmamba_small_e238_ema.pth \
  --output-dir /path/to/output
```

### ISIC 2017

```bash
python train.py --dataset isic2017 --data-dir /path/to/isic2017_split
```

The run directory stores logs, TensorBoard summaries, `latest.pth`, and best checkpoints. At the end of training, the best-mIoU checkpoint is evaluated with the same evaluation loader used by the released experiment code.

## Controlled ablations

The ablation runner currently targets eFAST:

```bash
python ablations/run_ablation.py \
  --regimes 1 \
  --folds 0 \
  --variants seggpt_only sam_only no_gating agreement_only boundary_only no_confidence \
  --epochs 10
```

Available variants are `full`, `seggpt_only`, `sam_only`, `no_gating`, `agreement_only`, `boundary_only`, and `no_confidence`. The default queue excludes `full`, matching the submitted experiment runner. The ablation implementation intentionally remains separate from the main training protocol; see [`ablations/README.md`](ablations/README.md).

## Reproducibility notes

The repository keeps several details that may look unusual but were present in the final executed training code, including the main-loop EMA step accumulation and the released ISIC 2017 target/evaluation stream. They are documented rather than silently changed. See [`docs/IMPLEMENTATION_NOTES.md`](docs/IMPLEMENTATION_NOTES.md).

For a mapping from the original experiment filenames to this release, see [`docs/LEGACY_NAME_MAPPING.md`](docs/LEGACY_NAME_MAPPING.md).

## Citation

Please cite the accompanying UniSegMatch paper when using this code. The full bibliographic entry can be added here after the paper metadata is finalized.

## License

See [`LICENSE`](LICENSE) and [`NOTICE`](NOTICE).

# Controlled eFAST ablations

This directory contains the controlled component-ablation implementation that was kept separately in the experiment workspace.

Available variants:

- `full`
- `seggpt_only`
- `sam_only`
- `no_gating`
- `agreement_only`
- `boundary_only`
- `no_confidence`

Example:

```bash
python ablations/run_ablation.py \
  --regimes 1 20 \
  --folds 0 \
  --variants seggpt_only sam_only no_gating \
  --epochs 10
```

By default the runner reads eFAST split directories from `data_splits/efast/train{1|20}/S{fold}` and VMamba weights from `pre_trained_weights/vmamba_small_e238_ema.pth`. Both locations can be overridden.

## Important difference from the main training loop

The controlled ablation protocol is not just a renamed copy of the final main runner. It intentionally preserves the later ablation workspace: **no EMA teacher**, **photometric-only** strong augmentation, and `step += 1` per optimizer update. The main method keeps its final v5 behavior in `engine.py` and `datasets/efast.py`.

The runner records per-epoch JSON, best/final metrics, resumable checkpoints, a source-code hash manifest, and aggregate CSV/JSON summaries across folds.

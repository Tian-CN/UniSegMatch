"""Dataset variant used by the controlled eFAST ablation experiments."""

import random
from PIL import Image, ImageEnhance

from datasets.efast import EFASTDataset


class EFASTAblationDataset(EFASTDataset):
    """eFAST loader with the photometric-only strong augmentation used in ablations."""

    def _strong_aug(self, img: Image.Image) -> Image.Image:
        if random.random() < 0.8:
            img = ImageEnhance.Brightness(img).enhance(random.uniform(0.7, 1.3))
        if random.random() < 0.8:
            img = ImageEnhance.Contrast(img).enhance(random.uniform(0.7, 1.3))
        if random.random() < 0.8:
            img = ImageEnhance.Color(img).enhance(random.uniform(0.7, 1.3))
        return img

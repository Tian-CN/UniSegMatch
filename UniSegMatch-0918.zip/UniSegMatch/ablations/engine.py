"""Controlled UniSegMatch ablation training loop for eFAST.

This module intentionally preserves the separately executed ablation protocol:
no EMA teacher, photometric-only strong augmentation (defined in dataset.py),
and one global-step increment per optimizer update.
"""

import numpy as np
import math
import torch
import torch.nn.functional as F
from tqdm import tqdm


def _masked_ce_loss(logits: torch.Tensor, target: torch.Tensor, keep: torch.Tensor) -> torch.Tensor:
    ce = F.cross_entropy(logits, target, reduction='none')
    if keep.dtype != ce.dtype:
        keep = keep.to(dtype=ce.dtype)
    denom = keep.sum().clamp_min(1.0)
    return (ce * keep).sum() / denom

def _binary_boundary_band(mask01: torch.Tensor, kernel_size: int) -> torch.Tensor:
    k = int(kernel_size)
    if k < 3:
        k = 3
    if k % 2 == 0:
        k += 1

    x = mask01.to(dtype=torch.float32).unsqueeze(1)
    pad = k // 2
    dil = F.max_pool2d(x, kernel_size=k, stride=1, padding=pad)
    ero = 1.0 - F.max_pool2d(1.0 - x, kernel_size=k, stride=1, padding=pad)
    band = (dil - ero).clamp(min=0.0, max=1.0)
    return band.squeeze(1)

def _samseg_weight_scale(epoch: int, config) -> float:
    enable = bool(getattr(config, 'samseg_weight_ramp_enable', False))
    if not enable:
        return 1.0
    warmup = int(getattr(config, 'samseg_weight_warmup_epochs', 0))
    ramp = int(getattr(config, 'samseg_weight_ramp_epochs', 0))
    start = float(getattr(config, 'samseg_weight_start', 0.0))
    end = float(getattr(config, 'samseg_weight_end', 1.0))

    if epoch <= warmup:
        return start
    if ramp <= 0:
        return end
    t = min(max((epoch - warmup) / float(ramp), 0.0), 1.0)
    return start + (end - start) * t

def _adaptive_conf_threshold(conf: torch.Tensor, base_th: float, min_keep_ratio: float) -> float:
    if min_keep_ratio <= 0:
        return float(base_th)
    x = conf.detach().reshape(-1)
    if x.numel() == 0:
        return float(base_th)

    keep_ratio = float((x >= base_th).to(dtype=torch.float32).mean().cpu())
    if keep_ratio >= float(min_keep_ratio):
        return float(base_th)

    n = int(x.numel())

    k = int(max(min(n, math.ceil((1.0 - float(min_keep_ratio)) * n)), 1))

    kth = float(torch.kthvalue(x, k).values.cpu())
    return float(min(base_th, kth))

def _conf_to_soft_weight(conf: torch.Tensor, th_high: float, margin: float) -> torch.Tensor:
    thh = float(th_high)
    thl = float(th_high) - float(margin)
    if thl < 0.0:
        thl = 0.0
    if thl >= thh:
        thl = max(thh - 1e-6, 0.0)
    w = (conf - thl) / (thh - thl)
    return w.clamp(0.0, 1.0)

def _weighted_dice_loss(score: torch.Tensor, target: torch.Tensor, weight: torch.Tensor) -> torch.Tensor:
    smooth = 1e-5
    if score.dim() == 4 and score.size(1) == 2:
        score = torch.softmax(score, dim=1)[:, 1]
    elif score.dim() == 4 and score.size(1) == 1:
        score = torch.sigmoid(score)[:, 0]
    elif score.dim() == 3:
        score = score
    else:
        raise ValueError(f"Unexpected score shape for weighted dice: {tuple(score.shape)}")
    if target.dim() == 4 and target.size(1) == 1:
        target = target[:, 0]
    score = score.float()
    target = target.float()
    w = weight.float()
    intersect = torch.sum(w * score * target)
    y_sum = torch.sum(w * target * target)
    z_sum = torch.sum(w * score * score)
    dice = (2.0 * intersect + smooth) / (z_sum + y_sum + smooth)
    return 1.0 - dice

def _ssl_weight_scale(epoch: int, config) -> float:
    enable = bool(getattr(config, 'ssl_weight_ramp_enable', False))
    if not enable:
        return 1.0
    warmup = int(getattr(config, 'ssl_weight_warmup_epochs', 0))
    ramp = int(getattr(config, 'ssl_weight_ramp_epochs', 0))
    start = float(getattr(config, 'ssl_weight_start', 0.0))
    end = float(getattr(config, 'ssl_weight_end', 1.0))

    if epoch <= warmup:
        return start
    if ramp <= 0:
        return end
    t = min(max((epoch - warmup) / float(ramp), 0.0), 1.0)
    return start + (end - start) * t

def _get_samseg_keep_mask(pred_x2, mask_x2, mask_x3, config):

    variant = config.variant
    keep = torch.ones_like(mask_x2, dtype=torch.float32)
    if variant in ('full', 'agreement_only', 'no_confidence'):
        keep = keep * (mask_x2 == mask_x3).float()
    if variant in ('full', 'boundary_only', 'no_confidence'):
        keep = keep * _binary_boundary_band(mask_x3.float(), config.samseg_boundary_ks)
    return keep

def _get_samseg_target_and_keep(mask_x2, mask_x3, keep, config):

    if config.variant == 'seggpt_only':
        return mask_x3, mask_x3, keep, keep
    if config.variant == 'sam_only':
        return mask_x2, mask_x2, keep, keep
    return mask_x2, mask_x3, keep, keep

def _get_conf_threshold(epoch: int, config) -> float:

    if not hasattr(config, 'conf_threshold'):
        return 0.95

    th = float(getattr(config, 'conf_threshold'))
    schedule = bool(getattr(config, 'conf_threshold_schedule', False))
    if not schedule:
        return th

    th_start = float(getattr(config, 'conf_threshold_start', th))
    th_end = float(getattr(config, 'conf_threshold_end', th))
    warmup = int(getattr(config, 'conf_threshold_warmup_epochs', 0))
    ramp_epochs = getattr(config, 'conf_threshold_ramp_epochs', None)

    if epoch <= warmup:
        return th_start

    if ramp_epochs is None:
        total = max(int(getattr(config, 'epochs', warmup + 1)) - warmup, 1)
    else:
        total = max(int(ramp_epochs), 1)

    t = min(max((epoch - warmup) / total, 0.0), 1.0)
    return th_start + (th_end - th_start) * t

def train_one_epoch(train_loader_l,
                    train_loader_l_samseg,
                    train_loader_u,
                    train_loader_u_mix,
                    previous_best,
                    criterion_ce,
                    criterion_dice,
                    model,
                    optimizer,
                    scheduler,
                    epoch,
                    step,
                    logger,
                    config,
                    writer):
    logger.info('===========> Epoch: {:}, LR: {:.5f}, Previous best: {:.2f}'.format(
        epoch, optimizer.param_groups[0]['lr'], previous_best))


    model.train()

    loss_list = []
    loss_x_list = []
    loss_x2_list = []
    loss_x3_list = []
    loss_u_s1_list = []
    loss_u_s2_list = []
    loss_u_w_fp_list = []

    conf_th_list = []
    samseg_keep_list = []
    ssl_keep_list = []
    ssl_w_mean_list = []
    ssl_th_eff_list = []
    ssl_adapted_list = []
    ssl_clamped_list = []
    ssl_agree_list = []
    ssl_agree_fg_list = []

    conf_th = _get_conf_threshold(epoch, config)
    retained_pixels = total_pixels = retained_images = total_images = 0

    loader = zip(train_loader_l, train_loader_l_samseg, train_loader_u, train_loader_u_mix)
    for i, ((img_x, mask_x),
            (img_x2, mask_x2, mask_x3),
            (img_u_w, img_u_s1, img_u_s2, cutmix_box1, cutmix_box2),
            (img_u_w_mix, img_u_s1_mix, img_u_s2_mix, _, _)) in tqdm(enumerate(loader),
                                                                     total=min(len(train_loader_l),
                                                                               len(train_loader_l_samseg),
                                                                               len(train_loader_u),
                                                                               len(train_loader_u_mix)),
                                                                     mininterval=20.0,
                                                                     maxinterval=360.0,
                                                                     miniters=20):
        if getattr(config, 'max_steps', 0) and i >= config.max_steps:
            break
        step += 1
        img_x, mask_x = img_x.cuda(non_blocking=True), mask_x.cuda(non_blocking=True)
        img_x2, mask_x2, mask_x3 = img_x2.cuda(non_blocking=True), mask_x2.cuda(non_blocking=True), mask_x3.cuda(non_blocking=True)
        img_u_w = img_u_w.cuda(non_blocking=True)
        img_u_s1, img_u_s2 = img_u_s1.cuda(non_blocking=True), img_u_s2.cuda(non_blocking=True)
        cutmix_box1, cutmix_box2 = cutmix_box1.cuda(non_blocking=True), cutmix_box2.cuda(non_blocking=True)
        img_u_w_mix = img_u_w_mix.cuda(non_blocking=True)
        img_u_s1_mix, img_u_s2_mix = img_u_s1_mix.cuda(non_blocking=True), img_u_s2_mix.cuda(non_blocking=True)

        with torch.no_grad():
            model.eval()
            pred_u_w_mix = model(img_u_w_mix).detach()
            conf_u_w_mix = pred_u_w_mix.softmax(dim=1).max(dim=1)[0]
            mask_u_w_mix = pred_u_w_mix.argmax(dim=1)

        B, C, H, W = img_u_s1.shape

        if cutmix_box1.dim() == 1 and cutmix_box1.shape[0] == 4:
            x1, y1, x2, y2 = cutmix_box1[0].item(), cutmix_box1[1].item(), cutmix_box1[2].item(), cutmix_box1[3].item()
            cutmix_box1 = torch.zeros((B, 1, H, W), device=img_u_s1.device, dtype=torch.float32)
            cutmix_box2 = torch.zeros((B, 1, H, W), device=img_u_s1.device, dtype=torch.float32)
            x1, y1 = max(0, int(x1 * W)), max(0, int(y1 * H))
            x2, y2 = min(W, int(x2 * W)), min(H, int(y2 * H))
            cutmix_box1[:, :, y1:y2, x1:x2] = 1.0
            cutmix_box2[:, :, y1:y2, x1:x2] = 1.0

        elif len(cutmix_box1.shape) == 2:
            cutmix_box1 = cutmix_box1.unsqueeze(0).unsqueeze(0).float()
            cutmix_box2 = cutmix_box2.unsqueeze(0).unsqueeze(0).float()
            if cutmix_box1.shape[-2:] != (H, W):
                cutmix_box1 = F.interpolate(cutmix_box1, size=(H, W), mode='nearest')
                cutmix_box2 = F.interpolate(cutmix_box2, size=(H, W), mode='nearest')
            cutmix_box1 = cutmix_box1.expand(B, -1, -1, -1)
            cutmix_box2 = cutmix_box2.expand(B, -1, -1, -1)

        elif len(cutmix_box1.shape) == 3:
            cutmix_box1 = cutmix_box1.unsqueeze(1).float()
            cutmix_box2 = cutmix_box2.unsqueeze(1).float()
            if cutmix_box1.shape[-2:] != (H, W):
                cutmix_box1 = F.interpolate(cutmix_box1, size=(H, W), mode='nearest')
                cutmix_box2 = F.interpolate(cutmix_box2, size=(H, W), mode='nearest')

        img_u_s1 = img_u_s1 * (1 - cutmix_box1) + img_u_s1_mix * cutmix_box1
        img_u_s2 = img_u_s2 * (1 - cutmix_box2) + img_u_s2_mix * cutmix_box2

        model.train()
        optimizer.zero_grad()

        num_lb, num_ulb = img_x.shape[0], img_u_w.shape[0]

        preds, preds_fp = model(torch.cat((img_x, img_u_w)), True)
        pred_x, pred_u_w = preds.split([num_lb, num_ulb])
        pred_u_w_fp = preds_fp[num_lb:]

        pred_x2 = model(img_x2)

        if img_u_s1.shape[1] != img_u_s2.shape[1]:
            if img_u_s1.shape[1] == 4 and img_u_s2.shape[1] == 3:
                img_u_s1 = img_u_s1[:, :3, :, :]
            elif img_u_s1.shape[1] == 3 and img_u_s2.shape[1] == 4:
                img_u_s2 = img_u_s2[:, :3, :, :]

        preds = model(torch.cat((img_u_s1, img_u_s2)))
        pred_u_s1, pred_u_s2 = preds.chunk(2)

        pred_u_w = pred_u_w.detach()
        conf_u_w = pred_u_w.softmax(dim=1).max(dim=1)[0]
        mask_u_w = pred_u_w.argmax(dim=1)

        mask_u_w_cutmixed1, conf_u_w_cutmixed1 = mask_u_w.clone(), conf_u_w.clone()
        mask_u_w_cutmixed2, conf_u_w_cutmixed2 = mask_u_w.clone(), conf_u_w.clone()

        cutmix_box1_mask = cutmix_box1.squeeze(1) == 1
        cutmix_box2_mask = cutmix_box2.squeeze(1) == 1

        mask_u_w_cutmixed1[cutmix_box1_mask] = mask_u_w_mix[cutmix_box1_mask]
        conf_u_w_cutmixed1[cutmix_box1_mask] = conf_u_w_mix[cutmix_box1_mask]

        mask_u_w_cutmixed2[cutmix_box2_mask] = mask_u_w_mix[cutmix_box2_mask]
        conf_u_w_cutmixed2[cutmix_box2_mask] = conf_u_w_mix[cutmix_box2_mask]

        use_dice = bool(getattr(config, 'loss_use_dice', True))
        w_x = float(getattr(config, 'loss_weight_x', 1.0))
        w_x2 = float(getattr(config, 'loss_weight_x2', 0.5))
        w_x3 = float(getattr(config, 'loss_weight_x3', 0.5))
        samseg_scale = _samseg_weight_scale(epoch, config)
        w_x2 = w_x2 * samseg_scale
        w_x3 = w_x3 * samseg_scale
        w_u_s1 = float(getattr(config, 'loss_weight_u_s1', 0.5))
        w_u_s2 = float(getattr(config, 'loss_weight_u_s2', 0.5))
        w_u_fp = float(getattr(config, 'loss_weight_u_fp', 0.5))
        ssl_scale = _ssl_weight_scale(epoch, config)
        w_u_s1 = w_u_s1 * ssl_scale
        w_u_s2 = w_u_s2 * ssl_scale
        w_u_fp = w_u_fp * ssl_scale
        normalize = bool(getattr(config, 'loss_normalize_by_weight_sum', True))

        samseg_min_keep_ratio = float(getattr(config, 'samseg_min_keep_ratio', 0.0))

        if use_dice:
            loss_x = (criterion_ce(pred_x, mask_x) + criterion_dice(pred_x.softmax(dim=1), mask_x.unsqueeze(1).float())) / 2.0
            keep_samseg = _get_samseg_keep_mask(pred_x2, mask_x2, mask_x3, config)
            keep_ratio = float(keep_samseg.mean().detach().cpu())
            if keep_ratio < samseg_min_keep_ratio:
                keep_samseg = torch.zeros_like(keep_samseg)

            tgt_x2, tgt_x3, keep_x2, keep_x3 = _get_samseg_target_and_keep(mask_x2, mask_x3, keep_samseg, config)

            loss_x2_ce = _masked_ce_loss(pred_x2, tgt_x2, keep_x2)
            loss_x2_dice = criterion_dice(
                pred_x2.softmax(dim=1),
                tgt_x2.unsqueeze(1).float(),
                ignore=(keep_x2 <= 0).float(),
            )
            loss_x2 = (loss_x2_ce + loss_x2_dice) / 2.0

            loss_x3_ce = _masked_ce_loss(pred_x2, tgt_x3, keep_x3)
            loss_x3_dice = criterion_dice(
                pred_x2.softmax(dim=1),
                tgt_x3.unsqueeze(1).float(),
                ignore=(keep_x3 <= 0).float(),
            )
            loss_x3 = (loss_x3_ce + loss_x3_dice) / 2.0
        else:
            loss_x = criterion_ce(pred_x, mask_x)
            keep_samseg = _get_samseg_keep_mask(pred_x2, mask_x2, mask_x3, config)
            keep_ratio = float(keep_samseg.mean().detach().cpu())
            if keep_ratio < samseg_min_keep_ratio:
                keep_samseg = torch.zeros_like(keep_samseg)
            tgt_x2, tgt_x3, keep_x2, keep_x3 = _get_samseg_target_and_keep(mask_x2, mask_x3, keep_samseg, config)
            loss_x2 = _masked_ce_loss(pred_x2, tgt_x2, keep_x2)
            loss_x3 = _masked_ce_loss(pred_x2, tgt_x3, keep_x3)

        retained_pixels += int((keep_x2 > 0).sum().item())
        total_pixels += keep_x2.numel()
        retained_images += int((keep_x2.flatten(1).sum(1) > 0).sum().item())
        total_images += keep_x2.shape[0]

        ssl_min_keep_ratio = float(getattr(config, 'ssl_min_keep_ratio', 0.0))
        ssl_weighting_mode = str(getattr(config, 'ssl_weighting_mode', 'hard')).lower()
        ssl_soft_margin = float(getattr(config, 'ssl_soft_margin', 0.10))

        ssl_adapt_max_drop = float(getattr(config, 'ssl_adapt_max_drop', 0.0))

        ssl_conf_th_s1 = _adaptive_conf_threshold(conf_u_w_cutmixed1, conf_th, ssl_min_keep_ratio)
        ssl_conf_th_s2 = _adaptive_conf_threshold(conf_u_w_cutmixed2, conf_th, ssl_min_keep_ratio)
        ssl_conf_th_fp = _adaptive_conf_threshold(conf_u_w, conf_th, ssl_min_keep_ratio)

        ssl_clamped = 0.0
        if ssl_adapt_max_drop > 0:
            min_th = max(conf_th - ssl_adapt_max_drop, 0.0)
            before_s1, before_s2, before_fp = ssl_conf_th_s1, ssl_conf_th_s2, ssl_conf_th_fp
            ssl_conf_th_s1 = max(ssl_conf_th_s1, min_th)
            ssl_conf_th_s2 = max(ssl_conf_th_s2, min_th)
            ssl_conf_th_fp = max(ssl_conf_th_fp, min_th)
            ssl_clamped = float(
                (ssl_conf_th_s1 != before_s1) or (ssl_conf_th_s2 != before_s2) or (ssl_conf_th_fp != before_fp)
            )

        ssl_conf_th_eff = (ssl_conf_th_s1 + ssl_conf_th_s2 + ssl_conf_th_fp) / 3.0
        ssl_adapted = float(
            (ssl_conf_th_s1 < conf_th) or (ssl_conf_th_s2 < conf_th) or (ssl_conf_th_fp < conf_th)
        )

        ssl_agree_enable = bool(getattr(config, 'ssl_agree_enable', False))
        ssl_agree_fp_enable = bool(getattr(config, 'ssl_agree_fp_enable', False))
        ssl_agree_fg_only = bool(getattr(config, 'ssl_agree_foreground_only', False))
        ssl_agree_min_w = float(getattr(config, 'ssl_agree_min_weight', 0.0))
        if ssl_agree_enable:
            with torch.no_grad():
                mask_u_s1 = pred_u_s1.argmax(dim=1)
                mask_u_s2 = pred_u_s2.argmax(dim=1)

                eq_s1 = (mask_u_s1 == mask_u_w_cutmixed1)
                eq_s2 = (mask_u_s2 == mask_u_w_cutmixed2)

                if ssl_agree_fg_only:

                    fg1 = (mask_u_w_cutmixed1 > 0) | (mask_u_s1 > 0)
                    fg2 = (mask_u_w_cutmixed2 > 0) | (mask_u_s2 > 0)

                    agree_s1 = (~fg1) | eq_s1
                    agree_s2 = (~fg2) | eq_s2

                    if fg1.any():
                        agree_ratio_s1_fg = float(eq_s1[fg1].to(dtype=torch.float32).mean().detach().cpu())
                    else:
                        agree_ratio_s1_fg = 1.0
                    if fg2.any():
                        agree_ratio_s2_fg = float(eq_s2[fg2].to(dtype=torch.float32).mean().detach().cpu())
                    else:
                        agree_ratio_s2_fg = 1.0
                else:
                    agree_s1 = eq_s1
                    agree_s2 = eq_s2
                    agree_ratio_s1_fg = float(eq_s1.to(dtype=torch.float32).mean().detach().cpu())
                    agree_ratio_s2_fg = float(eq_s2.to(dtype=torch.float32).mean().detach().cpu())

                agree_s1 = agree_s1.to(dtype=torch.float32)
                agree_s2 = agree_s2.to(dtype=torch.float32)
                if ssl_agree_min_w > 0.0:
                    agree_s1 = agree_s1 * (1.0 - ssl_agree_min_w) + ssl_agree_min_w
                    agree_s2 = agree_s2 * (1.0 - ssl_agree_min_w) + ssl_agree_min_w
                    if ssl_agree_fg_only:
                        agree_s1 = torch.where(fg1, agree_s1, torch.ones_like(agree_s1))
                        agree_s2 = torch.where(fg2, agree_s2, torch.ones_like(agree_s2))
                agree_ratio_s1 = float(agree_s1.mean().detach().cpu())
                agree_ratio_s2 = float(agree_s2.mean().detach().cpu())
        else:
            agree_s1 = None
            agree_s2 = None
            agree_ratio_s1 = 1.0
            agree_ratio_s2 = 1.0
            agree_ratio_s1_fg = 1.0
            agree_ratio_s2_fg = 1.0
            ssl_agree_min_w = 0.0

        if ssl_weighting_mode == 'soft':
            ssl_w_s1 = _conf_to_soft_weight(conf_u_w_cutmixed1.to(dtype=torch.float32), ssl_conf_th_s1, ssl_soft_margin)
            ssl_w_s2 = _conf_to_soft_weight(conf_u_w_cutmixed2.to(dtype=torch.float32), ssl_conf_th_s2, ssl_soft_margin)
            ssl_w_fp = _conf_to_soft_weight(conf_u_w.to(dtype=torch.float32), ssl_conf_th_fp, ssl_soft_margin)

            if config.variant == 'no_confidence':
                ssl_w_s1 = torch.ones_like(ssl_w_s1)
                ssl_w_s2 = torch.ones_like(ssl_w_s2)
                ssl_w_fp = torch.ones_like(ssl_w_fp)

            if ssl_agree_enable:
                ssl_w_s1 = ssl_w_s1 * agree_s1
                ssl_w_s2 = ssl_w_s2 * agree_s2
                if ssl_agree_fp_enable:
                    with torch.no_grad():
                        agree_fp = (pred_u_w_fp.argmax(dim=1) == mask_u_w).to(dtype=torch.float32)
                    ssl_w_fp = ssl_w_fp * agree_fp

            ssl_keep_s1 = (ssl_w_s1 > 0.0).to(dtype=torch.float32)
            ssl_keep_s2 = (ssl_w_s2 > 0.0).to(dtype=torch.float32)
            ssl_keep_fp = (ssl_w_fp > 0.0).to(dtype=torch.float32)
            ssl_w_mean_s1 = float(ssl_w_s1.mean().detach().cpu())
            ssl_w_mean_s2 = float(ssl_w_s2.mean().detach().cpu())
            ssl_w_mean_fp = float(ssl_w_fp.mean().detach().cpu())
            ssl_w_mean = (ssl_w_mean_s1 + ssl_w_mean_s2 + ssl_w_mean_fp) / 3.0
        else:
            ssl_keep_s1 = (conf_u_w_cutmixed1 >= ssl_conf_th_s1).to(dtype=torch.float32)
            ssl_keep_s2 = (conf_u_w_cutmixed2 >= ssl_conf_th_s2).to(dtype=torch.float32)
            ssl_keep_fp = (conf_u_w >= ssl_conf_th_fp).to(dtype=torch.float32)
            ssl_w_s1 = ssl_keep_s1
            ssl_w_s2 = ssl_keep_s2
            ssl_w_fp = ssl_keep_fp

            if ssl_agree_enable:
                ssl_keep_s1 = ssl_keep_s1 * agree_s1
                ssl_keep_s2 = ssl_keep_s2 * agree_s2
                ssl_w_s1 = ssl_keep_s1
                ssl_w_s2 = ssl_keep_s2
                if ssl_agree_fp_enable:
                    with torch.no_grad():
                        agree_fp = (pred_u_w_fp.argmax(dim=1) == mask_u_w).to(dtype=torch.float32)
                    ssl_keep_fp = ssl_keep_fp * agree_fp
                    ssl_w_fp = ssl_keep_fp
            ssl_w_mean_s1 = float(ssl_w_s1.mean().detach().cpu())
            ssl_w_mean_s2 = float(ssl_w_s2.mean().detach().cpu())
            ssl_w_mean_fp = float(ssl_w_fp.mean().detach().cpu())
            ssl_w_mean = (ssl_w_mean_s1 + ssl_w_mean_s2 + ssl_w_mean_fp) / 3.0

        ssl_valid_ratio_s1 = float(ssl_keep_s1.mean().detach().cpu())
        ssl_valid_ratio_s2 = float(ssl_keep_s2.mean().detach().cpu())
        ssl_valid_ratio_fp = float(ssl_keep_fp.mean().detach().cpu())
        ssl_valid_ratio = (ssl_valid_ratio_s1 + ssl_valid_ratio_s2 + ssl_valid_ratio_fp) / 3.0

        ssl_agree_ratio = (float(agree_ratio_s1) + float(agree_ratio_s2)) / 2.0
        ssl_agree_fg_ratio = (float(agree_ratio_s1_fg) + float(agree_ratio_s2_fg)) / 2.0

        if ssl_weighting_mode == 'soft':
            loss_u_s1 = _weighted_dice_loss(
                pred_u_s1,
                mask_u_w_cutmixed1.unsqueeze(1).float(),
                ssl_w_s1,
            )
            loss_u_s2 = _weighted_dice_loss(
                pred_u_s2,
                mask_u_w_cutmixed2.unsqueeze(1).float(),
                ssl_w_s2,
            )
            loss_u_w_fp = _weighted_dice_loss(
                pred_u_w_fp,
                mask_u_w.unsqueeze(1).float(),
                ssl_w_fp,
            )
        else:
            loss_u_s1 = criterion_dice(
                pred_u_s1,
                mask_u_w_cutmixed1.unsqueeze(1).float(),
                ignore=(1.0 - ssl_keep_s1).float(),
            )

            loss_u_s2 = criterion_dice(
                pred_u_s2,
                mask_u_w_cutmixed2.unsqueeze(1).float(),
                ignore=(1.0 - ssl_keep_s2).float(),
            )

            loss_u_w_fp = criterion_dice(
                pred_u_w_fp,
                mask_u_w.unsqueeze(1).float(),
                ignore=(1.0 - ssl_keep_fp).float(),
            )

        loss = (loss_x * w_x + loss_x2 * w_x2 + loss_x3 * w_x3 + loss_u_s1 * w_u_s1 + loss_u_s2 * w_u_s2 + loss_u_w_fp * w_u_fp)
        if normalize:
            denom = max(w_x + w_x2 + w_x3 + w_u_s1 + w_u_s2 + w_u_fp, 1e-8)
            loss = loss / denom

        if not torch.isfinite(loss):
            raise FloatingPointError('Non-finite loss; refusing to continue')
        loss.backward()
        optimizer.step()

        loss_list.append(loss.item())
        loss_x_list.append(loss_x.item())
        loss_x2_list.append(loss_x2.item())
        loss_x3_list.append(loss_x3.item())
        loss_u_s1_list.append(loss_u_s1.item())
        loss_u_s2_list.append(loss_u_s2.item())
        loss_u_w_fp_list.append(loss_u_w_fp.item())

        now_lr = optimizer.state_dict()['param_groups'][0]['lr']

        writer.add_scalar('loss', loss, global_step=step)
        writer.add_scalar('loss_x', loss_x, global_step=step)
        writer.add_scalar('loss_x2', loss_x2, global_step=step)
        writer.add_scalar('loss_x3', loss_x3, global_step=step)
        writer.add_scalar('loss_u_s1', loss_u_s1, global_step=step)
        writer.add_scalar('loss_u_s2', loss_u_s2, global_step=step)
        writer.add_scalar('loss_u_w_fp', loss_u_w_fp, global_step=step)
        writer.add_scalar('samseg_keep', keep_ratio, global_step=step)
        writer.add_scalar('samseg_weight_scale', samseg_scale, global_step=step)
        writer.add_scalar('ssl_weight_scale', ssl_scale, global_step=step)
        writer.add_scalar('ssl_valid_ratio', ssl_valid_ratio, global_step=step)
        writer.add_scalar('ssl_valid_ratio_s1', ssl_valid_ratio_s1, global_step=step)
        writer.add_scalar('ssl_valid_ratio_s2', ssl_valid_ratio_s2, global_step=step)
        writer.add_scalar('ssl_valid_ratio_fp', ssl_valid_ratio_fp, global_step=step)
        writer.add_scalar('ssl_w_mean', ssl_w_mean, global_step=step)
        writer.add_scalar('ssl_w_mean_s1', ssl_w_mean_s1, global_step=step)
        writer.add_scalar('ssl_w_mean_s2', ssl_w_mean_s2, global_step=step)
        writer.add_scalar('ssl_w_mean_fp', ssl_w_mean_fp, global_step=step)
        writer.add_scalar('ssl_conf_th_eff', ssl_conf_th_eff, global_step=step)
        writer.add_scalar('ssl_conf_th_eff_s1', ssl_conf_th_s1, global_step=step)
        writer.add_scalar('ssl_conf_th_eff_s2', ssl_conf_th_s2, global_step=step)
        writer.add_scalar('ssl_conf_th_eff_fp', ssl_conf_th_fp, global_step=step)
        writer.add_scalar('ssl_adapted', ssl_adapted, global_step=step)
        writer.add_scalar('ssl_clamped', ssl_clamped, global_step=step)
        writer.add_scalar('ssl_agree_ratio', ssl_agree_ratio, global_step=step)
        writer.add_scalar('ssl_agree_ratio_s1', float(agree_ratio_s1), global_step=step)
        writer.add_scalar('ssl_agree_ratio_s2', float(agree_ratio_s2), global_step=step)
        writer.add_scalar('ssl_agree_fg_ratio', ssl_agree_fg_ratio, global_step=step)
        writer.add_scalar('ssl_agree_fg_ratio_s1', float(agree_ratio_s1_fg), global_step=step)
        writer.add_scalar('ssl_agree_fg_ratio_s2', float(agree_ratio_s2_fg), global_step=step)
        writer.add_scalar('ssl_agree_min_weight', float(ssl_agree_min_w), global_step=step)

        if i % config.print_interval == 0:
            log_info = f'train: epoch {epoch}, iter:{i}, loss: {np.mean(loss_list):.4f}, lr: {now_lr}, loss_x:{np.mean(loss_x_list):.4f}, loss_x2:{np.mean(loss_x2_list):.4f}, loss_x3:{np.mean(loss_x3_list):.4f}, s1:{np.mean(loss_u_s1_list):.4f}, s2:{np.mean(loss_u_s2_list):.4f}, fp:{np.mean(loss_u_w_fp_list):.4f}, conf_th:{conf_th:.3f}, samseg_keep:{keep_ratio:.3f}, samseg_scale:{samseg_scale:.3f}, ssl_scale:{ssl_scale:.3f}, ssl_keep:{ssl_valid_ratio:.3f}, ssl_keep_s1:{ssl_valid_ratio_s1:.3f}, ssl_keep_s2:{ssl_valid_ratio_s2:.3f}, ssl_keep_fp:{ssl_valid_ratio_fp:.3f}, ssl_w_mean:{ssl_w_mean:.3f}, ssl_agree:{ssl_agree_ratio:.3f}, ssl_agree_fg:{ssl_agree_fg_ratio:.3f}, ssl_agree_minw:{float(ssl_agree_min_w):.2f}, ssl_th_eff:{ssl_conf_th_eff:.3f}, ssl_th_s1:{ssl_conf_th_s1:.3f}, ssl_th_s2:{ssl_conf_th_s2:.3f}, ssl_th_fp:{ssl_conf_th_fp:.3f}, ssl_adapt:{ssl_adapted:.0f}, ssl_clamp:{ssl_clamped:.0f}, ssl_mode:{ssl_weighting_mode}'
            print(log_info)
            logger.info(log_info)

        conf_th_list.append(float(conf_th))
        samseg_keep_list.append(float(keep_ratio))
        ssl_keep_list.append(float(ssl_valid_ratio))
        ssl_w_mean_list.append(float(ssl_w_mean))
        ssl_th_eff_list.append(float(ssl_conf_th_eff))
        ssl_adapted_list.append(float(ssl_adapted))
        ssl_clamped_list.append(float(ssl_clamped))
        ssl_agree_list.append(float(ssl_agree_ratio))
        ssl_agree_fg_list.append(float(ssl_agree_fg_ratio))

    scheduler.step()

    try:
        model._last_train_stats = {
            'epoch': int(epoch),
            'effective_pl_pixel_keep': retained_pixels / max(total_pixels, 1),
            'effective_pl_image_keep': retained_images / max(total_images, 1),
            'supervised_images_seen': total_images,
            'optimizer_steps': len(loss_list),
            'loss': float(np.mean(loss_list)) if len(loss_list) > 0 else None,
            'loss_x': float(np.mean(loss_x_list)) if len(loss_x_list) > 0 else None,
            'loss_x2': float(np.mean(loss_x2_list)) if len(loss_x2_list) > 0 else None,
            'loss_x3': float(np.mean(loss_x3_list)) if len(loss_x3_list) > 0 else None,
            'loss_u_s1': float(np.mean(loss_u_s1_list)) if len(loss_u_s1_list) > 0 else None,
            'loss_u_s2': float(np.mean(loss_u_s2_list)) if len(loss_u_s2_list) > 0 else None,
            'loss_u_fp': float(np.mean(loss_u_w_fp_list)) if len(loss_u_w_fp_list) > 0 else None,
            'conf_th': float(np.mean(conf_th_list)) if len(conf_th_list) > 0 else None,
            'samseg_keep': float(np.mean(samseg_keep_list)) if len(samseg_keep_list) > 0 else None,
            'ssl_keep': float(np.mean(ssl_keep_list)) if len(ssl_keep_list) > 0 else None,
            'ssl_w_mean': float(np.mean(ssl_w_mean_list)) if len(ssl_w_mean_list) > 0 else None,
            'ssl_th_eff': float(np.mean(ssl_th_eff_list)) if len(ssl_th_eff_list) > 0 else None,
            'ssl_adapt': float(np.mean(ssl_adapted_list)) if len(ssl_adapted_list) > 0 else None,
            'ssl_clamp': float(np.mean(ssl_clamped_list)) if len(ssl_clamped_list) > 0 else None,
            'ssl_agree': float(np.mean(ssl_agree_list)) if len(ssl_agree_list) > 0 else None,
            'ssl_agree_fg': float(np.mean(ssl_agree_fg_list)) if len(ssl_agree_fg_list) > 0 else None,
            'ssl_agree_minw': float(getattr(config, 'ssl_agree_min_weight', 0.0)),
            'ssl_mode': str(getattr(config, 'ssl_weighting_mode', 'hard')).lower(),
            'ssl_soft_margin': float(getattr(config, 'ssl_soft_margin', 0.10)),
            'ssl_adapt_max_drop': float(getattr(config, 'ssl_adapt_max_drop', 0.0)),
        }
    except Exception:
        pass
    return step


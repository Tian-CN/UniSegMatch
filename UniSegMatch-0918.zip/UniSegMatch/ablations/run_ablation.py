"""Run the controlled eFAST ablation study used with UniSegMatch.

The ablation protocol is intentionally separate from the main-method reproduction:
there is no EMA teacher, strong views use photometric augmentation only, and the
training global step increments once per optimizer update.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import logging
import os
from pathlib import Path
import random
import sys
import time
from types import SimpleNamespace

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import numpy as np
import torch
from tensorboardX import SummaryWriter
from torch.utils.data import DataLoader, Subset

from ablations.dataset import EFASTAblationDataset
from ablations.engine import train_one_epoch
from losses import DiceLoss

VARIANTS = [
    "full",
    "seggpt_only",
    "sam_only",
    "no_gating",
    "agreement_only",
    "boundary_only",
    "no_confidence",
]
METRICS = ["miou", "dsc", "accuracy", "precision", "sensitivity", "specificity"]


def atomic_json(path: Path, obj) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix(path.suffix + ".tmp")
    temp.write_text(json.dumps(obj, indent=2, allow_nan=False), encoding="utf-8")
    os.replace(temp, path)


def config_for(variant: str, epochs: int = 10) -> SimpleNamespace:
    """Configuration of the executed controlled-ablation protocol."""
    return SimpleNamespace(
        variant=variant,
        epochs=epochs,
        crop_size=256,
        loss_use_dice=True,
        loss_weight_x=1.0,
        loss_weight_x2=0.05,
        loss_weight_x3=0.05,
        loss_weight_u_s1=0.25,
        loss_weight_u_s2=0.25,
        loss_weight_u_fp=0.25,
        loss_normalize_by_weight_sum=True,
        samseg_boundary_ks=11,
        samseg_min_keep_ratio=0.0,
        samseg_weight_ramp_enable=True,
        samseg_weight_start=0.2,
        samseg_weight_end=1.0,
        samseg_weight_warmup_epochs=2,
        samseg_weight_ramp_epochs=8,
        ssl_weight_ramp_enable=True,
        ssl_weight_start=0.2,
        ssl_weight_end=1.0,
        ssl_weight_warmup_epochs=2,
        ssl_weight_ramp_epochs=8,
        ssl_min_keep_ratio=0.02,
        ssl_adapt_max_drop=0.07,
        ssl_weighting_mode="soft",
        ssl_soft_margin=0.05,
        ssl_agree_enable=True,
        ssl_agree_fp_enable=False,
        ssl_agree_foreground_only=True,
        ssl_agree_min_weight=0.2,
        conf_threshold=0.90,
        conf_threshold_schedule=True,
        conf_threshold_start=0.95,
        conf_threshold_end=0.90,
        conf_threshold_warmup_epochs=5,
        conf_threshold_ramp_epochs=20,
        print_interval=20,
        max_steps=0,
    )


def seed_all(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.benchmark = False
    torch.backends.cudnn.deterministic = True


def make_loaders(cfg, split_dir: Path, workers: int, smoke: bool):
    labeled = EFASTAblationDataset(split_dir, cfg, train_l=True)
    pseudo = EFASTAblationDataset(split_dir, cfg, train_l=True, samseg=True)
    unlabeled = EFASTAblationDataset(split_dir, cfg, train_u=True)
    evaluation = EFASTAblationDataset(split_dir, cfg, valtest=True)

    sizes = {
        "labeled": len(labeled),
        "pseudo": len(pseudo),
        "unlabeled": len(unlabeled),
        "evaluation": len(evaluation),
    }
    if smoke:
        labeled, pseudo, unlabeled, evaluation = [
            Subset(dataset, list(range(min(2, len(dataset)))))
            for dataset in (labeled, pseudo, unlabeled, evaluation)
        ]

    def loader(dataset, shuffle: bool, batch: int = 2, drop: bool = False):
        return DataLoader(
            dataset,
            batch_size=batch,
            shuffle=shuffle,
            num_workers=workers,
            pin_memory=True,
            drop_last=drop,
        )

    loaders = [
        loader(labeled, True),
        loader(pseudo, True),
        loader(unlabeled, True),
        loader(unlabeled, False, drop=True),
    ]
    if min(map(len, loaders)) < 1:
        raise RuntimeError("At least one ablation training stream is empty after batching.")
    return loaders, loader(evaluation, False, batch=1), sizes


@torch.no_grad()
def evaluate(model, loader):
    model.eval()
    cm = torch.zeros(4, dtype=torch.int64, device="cuda")
    for images, targets in loader:
        logits = model(images.cuda(non_blocking=True))
        if not torch.isfinite(logits).all():
            raise FloatingPointError("Non-finite evaluation logits")
        pred = logits.argmax(1)
        code = targets.cuda(non_blocking=True).flatten() * 2 + pred.flatten()
        cm += torch.bincount(code, minlength=4)

    tn, fp, fn, tp = map(int, cm.cpu().tolist())

    def ratio(numerator, denominator):
        return numerator / denominator if denominator else 0.0

    return {
        "miou": ratio(tp, tp + fp + fn),
        "dsc": ratio(2 * tp, 2 * tp + fp + fn),
        "accuracy": ratio(tp + tn, tp + tn + fp + fn),
        "precision": ratio(tp, tp + fp),
        "sensitivity": ratio(tp, tp + fn),
        "specificity": ratio(tn, tn + fp),
        "confusion": [tn, fp, fn, tp],
    }


def aggregate(output_root: Path) -> None:
    rows = []
    for regime in (1, 20):
        for variant in VARIANTS:
            items = []
            for fold in range(25):
                result = output_root / f"train{regime}" / f"S{fold:02d}" / variant / "complete.json"
                if result.exists():
                    items.append(json.loads(result.read_text(encoding="utf-8")))
            if not items:
                continue

            row = {
                "regime": regime,
                "variant": variant,
                "n": len(items),
                "expected_n": 25,
                "complete": len(items) == 25,
            }
            for metric in METRICS:
                values = np.asarray([item["metrics"][metric] for item in items], dtype=float)
                row[f"{metric}_mean"] = float(values.mean())
                row[f"{metric}_std_population"] = float(values.std(ddof=0))
                row[f"{metric}_std_sample"] = float(values.std(ddof=1)) if len(values) > 1 else None
                final_values = np.asarray([item["final"]["metrics"][metric] for item in items], dtype=float)
                row[f"final_{metric}_mean"] = float(final_values.mean())
                row[f"final_{metric}_std_population"] = float(final_values.std(ddof=0))
                row[f"final_{metric}_std_sample"] = (
                    float(final_values.std(ddof=1)) if len(final_values) > 1 else None
                )
            rows.append(row)

    atomic_json(output_root / "summary.json", rows)
    if rows:
        temp = output_root / "summary.csv.tmp"
        with temp.open("w", newline="", encoding="utf-8") as handle:
            writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
            writer.writeheader()
            writer.writerows(rows)
        os.replace(temp, output_root / "summary.csv")


def record_best_table(output_root: Path) -> None:
    rows = []
    for path in sorted(output_root.glob("train*/S*/*/best.json")):
        best = json.loads(path.read_text(encoding="utf-8"))
        last = json.loads((path.parent / "last.json").read_text(encoding="utf-8"))
        rows.append(
            {
                "regime": int(path.parents[2].name[5:]),
                "fold": int(path.parents[1].name[1:]),
                "variant": path.parent.name,
                "completed": (path.parent / "complete.json").exists(),
                "best_epoch": best["epoch"],
                **{metric: best["metrics"][metric] for metric in METRICS},
                "last_epoch": last["epoch"],
                **{f"last_{metric}": last["metrics"][metric] for metric in METRICS},
            }
        )
    if rows:
        temp = output_root / "best_by_fold.csv.tmp"
        with temp.open("w", newline="", encoding="utf-8") as handle:
            writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
            writer.writeheader()
            writer.writerows(rows)
        os.replace(temp, output_root / "best_by_fold.csv")


def split_path(data_root: Path, regime: int, fold: int) -> Path:
    return data_root / f"train{regime}" / f"S{fold}"


def save_checkpoint_atomic(obj, destination: Path) -> None:
    temp = destination.with_suffix(destination.suffix + ".tmp")
    torch.save(obj, temp)
    os.replace(temp, destination)


def run_one(args, regime: int, fold: int, variant: str) -> None:
    output_root = args.output.resolve()
    folder = output_root / f"train{regime}" / f"S{fold:02d}" / variant
    folder.mkdir(parents=True, exist_ok=True)
    if (folder / "complete.json").exists():
        print("SKIP completed", folder, flush=True)
        return

    seed_all(args.seed)
    cfg = config_for(variant, 1 if args.smoke else args.epochs)
    cfg.max_steps = 1 if args.smoke else 0
    current_split = split_path(args.data_root.resolve(), regime, fold)
    loaders, evaluation_loader, sizes = make_loaders(cfg, current_split, args.workers, args.smoke)

    protocol = {
        **vars(cfg),
        "regime": regime,
        "fold": fold,
        "seed": args.seed,
        "sizes": sizes,
        "optimizer": "AdamW",
        "lr": 1e-4,
        "weight_decay": 1e-2,
        "cosine_T_max": 50,
        "eta_min": 1e-5,
        "batch_size": 2,
        "ema": False,
        "model": "UniSegMatch/VMUNet",
        "pretrained": str(args.pretrained.resolve()),
        "depths": [2, 2, 2, 2],
        "depths_decoder": [2, 2, 2, 1],
        "preprocessing": "grayscale->RGB, /255, bilinear image, nearest mask",
        "augmentation": "photometric-only strong views + CutMix",
        "selection": "maximum evaluation foreground IoU over epochs",
        "smoke": args.smoke,
    }
    config_path = folder / "config.json"
    if config_path.exists() and json.loads(config_path.read_text(encoding="utf-8")) != protocol:
        raise RuntimeError(f"Configuration mismatch in existing run: {folder}")
    atomic_json(config_path, protocol)

    logger = logging.getLogger(f"ablation.{regime}.{fold}.{variant}")
    logger.setLevel(logging.INFO)
    logger.propagate = False
    handler = logging.FileHandler(folder / "train.log")
    handler.setFormatter(logging.Formatter("%(asctime)s %(message)s"))
    logger.addHandler(handler)
    writer = SummaryWriter(str(folder / "tensorboard"))

    # Delay the heavy model import so --help and manifest tooling work without CUDA/Mamba installed.
    from models.vmunet.unisegmatch import VMUNet

    model = VMUNet(
        num_classes=2,
        input_channels=3,
        depths=[2, 2, 2, 2],
        depths_decoder=[2, 2, 2, 1],
        drop_path_rate=0.2,
        load_ckpt_path=str(args.pretrained.resolve()),
    )
    model.load_from()
    model = model.cuda()
    optimizer = torch.optim.AdamW(model.parameters(), lr=1e-4, weight_decay=1e-2)
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=50, eta_min=1e-5)

    best = None
    step = 0
    start_epoch = 1
    latest = folder / "latest.pth"
    if latest.exists():
        state = torch.load(latest, map_location="cpu")
        model.load_state_dict(state["model"])
        optimizer.load_state_dict(state["optimizer"])
        scheduler.load_state_dict(state["scheduler"])
        best = state["best"]
        step = state["step"]
        start_epoch = state["epoch"] + 1
        random.setstate(state["random"])
        np.random.set_state(state["numpy"])
        torch.set_rng_state(state["torch"])
        torch.cuda.set_rng_state_all(state["cuda"])
        del state

    criterion_ce = torch.nn.CrossEntropyLoss()
    criterion_dice = DiceLoss(n_classes=2)

    try:
        for epoch in range(start_epoch, cfg.epochs + 1):
            start_time = time.time()
            torch.cuda.reset_peak_memory_stats()
            step = train_one_epoch(
                *loaders,
                best["metrics"]["miou"] if best else 0.0,
                criterion_ce,
                criterion_dice,
                model,
                optimizer,
                scheduler,
                epoch,
                step,
                logger,
                cfg,
                writer,
            )
            metrics = evaluate(model, evaluation_loader)
            row = {
                "epoch": epoch,
                "metrics": metrics,
                "train": getattr(model, "_last_train_stats", {}),
                "elapsed_seconds": time.time() - start_time,
                "peak_gpu_bytes": torch.cuda.max_memory_allocated(),
            }
            atomic_json(folder / f"epoch_{epoch:02d}.json", row)
            atomic_json(folder / "last.json", row)

            if best is None or metrics["miou"] > best["metrics"]["miou"]:
                best = {"epoch": epoch, "metrics": metrics}
                save_checkpoint_atomic(model.state_dict(), folder / "best.pth")
                atomic_json(folder / "best.json", best)

            record_best_table(output_root)
            for name in METRICS:
                writer.add_scalar(f"evaluation/{name}", metrics[name], epoch)
            writer.add_scalar("evaluation/best_miou", best["metrics"]["miou"], epoch)

            state = {
                "model": model.state_dict(),
                "optimizer": optimizer.state_dict(),
                "scheduler": scheduler.state_dict(),
                "best": best,
                "step": step,
                "epoch": epoch,
                "random": random.getstate(),
                "numpy": np.random.get_state(),
                "torch": torch.get_rng_state(),
                "cuda": torch.cuda.get_rng_state_all(),
            }
            save_checkpoint_atomic(state, latest)
            logger.info("EPOCH_RESULT %s", json.dumps(row))
            writer.flush()
            print(
                f"TRAIN{regime} S{fold:02d} {variant} epoch={epoch} "
                f"miou={metrics['miou']:.6f} best={best['metrics']['miou']:.6f} "
                f"best_epoch={best['epoch']} seconds={row['elapsed_seconds']:.1f}",
                flush=True,
            )
            atomic_json(
                output_root / "status.json",
                {"status": "running", "regime": regime, "fold": fold, "variant": variant, "epoch": epoch, "best": best},
            )

        final = json.loads((folder / "last.json").read_text(encoding="utf-8"))
        atomic_json(
            folder / "complete.json",
            {
                **best,
                "regime": regime,
                "fold": fold,
                "variant": variant,
                "final": final,
                "stop_reason": "planned_epochs_completed",
            },
        )
        record_best_table(output_root)
        latest.unlink(missing_ok=True)
    finally:
        writer.close()
        logger.removeHandler(handler)
        handler.close()


def code_manifest() -> dict[str, str]:
    return {
        str(path.relative_to(ROOT)): hashlib.sha256(path.read_bytes()).hexdigest()
        for path in ROOT.rglob("*.py")
        if "runs" not in path.parts and "__pycache__" not in path.parts
    }


def acquire_optional_lock(output_root: Path):
    try:
        import fcntl
    except ImportError:
        return None
    handle = (output_root / "run.lock").open("w")
    fcntl.flock(handle, fcntl.LOCK_EX | fcntl.LOCK_NB)
    return handle


def parse_args():
    parser = argparse.ArgumentParser(description="Controlled eFAST ablations for UniSegMatch")
    parser.add_argument("--regimes", nargs="+", type=int, default=[1], choices=[1, 20])
    parser.add_argument("--folds", nargs="+", type=int, default=list(range(25)))
    parser.add_argument(
        "--variants",
        nargs="+",
        choices=VARIANTS,
        default=[variant for variant in VARIANTS if variant != "full"],
    )
    parser.add_argument("--epochs", type=int, default=10)
    parser.add_argument("--workers", type=int, default=2)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--data-root", type=Path, default=ROOT / "data_splits" / "efast")
    parser.add_argument("--pretrained", type=Path, default=ROOT / "pre_trained_weights" / "vmamba_small_e238_ema.pth")
    parser.add_argument("--output", type=Path, default=ROOT / "runs" / "ablations")
    parser.add_argument("--smoke", action="store_true", help="One epoch / one training step for environment checks.")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    if any(fold < 0 or fold > 24 for fold in args.folds):
        raise SystemExit("--folds must contain values from 0 to 24")
    if not torch.cuda.is_available():
        raise RuntimeError("Ablation training requires a CUDA-capable PyTorch installation.")

    torch.set_num_threads(4)
    default_output = (ROOT / "runs" / "ablations").resolve()
    if args.smoke and args.output.resolve() == default_output:
        args.output = ROOT / "runs" / "ablation_smoke"
    output_root = args.output.resolve()
    output_root.mkdir(parents=True, exist_ok=True)
    lock_handle = acquire_optional_lock(output_root)
    # Keep the descriptor alive for the duration of the process when fcntl is available.
    _ = lock_handle

    atomic_json(
        output_root / "plan.json",
        {
            "regimes": args.regimes,
            "folds": args.folds,
            "variants": args.variants,
            "epochs": args.epochs,
            "smoke": args.smoke,
        },
    )
    hashes = code_manifest()
    manifest_path = output_root / "code_manifest.json"
    if manifest_path.exists() and json.loads(manifest_path.read_text(encoding="utf-8")) != hashes:
        raise RuntimeError("Code changed since run creation; use a new --output directory.")
    atomic_json(manifest_path, hashes)

    try:
        for fold in args.folds:
            for regime in args.regimes:
                for variant in args.variants:
                    run_one(args, regime, fold, variant)
                    aggregate(output_root)
                    torch.cuda.empty_cache()
        atomic_json(output_root / "status.json", {"status": "complete"})
    except Exception as exc:
        atomic_json(output_root / "status.json", {"status": "failed", "error": repr(exc)})
        raise


if __name__ == "__main__":
    main()

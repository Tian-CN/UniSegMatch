from __future__ import annotations

import random
from pathlib import Path

import numpy as np
import torch
from PIL import Image, ImageEnhance, ImageOps
from torch.utils.data import Dataset

from datasets.common import load_path_array, require_same_length
from datasets.transforms import obtain_cutmix_box


class ISIC2017Dataset(Dataset):
    """NPY-manifest loader used by the final UniSegMatch ISIC 2017 experiments."""

    def __init__(
        self,
        split_dir,
        config,
        train_l: bool = False,
        train_u: bool = False,
        valtest: bool = False,
        nsample: int | None = None,
        samseg: bool = False,
    ):
        super().__init__()
        self.split_dir = Path(split_dir)
        self.size = getattr(config, "crop_size", 256)
        if isinstance(self.size, (tuple, list)):
            self.size = int(self.size[0])

        self.train_l = train_l
        self.train_u = train_u
        self.valtest = valtest
        self.samseg = samseg

        if self.train_l and self.samseg:
            self.data = load_path_array(self.split_dir / "data_test.npy", self.split_dir)
            self.mask2 = load_path_array(self.split_dir / "mask2_test.npy", self.split_dir)
            self.mask3 = load_path_array(self.split_dir / "mask3_test.npy", self.split_dir)
            require_same_length(data=self.data, mask2=self.mask2, mask3=self.mask3)
            if nsample is not None:
                self.data = self._repeat_to(self.data, nsample)
                self.mask2 = self._repeat_to(self.mask2, nsample)
                self.mask3 = self._repeat_to(self.mask3, nsample)
        elif self.train_l:
            self.data = load_path_array(self.split_dir / "data_train.npy", self.split_dir)
            self.mask = load_path_array(self.split_dir / "mask_train.npy", self.split_dir)
            require_same_length(data=self.data, mask=self.mask)
            if nsample is not None:
                self.data = self._repeat_to(self.data, nsample)
                self.mask = self._repeat_to(self.mask, nsample)
        else:
            # The final released protocol intentionally uses data_test.npy as the
            # unlabeled target stream and also evaluates it with mask_test.npy.
            self.data = load_path_array(self.split_dir / "data_test.npy", self.split_dir)
            self.mask = load_path_array(self.split_dir / "mask_test.npy", self.split_dir)
            require_same_length(data=self.data, mask=self.mask)
            if self.train_u and nsample is not None:
                self.data = self._repeat_to(self.data, nsample)
                self.mask = self._repeat_to(self.mask, nsample)

    @staticmethod
    def _repeat_to(arr: np.ndarray, nsample: int) -> np.ndarray:
        if len(arr) == 0:
            raise ValueError("Cannot repeat an empty split")
        return arr.repeat(int(np.ceil(nsample / len(arr))), axis=0)[:nsample]

    def __len__(self):
        return len(self.data)

    def _load_rgb(self, path: str) -> Image.Image:
        return Image.open(path).convert("RGB")

    def _load_mask(self, path: str) -> np.ndarray:
        if not path or not Path(path).is_file():
            raise FileNotFoundError(f"Required mask is missing: {path}")
        mask = Image.open(path).convert("L")
        mask = mask.resize((self.size, self.size), resample=Image.NEAREST)
        return (np.asarray(mask) > 0).astype(np.uint8)

    def _img_to_tensor(self, img: Image.Image) -> torch.Tensor:
        img = img.resize((self.size, self.size), resample=Image.BILINEAR)
        arr = np.asarray(img).astype(np.float32) / 255.0
        return torch.from_numpy(np.transpose(arr, (2, 0, 1)))

    def _strong_aug(self, img: Image.Image) -> Image.Image:
        # Preserved from the final experiment implementation.
        if random.random() < 0.5:
            img = ImageOps.mirror(img)
        if random.random() < 0.5:
            img = ImageOps.flip(img)
        if random.random() < 0.8:
            img = ImageEnhance.Brightness(img).enhance(random.uniform(0.7, 1.3))
        if random.random() < 0.8:
            img = ImageEnhance.Contrast(img).enhance(random.uniform(0.7, 1.3))
        if random.random() < 0.8:
            img = ImageEnhance.Color(img).enhance(random.uniform(0.7, 1.3))
        return img

    def __getitem__(self, index):
        img = self._load_rgb(str(self.data[index]))

        if self.valtest:
            mask = self._load_mask(str(self.mask[index]))
            return self._img_to_tensor(img).float(), torch.from_numpy(mask).long()

        if self.train_l:
            if self.samseg:
                mask2 = self._load_mask(str(self.mask2[index]))
                mask3 = self._load_mask(str(self.mask3[index]))
                return (
                    self._img_to_tensor(img).float(),
                    torch.from_numpy(mask2).long(),
                    torch.from_numpy(mask3).long(),
                )
            mask = self._load_mask(str(self.mask[index]))
            return self._img_to_tensor(img).float(), torch.from_numpy(mask).long()

        img_w = self._img_to_tensor(img).float()
        img_s1 = self._img_to_tensor(self._strong_aug(img.copy())).float()
        img_s2 = self._img_to_tensor(self._strong_aug(img.copy())).float()
        return (
            img_w,
            img_s1,
            img_s2,
            obtain_cutmix_box(self.size, p=0.5),
            obtain_cutmix_box(self.size, p=0.5),
        )

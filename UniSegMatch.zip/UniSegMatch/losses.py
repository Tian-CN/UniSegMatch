from __future__ import annotations

import torch
from torch import nn


class DiceLoss(nn.Module):
    """Multi-class Dice loss used by the semi-supervised training objective."""

    def __init__(self, n_classes: int):
        super().__init__()
        self.n_classes = n_classes

    def _one_hot_encoder(self, input_tensor: torch.Tensor) -> torch.Tensor:
        tensors = []
        for class_index in range(self.n_classes):
            tensors.append(input_tensor == class_index * torch.ones_like(input_tensor))
        return torch.cat(tensors, dim=1).float()

    @staticmethod
    def _dice_loss(score: torch.Tensor, target: torch.Tensor, ignore: torch.Tensor | None) -> torch.Tensor:
        target = target.float()
        smooth = 1e-5
        if ignore is None:
            valid = torch.ones_like(target, dtype=torch.bool)
        else:
            valid = ignore != 1
        intersect = torch.sum(score[valid] * target[valid])
        y_sum = torch.sum(target[valid] * target[valid])
        z_sum = torch.sum(score[valid] * score[valid])
        dice = (2 * intersect + smooth) / (z_sum + y_sum + smooth)
        return 1 - dice

    def forward(self, inputs, target, weight=None, softmax=False, ignore=None):
        if softmax:
            inputs = torch.softmax(inputs, dim=1)
        target = self._one_hot_encoder(target)
        if weight is None:
            weight = [1] * self.n_classes
        if inputs.size() != target.size():
            raise ValueError(f"Prediction and target shapes differ: {inputs.size()} vs {target.size()}")
        loss = 0.0
        for class_index in range(self.n_classes):
            loss += self._dice_loss(inputs[:, class_index], target[:, class_index], ignore) * weight[class_index]
        return loss / self.n_classes

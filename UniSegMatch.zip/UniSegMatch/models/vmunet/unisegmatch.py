from .fp_backbone import VSSM_FPStable
from pathlib import Path

import torch
from torch import nn

class VMUNet(nn.Module):
    def __init__(
        self,
        input_channels=3,
        num_classes=1,
        depths=[2, 2, 9, 2],
        depths_decoder=[2, 9, 2, 2],
        drop_path_rate=0.2,
        load_ckpt_path=None,
        fp_dropout_p: float = 0.5,
    ):
        super().__init__()

        self.load_ckpt_path = load_ckpt_path
        self.num_classes = num_classes

        self.vmunet = VSSM_FPStable(
            in_chans=input_channels,
            num_classes=num_classes,
            depths=depths,
            depths_decoder=depths_decoder,
            drop_path_rate=drop_path_rate,
            fp_dropout_p=fp_dropout_p,
        )

    def forward(self, x, need_fp=False):
        if x.size()[1] == 1:
            x = x.repeat(1, 3, 1, 1)
        logits = self.vmunet(x, need_fp=need_fp)
        if self.num_classes == 1:
            if need_fp:
                return (torch.sigmoid(logits)).chunk(2)
            return torch.sigmoid(logits)
        else:
            if need_fp:
                return logits.chunk(2)
            return logits

    def load_from(self):
        if self.load_ckpt_path is not None:
            ckpt_path = Path(self.load_ckpt_path)
            if not ckpt_path.is_file():
                raise FileNotFoundError(f'Pretrained VMamba checkpoint not found: {ckpt_path}')
            model_dict = self.vmunet.state_dict()
            modelCheckpoint = torch.load(ckpt_path, map_location='cpu')
            pretrained_dict = modelCheckpoint['model']
            new_dict = {k: v for k, v in pretrained_dict.items() if k in model_dict.keys()}
            model_dict.update(new_dict)
            print('Total model_dict: {}, Total pretrained_dict: {}, update: {}'.format(len(model_dict), len(pretrained_dict), len(new_dict)))
            self.vmunet.load_state_dict(model_dict)

            not_loaded_keys = [k for k in pretrained_dict.keys() if k not in new_dict.keys()]
            print('Not loaded keys:', not_loaded_keys)
            print("encoder loaded finished!")

            model_dict = self.vmunet.state_dict()
            modelCheckpoint = torch.load(ckpt_path, map_location='cpu')
            pretrained_odict = modelCheckpoint['model']
            pretrained_dict = {}
            for k, v in pretrained_odict.items():
                if 'layers.0' in k:
                    new_k = k.replace('layers.0', 'layers_up.3')
                    pretrained_dict[new_k] = v
                elif 'layers.1' in k:
                    new_k = k.replace('layers.1', 'layers_up.2')
                    pretrained_dict[new_k] = v
                elif 'layers.2' in k:
                    new_k = k.replace('layers.2', 'layers_up.1')
                    pretrained_dict[new_k] = v
                elif 'layers.3' in k:
                    new_k = k.replace('layers.3', 'layers_up.0')
                    pretrained_dict[new_k] = v
            new_dict = {k: v for k, v in pretrained_dict.items() if k in model_dict.keys()}
            model_dict.update(new_dict)
            print('Total model_dict: {}, Total pretrained_dict: {}, update: {}'.format(len(model_dict), len(pretrained_dict), len(new_dict)))
            self.vmunet.load_state_dict(model_dict)

            not_loaded_keys = [k for k in pretrained_dict.keys() if k not in new_dict.keys()]
            print('Not loaded keys:', not_loaded_keys)
            print("decoder loaded finished!")

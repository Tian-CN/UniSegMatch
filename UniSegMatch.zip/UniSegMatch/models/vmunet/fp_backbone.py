import torch
from torch import nn

from .backbone import VSSM

class VSSM_FPStable(VSSM):
    def __init__(self, *args, fp_dropout_p: float = 0.5, **kwargs):
        super().__init__(*args, **kwargs)
        self.fp_dropout = nn.Dropout2d(fp_dropout_p)

    def forward(self, x, need_fp: bool = False):
        x, skip_list = self.forward_features(x)
        skip_list.append(x)
        if need_fp:
            skip_list = [torch.cat((feat, self.fp_dropout(feat)), dim=0) for feat in skip_list]
            x = self.forward_features_up(x, skip_list)
            x = self.forward_final(x)
            return x
        x = self.forward_features_up(x, skip_list)
        x = self.forward_final(x)
        return x

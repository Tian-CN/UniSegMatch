from __future__ import annotations

import argparse
import copy
import os
from datetime import datetime
from pathlib import Path
from types import SimpleNamespace

import torch
from tensorboardX import SummaryWriter
from torch import nn
from torch.utils.data import DataLoader

from engine import test_one_epoch, train_one_epoch, val_one_epoch_metrics
from losses import DiceLoss
from utils import get_logger, get_optimizer, get_scheduler, log_config_info, log_model_size, set_seed


ROOT = Path(__file__).resolve().parent


def _config_namespace(config_cls) -> SimpleNamespace:
    values = {}
    for cls in reversed(config_cls.mro()):
        for key, value in vars(cls).items():
            if not key.startswith("_") and not callable(value):
                values[key] = copy.deepcopy(value)
    return SimpleNamespace(**values)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Train UniSegMatch on eFAST or ISIC 2017.")
    parser.add_argument("--dataset", choices=["efast", "isic2017"], required=True)
    parser.add_argument("--data-dir", type=Path, default=None, help="Directory containing the NPY split manifests.")
    parser.add_argument("--output-dir", type=Path, default=None, help="Experiment output directory.")
    parser.add_argument("--pretrained", type=Path, default=ROOT / "pre_trained_weights" / "vmamba_small_e238_ema.pth")
    parser.add_argument("--gpu-id", default="0")
    parser.add_argument("--epochs", type=int, default=None)
    parser.add_argument("--batch-size", type=int, default=None)
    parser.add_argument("--workers", type=int, default=None)
    parser.add_argument("--seed", type=int, default=None)
    parser.add_argument("--regime", type=int, choices=[1, 20], default=1, help="eFAST labeled-subject regime.")
    parser.add_argument("--fold", type=int, default=0, help="eFAST cyclic fold index (0-24).")
    parser.add_argument("--skip-model-profile", action="store_true", help="Skip parameter/FLOP reporting.")
    return parser.parse_args()


def load_dataset_config(name: str):
    if name == "efast":
        from configs.efast import Config
        from datasets.efast import EFASTDataset

        return _config_namespace(Config), EFASTDataset
    from configs.isic2017 import Config
    from datasets.isic2017 import ISIC2017Dataset

    return _config_namespace(Config), ISIC2017Dataset


def configure_run(args: argparse.Namespace):
    config, dataset_cls = load_dataset_config(args.dataset)
    if args.dataset == "efast" and not 0 <= args.fold <= 24:
        raise ValueError("--fold must be in 0..24")

    if args.data_dir is not None:
        data_dir = args.data_dir
    elif args.dataset == "efast":
        data_dir = ROOT / "data_splits" / "efast" / f"train{args.regime}" / f"S{args.fold}"
    else:
        data_dir = ROOT / "data_splits" / "isic2017"

    timestamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    if args.output_dir is not None:
        output_dir = args.output_dir
    elif args.dataset == "efast":
        output_dir = ROOT / "runs" / "efast" / f"train{args.regime}" / f"S{args.fold}" / timestamp
    else:
        output_dir = ROOT / "runs" / "isic2017" / timestamp

    config.data_path = str(data_dir.resolve())
    config.work_dir = str(output_dir.resolve()) + os.sep
    config.gpu_id = str(args.gpu_id)
    config.model_config["load_ckpt_path"] = str(args.pretrained.resolve())
    if args.epochs is not None:
        config.epochs = args.epochs
    if args.batch_size is not None:
        config.batch_size = args.batch_size
    if args.workers is not None:
        config.num_workers = args.workers
    if args.seed is not None:
        config.seed = args.seed
    return config, dataset_cls


def build_ema_model(model: torch.nn.Module) -> torch.nn.Module:
    model_ema = copy.deepcopy(model)
    for parameter in model_ema.parameters():
        parameter.requires_grad_(False)
    model_ema.eval()
    return model_ema


def build_loaders(config, dataset_cls):
    data_path = config.data_path
    trainset_l_samseg = dataset_cls(data_path, config, train_l=True, train_u=False, valtest=False, samseg=True)
    trainset_u = dataset_cls(data_path, config, train_l=False, train_u=True, valtest=False)
    trainset_l = dataset_cls(
        data_path,
        config,
        train_l=True,
        train_u=False,
        valtest=False,
        nsample=len(trainset_u),
        samseg=False,
    )
    valset = dataset_cls(data_path, config, train_l=False, train_u=False, valtest=True)

    common = dict(batch_size=config.batch_size, pin_memory=True, num_workers=config.num_workers, drop_last=True)
    trainloader_l_samseg = DataLoader(trainset_l_samseg, shuffle=True, **common)
    trainloader_u = DataLoader(trainset_u, shuffle=True, **common)
    trainloader_l = DataLoader(trainset_l, shuffle=True, **common)
    trainloader_u_mix = DataLoader(
        trainset_u,
        batch_size=config.batch_size,
        shuffle=False,
        pin_memory=True,
        num_workers=1,
        drop_last=True,
    )
    valloader = DataLoader(
        valset,
        batch_size=1,
        shuffle=False,
        pin_memory=True,
        num_workers=config.num_workers,
        drop_last=True,
    )

    if min(len(trainloader_l), len(trainloader_l_samseg), len(trainloader_u), len(trainloader_u_mix)) == 0:
        raise RuntimeError("At least one training stream is empty after batching. Check the split manifests and batch size.")
    return trainloader_l, trainloader_l_samseg, trainloader_u, trainloader_u_mix, valloader


def main() -> None:
    args = parse_args()
    config, dataset_cls = configure_run(args)

    # CUDA_VISIBLE_DEVICES is intentionally set before the first CUDA operation.
    os.environ["CUDA_VISIBLE_DEVICES"] = config.gpu_id
    if not torch.cuda.is_available():
        raise RuntimeError("UniSegMatch training requires a CUDA-capable PyTorch installation.")

    work_dir = Path(config.work_dir)
    checkpoint_dir = work_dir / "checkpoints"
    outputs_dir = work_dir / "outputs"
    log_dir = work_dir / "log"
    checkpoint_dir.mkdir(parents=True, exist_ok=True)
    outputs_dir.mkdir(parents=True, exist_ok=True)

    logger = get_logger("train", log_dir)
    writer = SummaryWriter(str(work_dir / "summary"))
    log_config_info(config, logger)

    set_seed(config.seed)
    torch.cuda.empty_cache()

    print("#----------Preparing dataset----------#")
    trainloader_l, trainloader_l_samseg, trainloader_u, trainloader_u_mix, valloader = build_loaders(
        config, dataset_cls
    )

    print("#----------Preparing model----------#")
    # Heavy model dependencies are imported lazily so CLI/help and split validation
    # remain usable before CUDA/Mamba are installed.
    from models.vmunet.unisegmatch import VMUNet

    model_cfg = config.model_config
    model = VMUNet(
        num_classes=model_cfg["num_classes"],
        input_channels=model_cfg["input_channels"],
        depths=model_cfg["depths"],
        depths_decoder=model_cfg["depths_decoder"],
        drop_path_rate=model_cfg["drop_path_rate"],
        load_ckpt_path=model_cfg["load_ckpt_path"],
    )
    model.load_from()
    model = model.cuda()
    if not args.skip_model_profile:
        log_model_size(model, config.crop_size, logger)

    model_ema = None
    if bool(getattr(config, "ema_teacher_enable", False)):
        model_ema = build_ema_model(model)
        logger.info(
            "EMA teacher enabled: decay=%s, warmup_steps=%s",
            config.ema_decay,
            config.ema_warmup_steps,
        )

    criterion_ce = nn.CrossEntropyLoss()
    criterion_dice = DiceLoss(2)
    optimizer = get_optimizer(config, model)
    scheduler = get_scheduler(config, optimizer)

    min_loss = float("inf")
    min_epoch = 1
    best_miou = -1.0
    best_miou_epoch = 1
    early_bad_epochs = 0
    early_patience = int(getattr(config, "early_stop_patience", 0))
    early_min_delta = float(getattr(config, "early_stop_min_delta", 0.0))
    early_start_epoch = int(getattr(config, "early_stop_start_epoch", 1))
    previous_best = 0.0
    step = 0

    try:
        print("#----------Training----------#")
        for epoch in range(1, config.epochs + 1):
            torch.cuda.empty_cache()
            step = train_one_epoch(
                trainloader_l,
                trainloader_l_samseg,
                trainloader_u,
                trainloader_u_mix,
                previous_best,
                criterion_ce,
                criterion_dice,
                model,
                optimizer,
                scheduler,
                epoch,
                step,
                logger,
                config,
                writer,
                model_ema=model_ema,
            )

            loss, miou, dsc = val_one_epoch_metrics(valloader, model, criterion_ce, epoch, logger, config)

            if loss < min_loss:
                torch.save(model.state_dict(), checkpoint_dir / "best_loss.pth")
                min_loss = loss
                min_epoch = epoch

            if miou > best_miou:
                torch.save(model.state_dict(), checkpoint_dir / "best_miou.pth")
                best_miou = miou
                best_miou_epoch = epoch
                early_bad_epochs = 0
                last_stats = getattr(model, "_last_train_stats", None)
                best_msg = f"BEST_MIOU epoch={epoch} miou={miou:.6f} loss={loss:.4f} dsc={dsc:.6f}"
                if isinstance(last_stats, dict):
                    best_msg += (
                        f" conf_th={last_stats.get('conf_th')} samseg_keep={last_stats.get('samseg_keep')}"
                        f" ssl_keep={last_stats.get('ssl_keep')} ssl_w_mean={last_stats.get('ssl_w_mean')}"
                        f" ema_decay={last_stats.get('ema_decay')}"
                    )
                print(best_msg)
                logger.info(best_msg)
                writer.add_scalar("best/miou", best_miou, global_step=epoch)
            elif early_patience > 0 and epoch >= early_start_epoch:
                if miou < best_miou + early_min_delta:
                    early_bad_epochs += 1
                else:
                    early_bad_epochs = 0

            torch.save(
                {
                    "epoch": epoch,
                    "min_loss": min_loss,
                    "min_epoch": min_epoch,
                    "best_miou": best_miou,
                    "best_miou_epoch": best_miou_epoch,
                    "loss": loss,
                    "miou": miou,
                    "dsc": dsc,
                    "model_state_dict": model.state_dict(),
                    "optimizer_state_dict": optimizer.state_dict(),
                    "scheduler_state_dict": scheduler.state_dict(),
                },
                checkpoint_dir / "latest.pth",
            )

            if early_patience > 0 and epoch >= early_start_epoch and early_bad_epochs >= early_patience:
                logger.info(
                    "EARLY_STOP epoch=%s best_epoch=%s best_miou=%.6f patience=%s",
                    epoch,
                    best_miou_epoch,
                    best_miou,
                    early_patience,
                )
                break

        best_path = checkpoint_dir / "best_miou.pth"
        if not best_path.exists():
            best_path = checkpoint_dir / "best_loss.pth"
        if best_path.exists():
            print("#----------Testing best checkpoint----------#")
            model.load_state_dict(torch.load(best_path, map_location="cpu"))
            model = model.cuda()
            test_one_epoch(valloader, model, criterion_ce, logger, config)

        if (checkpoint_dir / "best_miou.pth").exists():
            os.replace(
                checkpoint_dir / "best_miou.pth",
                checkpoint_dir / f"best-miou-epoch{best_miou_epoch}-miou{best_miou:.4f}.pth",
            )
        if (checkpoint_dir / "best_loss.pth").exists():
            os.replace(
                checkpoint_dir / "best_loss.pth",
                checkpoint_dir / f"best-loss-epoch{min_epoch}-loss{min_loss:.4f}.pth",
            )
    finally:
        writer.close()


if __name__ == "__main__":
    main()

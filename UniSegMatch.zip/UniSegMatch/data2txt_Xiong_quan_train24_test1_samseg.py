import os

import numpy as np

def set_data_path(image_dir, mask_dir):
    list_nii = os.listdir(image_dir)
    list_nii.sort()
    sitk_images = []
    sitk_masks = []
    for nii in list_nii:
        print(nii)
        list_subject = os.listdir(os.path.join(image_dir, nii))
        for vidio in list_subject:
            print(vidio)
            list_vidio = os.listdir(os.path.join(image_dir, nii, vidio))
            for picture in list_vidio:
                print(picture)
                if os.path.exists(os.path.join(image_dir, nii, vidio, picture)):
                    sitk_images.append(os.path.join(image_dir, nii, vidio, picture))
                    sitk_masks.append(os.path.join(mask_dir, nii, vidio, picture))
    return sitk_images, sitk_masks

def set_data_path_sam_seg(img_image_dir, SAM_mask_dir, SegGPT_mask_dir):
    image_dir = img_image_dir
    mask_dir = SAM_mask_dir
    mask_dir2 = SegGPT_mask_dir

    list_nii = os.listdir(image_dir)
    list_nii.sort()
    sitk_images = []
    sitk_masks = []
    sitk_masks2 = []
    for nii in list_nii:
        print(nii)
        list_subject = os.listdir(os.path.join(image_dir, nii))
        for vidio in list_subject:
            print(vidio)
            list_vidio = os.listdir(os.path.join(image_dir, nii, vidio))
            for picture in list_vidio:
                print(picture)
                if os.path.exists(os.path.join(image_dir, nii, vidio, picture)):
                    sitk_images.append(os.path.join(image_dir, nii, vidio, picture))
                    sitk_masks.append(os.path.join(mask_dir, nii, vidio, picture))
                    sitk_masks2.append(os.path.join(mask_dir2, nii, vidio, picture))
    return sitk_images, sitk_masks, sitk_masks2

def set_data_path_prompt(prompt_mask_dir):
    image_dir = prompt_mask_dir
    mask_dir = prompt_mask_dir

    list_nii = os.listdir(image_dir)
    list_nii.sort()
    sitk_images = []
    sitk_masks = []

    for nii in list_nii:
        print(nii)
        list_subject = os.listdir(os.path.join(image_dir, nii))
        for vidio in list_subject:
            print(vidio)
            list_vidio = os.listdir(os.path.join(image_dir, nii, vidio))
            for picture in list_vidio:
                print(picture)
                list_picture = os.listdir(os.path.join(image_dir, nii, vidio, picture))
                for frame in list_picture:
                    if os.path.exists(os.path.join(image_dir, nii, vidio, picture, frame)):
                        if "_label" in frame:
                            sitk_masks.append(os.path.join(mask_dir, nii, vidio, picture, frame))
                        else:
                            sitk_images.append(os.path.join(image_dir, nii, vidio, picture, frame))

    return sitk_images, sitk_masks

def get_keywords_by_indices(supported, indices):
    pass

    keywords_subset = [supported[index] for index in indices]
    return keywords_subset

def train_test_split_subject_independent(image, mask, testsubjects: int = [0]):
    train_image_paths, test_image_paths, train_mask_paths, test_mask_paths = [], [], [], []
    supported = ["001-", "002-", "003-", "004-", "005-", "006-", "007-", "008-", "009-", "010-", "011-", "012-", "013-",
                 "014-", "015-", "016-", "017-", "018-", "019-", "020-", "021-", "022-", "023-", "024-", "025-"]
    selected_keywords = get_keywords_by_indices(supported, testsubjects)

    for img, mask_img in zip(image, mask):

        if any(keyword in mask_img for keyword in selected_keywords):

            test_image_paths.append(img)
            test_mask_paths.append(mask_img)
        else:

            train_image_paths.append(img)
            train_mask_paths.append(mask_img)

    return train_image_paths, test_image_paths, train_mask_paths, test_mask_paths
def train_test_split_subject_independent_sam_seg(image, mask, mask2, testsubjects: int = [0]):
    train_image_paths, test_image_paths, train_mask_paths, test_mask_paths, train_mask2_paths, test_mask2_paths = [], [], [], [], [], []
    supported = ["001-", "002-", "003-", "004-", "005-", "006-", "007-", "008-", "009-", "010-", "011-", "012-", "013-",
                 "014-", "015-", "016-", "017-", "018-", "019-", "020-", "021-", "022-", "023-", "024-", "025-"]
    selected_keywords = get_keywords_by_indices(supported, testsubjects)

    for img, mask_img, mask2_img in zip(image, mask, mask2):

        if any(keyword in mask_img for keyword in selected_keywords):

            test_image_paths.append(img)
            test_mask_paths.append(mask_img)
            test_mask2_paths.append(mask2_img)
        else:

            train_image_paths.append(img)
            train_mask_paths.append(mask_img)
            train_mask2_paths.append(mask2_img)

    return train_image_paths, test_image_paths, train_mask_paths, test_mask_paths, train_mask2_paths, test_mask2_paths
def train_test_split_subject_independent_prompt(image, mask, testsubjects: int = [0]):
    train_image_paths, test_image_paths, train_mask_paths, test_mask_paths, train_mask2_paths, test_mask2_paths = [], [], [], [], [], []
    supported = ["001-", "002-", "003-", "004-", "005-", "006-", "007-", "008-", "009-", "010-", "011-", "012-", "013-",
                 "014-", "015-", "016-", "017-", "018-", "019-", "020-", "021-", "022-", "023-", "024-", "025-"]
    selected_keywords = get_keywords_by_indices(supported, testsubjects)

    for img, mask_img in zip(image, mask):

        if any(keyword in mask_img for keyword in selected_keywords):

            test_image_paths.append(img)
            test_mask_paths.append(mask_img)

        else:

            train_image_paths.append(img)
            train_mask_paths.append(mask_img)

    return train_image_paths, test_image_paths, train_mask_paths, test_mask_paths

def get_data_path(img_image_dir, prompt_mask_dir, SegGPT_mask_dir, SAM_mask_dir, testsubjects: int = [0]):
    image_paths, mask_paths, mask_paths2 = set_data_path_sam_seg(img_image_dir, SAM_mask_dir, SegGPT_mask_dir)
    image_paths_p, mask_paths_p = set_data_path_prompt(prompt_mask_dir)
    print("build dataset success!")

    train_image_paths, test_image_paths, train_mask_paths, test_mask_paths, train_mask2_paths, test_mask2_paths = train_test_split_subject_independent_sam_seg(
        image=image_paths, mask=mask_paths, mask2=mask_paths2, testsubjects=testsubjects)
    train_image_paths_p, test_image_paths_p, train_mask_paths_p, test_mask_paths_p = train_test_split_subject_independent_prompt(
        image=image_paths_p, mask=mask_paths_p, testsubjects=testsubjects)

    return train_image_paths, test_image_paths, train_mask_paths, test_mask_paths, train_mask2_paths, test_mask2_paths, train_image_paths_p, test_image_paths_p, train_mask_paths_p, test_mask_paths_p
if __name__ == '__main__':
    for testsubjects in range(2):

        path = "./splits/US_Xiong_all/train24_other_test_samseg/S" + str(testsubjects) + "/"
        test_all = [testsubjects + i for i in range(24)]

        if not os.path.exists(path):

            os.makedirs(path)
            print(f"文件夹 '{path}' 已创建。")
        else:
            print(f"文件夹 '{path}' 已存在。")

        image_dir = "./data/US/xiong_data/images/"
        mask_dir = "./data/US/xiong_data/masks/"

        image_paths = []
        mask_paths = []

        img_image_dir = "./data/US/xiong_data/images/"
        prompt_mask_dir = "./data/US/xiong_prompt/"
        SegGPT_mask_dir = "./data/US/xiong_data/masks/"
        SAM_mask_dir = "./data/US/xiong_data/mask_sam/"

        train_image_paths, test_image_paths, train_mask_paths, test_mask_paths, train_mask2_paths, test_mask2_paths, train_image_paths_p, test_image_paths_p, train_mask_paths_p, test_mask_paths_p = get_data_path(img_image_dir, prompt_mask_dir, SegGPT_mask_dir, SAM_mask_dir, test_all)

        trainImageSet = test_image_paths_p
        trainMaskSet = test_mask_paths_p
        testImageSet = train_image_paths_p
        testMaskSet = train_mask_paths_p
        trainImageSetSAM = test_image_paths
        trainMaskSetSAM = test_mask_paths

        trainImageSetSEG = test_image_paths
        trainMaskSetSEG = test_mask2_paths

        print("build dataset success!")

        def write_paths_to_txt(file_path, image_paths, mask_paths):
            with open(file_path, "w") as file:
                for image_path, mask_path in zip(image_paths, mask_paths):
                    file.write(f"{image_path} {mask_path}\n")

        Train_img, Test_img, Train_mask, Test_mask = trainImageSet, testImageSet, trainMaskSet, testMaskSet
        Train_img2, Train_mask2, Train_img3, Train_mask3 = trainImageSetSAM, trainMaskSetSAM, trainImageSetSEG, trainMaskSetSEG

        np.save("./splits/US_Xiong_all/train24_other_test_samseg/S" + str(testsubjects) + "/data_train", Train_img)
        np.save("./splits/US_Xiong_all/train24_other_test_samseg/S" + str(testsubjects) + "/data_test", Test_img)
        Validation_img = Test_img
        np.save("./splits/US_Xiong_all/train24_other_test_samseg/S" + str(testsubjects) + "/data_val", Validation_img)

        np.save("./splits/US_Xiong_all/train24_other_test_samseg/S" + str(testsubjects) + "/mask_train", Train_mask)
        np.save("./splits/US_Xiong_all/train24_other_test_samseg/S" + str(testsubjects) + "/mask_test", Test_mask)
        Validation_mask = Test_mask
        np.save("./splits/US_Xiong_all/train24_other_test_samseg/S" + str(testsubjects) + "/mask_val", Validation_mask)

        np.save("./splits/US_Xiong_all/train24_other_test_samseg/S" + str(testsubjects) + "/data_train2", Train_img2)
        np.save("./splits/US_Xiong_all/train24_other_test_samseg/S" + str(testsubjects) + "/data_train3", Train_img3)
        np.save("./splits/US_Xiong_all/train24_other_test_samseg/S" + str(testsubjects) + "/mask_train2", Train_mask2)
        np.save("./splits/US_Xiong_all/train24_other_test_samseg/S" + str(testsubjects) + "/mask_train3", Train_mask3)

        write_paths_to_txt("./splits/US_Xiong_all/train24_other_test_samseg/S" + str(testsubjects) + "/labeled.txt", trainImageSet, trainMaskSet)

        write_paths_to_txt("./splits/US_Xiong_all/train24_other_test_samseg/S" + str(testsubjects) + "/unlabeled.txt", testImageSet, testMaskSet)

        write_paths_to_txt("./splits/US_Xiong_all/train24_other_test_samseg/S" + str(testsubjects) + "/valtest.txt", testImageSet, testMaskSet)

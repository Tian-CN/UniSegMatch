#!/usr/bin/env python3
"""Validate UniSegMatch NPY split manifests before starting a GPU run."""

from __future__ import annotations

import argparse
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import numpy as np

from datasets.common import normalize_path_array


GROUPS = {
    "efast": [
        ("labeled", ["data_train.npy", "mask_train.npy"]),
        ("pseudo", ["data_train2.npy", "mask_train2.npy", "mask_train3.npy"]),
        ("unlabeled", ["data_test.npy", "mask_test.npy"]),
        ("validation", ["data_val.npy", "mask_val.npy"]),
    ],
    "isic2017": [
        ("labeled", ["data_train.npy", "mask_train.npy"]),
        ("target/evaluation", ["data_test.npy", "mask_test.npy", "mask2_test.npy", "mask3_test.npy"]),
    ],
}


def parse_args():
    parser = argparse.ArgumentParser(description="Validate UniSegMatch NPY split manifests")
    parser.add_argument("--dataset", required=True, choices=sorted(GROUPS))
    parser.add_argument("--data-dir", required=True, type=Path)
    parser.add_argument(
        "--check-files",
        action="store_true",
        help="Also resolve every path stored in each manifest and check that the referenced file exists.",
    )
    parser.add_argument("--show-missing", type=int, default=5, help="Maximum missing paths printed per manifest.")
    return parser.parse_args()


def load_manifest(path: Path):
    arr = np.load(path, allow_pickle=True)
    if arr.ndim == 0:
        arr = arr.reshape(1)
    return arr


def main() -> int:
    args = parse_args()
    split_dir = args.data_dir.resolve()
    if not split_dir.is_dir():
        print(f"ERROR: split directory does not exist: {split_dir}")
        return 2

    failures = 0
    print(f"Dataset: {args.dataset}")
    print(f"Split directory: {split_dir}")

    for group_name, filenames in GROUPS[args.dataset]:
        arrays = {}
        print(f"\n[{group_name}]")
        for filename in filenames:
            path = split_dir / filename
            if not path.is_file():
                print(f"  MISSING manifest: {filename}")
                failures += 1
                continue
            try:
                arr = load_manifest(path)
            except Exception as exc:
                print(f"  INVALID manifest: {filename}: {exc}")
                failures += 1
                continue
            arrays[filename] = arr
            print(f"  {filename}: {len(arr)} entries")

            if args.check_files:
                resolved = normalize_path_array(arr, split_dir)
                missing = [value for value in resolved if not value or not Path(value).is_file()]
                if missing:
                    failures += 1
                    print(f"    missing referenced files: {len(missing)}/{len(resolved)}")
                    for value in missing[: max(args.show_missing, 0)]:
                        print(f"      - {value}")
                else:
                    print("    referenced files: OK")

        if len(arrays) == len(filenames):
            lengths = {filename: len(arr) for filename, arr in arrays.items()}
            if len(set(lengths.values())) != 1:
                print(f"  ERROR: inconsistent lengths: {lengths}")
                failures += 1
            else:
                print(f"  aligned length: {next(iter(lengths.values()))}")

    if failures:
        print(f"\nValidation FAILED with {failures} issue(s).")
        return 1
    print("\nValidation PASSED.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

# UniSegMatch

PyTorch implementation of **UniSegMatch** for medical image segmentation on **eFAST** and **ISIC 2017**.

## Repository structure

```text
UniSegMatch/
├── train.py
├── engine.py
├── losses.py
├── utils.py
├── configs/
├── datasets/
├── models/vmunet/
├── ablations/
├── tools/validate_split.py
├── docs/DATA_LAYOUT.md
├── requirements.txt
└── LICENSE
```

## Installation

A CUDA-capable environment is recommended.

```bash
pip install -r requirements.txt
```

Place the VMamba pretrained checkpoint at:

```text
pre_trained_weights/vmamba_small_e238_ema.pth
```

or provide another path with `--pretrained`.

## Data preparation

The repository does not include dataset images, annotations, pseudo-label caches, or pretrained weights. Training uses `.npy` manifests containing paths to the required files.

See [`docs/DATA_LAYOUT.md`](docs/DATA_LAYOUT.md) for the expected manifest names and directory layout.

Optional validation before training:

```bash
python tools/validate_split.py --dataset efast --data-dir data_splits/efast/train1/S0 --check-files
python tools/validate_split.py --dataset isic2017 --data-dir data_splits/isic2017 --check-files
```

## Training

### eFAST

```bash
python train.py --dataset efast --regime 1 --fold 0
```

For the 20-labeled-subject setting:

```bash
python train.py --dataset efast --regime 20 --fold 0
```

A custom split directory can be provided with `--data-dir`:

```bash
python train.py \
  --dataset efast \
  --data-dir /path/to/split \
  --pretrained /path/to/vmamba_small_e238_ema.pth \
  --output-dir /path/to/output
```

### ISIC 2017

```bash
python train.py --dataset isic2017 --data-dir /path/to/isic2017_split
```

Training outputs are written to `runs/` by default and include logs, TensorBoard summaries, and checkpoints.

## Ablation experiments

The eFAST ablation runner supports:

`full`, `seggpt_only`, `sam_only`, `no_gating`, `agreement_only`, `boundary_only`, and `no_confidence`.

Example:

```bash
python ablations/run_ablation.py \
  --regimes 1 \
  --folds 0 \
  --variants seggpt_only sam_only no_gating agreement_only boundary_only no_confidence \
  --epochs 10
```

See [`ablations/README.md`](ablations/README.md) for usage details.

## Citation

Please cite the accompanying UniSegMatch paper when using this code.

## License

This project is released under the Apache License 2.0. See [`LICENSE`](LICENSE).

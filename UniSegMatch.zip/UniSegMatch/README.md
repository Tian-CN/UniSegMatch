# UniSegMatch

Python source snapshot for UniSegMatch segmentation training and ablation experiments.

## Contents

| Location | Contents |
|---|---|
| `train_US_XIONG_SWIN_MATCH*samseg*.py` | Ultrasound training entries and historical component ablations |
| `train_ISIC2017_SWIN_MATCH_train1_samseg_npy_ssl*.py` | Retained ISIC2017 training versions |
| `models/vmunet/` | State-space segmentation models and window-based backbones |
| `engine_match_samseg*.py` | Training objectives, consistency learning and component ablation engines |
| `configs/` | Existing training configuration files |
| `datasets/`, `util_match/`, `utils.py` | Data loading, augmentation, losses and utilities |
| `ablations/run_ablation.py` | Controlled pseudo-label source, gating and confidence ablations |
| `ablations/engine_ablation.py` | The engine copied from the executed ablation workspace |

The suffixes `ePG`, `eUni`, and `eSSM` identify the original component-ablation files. Filenames and version distinctions are retained so that different experimental implementations are not silently merged.

## Environment

Use Linux or WSL with a CUDA-capable PyTorch installation. Install a compatible `mamba-ssm` selective-scan implementation. The dependency list is inferred from imports; it is not a frozen historical environment specification. The ablation runner uses Linux `fcntl` locking.

```bash
pip install -r requirements.txt
```

## Data and weights

Run training commands from the project root. Prepare your own input data, split files, cached SegGPT/SAM-Med2D masks and pretrained weights. Dataset files, subject-level lists, checkpoints and experiment logs are not included in this source-only snapshot.

The retained loaders use the project-relative directories `data/`, `US_DATA/`, `isic2017_data/` and `pre_trained_weights/`. Update the relevant configuration before running. Different historical configuration versions retain their own defaults, including prompt-cache selections; select the version and dataset configuration for the intended experiment.

For the controlled ablations, prepare:

```text
US_DATA/train1_other_test_samseg_1by1/S0 ... S24
US_DATA/train20_other_test_samseg_1by1/S0 ... S24
pre_trained_weights/vmamba_small_e238_ema.pth
```

Training consumes cached LVM pseudo-labels. The separate SegGPT and SAM-Med2D inference projects are not included in this training-and-ablation snapshot.

## Controlled ablations

```bash
python ablations/run_ablation.py --regimes 1 --folds 0 --variants seggpt_only --epochs 10 --output runs/train1_example
python ablations/run_ablation.py --regimes 20 --folds 0 --variants sam_only --epochs 10 --output runs/train20_example
```

Available modes are `full`, `seggpt_only`, `sam_only`, `no_gating`, `agreement_only`, `boundary_only`, and `no_confidence`. The default queue excludes `full`. Specifying `--regimes 1 20` without `--folds` evaluates all 25 cyclic partitions for both regimes. The copied runner selects the best evaluation-IoU checkpoint and records both best and final-epoch metrics.

The historical Full entries and the later controlled ablation implementation are retained separately. This collection does not establish that every historical result used one identical configuration.

## Source preparation

Python comments and standalone documentation strings have been removed. Machine-specific absolute paths have been replaced with project-relative paths. The controlled runner uses the project root for inputs, weights and outputs, and checks free space on the project filesystem. Model calculations and training parameters have otherwise been preserved.

Static validation checks Python syntax, local imports, comments, documentation strings and private path residue. It does not constitute a new training run or numerical reproduction.

The upstream license is retained in `LICENSE`; any extracted source attribution is retained in `NOTICE`.

import os
import sys
import warnings

import torch
from tensorboardX import SummaryWriter
from torch import nn
from torch.utils.data import DataLoader

from configs.config_setting_ISIC2017_match_samseg_npy import setting_config
from datasets.dataset_isic2017_npy_match_samseg import ISIC2017NPYDataset
from engine_match_samseg_isic2017_v2 import train_one_epoch, val_one_epoch, test_one_epoch
from models.vmunet.swinvmunet_match import VMUNet
from util_match.utils import DiceLoss as MatchDiceLoss
from utils import *

warnings.filterwarnings("ignore")

def main(config):
    save_path = config.work_dir
    if not os.path.exists(save_path):
        os.makedirs(save_path)

    print('#----------Creating logger----------#')
    sys.path.append(config.work_dir + '/')
    log_dir = os.path.join(config.work_dir, 'log')
    checkpoint_dir = os.path.join(config.work_dir, 'checkpoints')
    resume_model = os.path.join(checkpoint_dir, 'latest.pth')
    outputs = os.path.join(config.work_dir, 'outputs')
    if not os.path.exists(checkpoint_dir):
        os.makedirs(checkpoint_dir)
    if not os.path.exists(outputs):
        os.makedirs(outputs)

    logger = get_logger('train', log_dir)
    writer = SummaryWriter(config.work_dir + 'summary')

    log_config_info(config, logger)

    print('#----------GPU init----------#')
    os.environ["CUDA_VISIBLE_DEVICES"] = config.gpu_id
    set_seed(config.seed)
    torch.cuda.empty_cache()

    print('#----------Preparing dataset----------#')
    data_path = config.data_path
    if not data_path.endswith('/'):
        data_path += '/'

    trainset_l_samseg = ISIC2017NPYDataset(
        data_path,
        config,
        train_l=True,
        train_u=False,
        Valtest=False,
        samseg=True,
    )
    trainloader_l_samseg = DataLoader(
        trainset_l_samseg,
        batch_size=config.batch_size,
        shuffle=True,
        pin_memory=True,
        num_workers=config.num_workers,
        drop_last=True,
    )

    trainset_u = ISIC2017NPYDataset(
        data_path,
        config,
        train_l=False,
        train_u=True,
        Valtest=False,
    )
    trainloader_u = DataLoader(
        trainset_u,
        batch_size=config.batch_size,
        shuffle=True,
        pin_memory=True,
        num_workers=config.num_workers,
        drop_last=True,
    )

    trainset_l = ISIC2017NPYDataset(
        data_path,
        config,
        train_l=True,
        train_u=False,
        Valtest=False,
        samseg=False,
    )
    trainloader_l = DataLoader(
        trainset_l,
        batch_size=config.batch_size,
        shuffle=True,
        pin_memory=True,
        num_workers=config.num_workers,
        drop_last=True,
    )

    trainloader_u_mix = DataLoader(
        trainset_u,
        batch_size=config.batch_size,
        pin_memory=True,
        num_workers=1,
        drop_last=True,
    )

    valset = ISIC2017NPYDataset(
        data_path,
        config,
        train_l=False,
        train_u=False,
        Valtest=True,
    )
    valloader = DataLoader(
        valset,
        batch_size=1,
        shuffle=False,
        pin_memory=True,
        num_workers=config.num_workers,
        drop_last=True,
    )

    print('#----------Prepareing Model----------#')
    model_cfg = config.model_config
    if config.network == 'vmunet':
        model = VMUNet(
            num_classes=model_cfg['num_classes'],
            input_channels=model_cfg['input_channels'],
            depths=model_cfg['depths'],
            depths_decoder=model_cfg['depths_decoder'],
            drop_path_rate=model_cfg['drop_path_rate'],
            load_ckpt_path=model_cfg['load_ckpt_path'],
        )
        model.load_from()
    else:
        raise Exception('network in not right!')

    model = model.cuda()
    cal_params_flops(model, 256, logger)

    print('#----------Prepareing loss, opt, sch and amp----------#')
    criterion = config.criterion
    DiceLoss2 = DiceLoss_T(wd=1)
    optimizer = get_optimizer(config, model)
    scheduler = get_scheduler(config, optimizer)

    criterion_ce = nn.CrossEntropyLoss()
    criterion_dice = MatchDiceLoss(2)

    print('#----------Set other params----------#')
    min_loss = 999
    start_epoch = 1
    min_epoch = 1

    previous_best = 0.0

    step = 0
    print('#----------Training----------#')
    for epoch in range(start_epoch, config.epochs + 1):
        torch.cuda.empty_cache()

        step = train_one_epoch(
            trainloader_l,
            trainloader_l_samseg,
            trainloader_u,
            trainloader_u_mix,
            previous_best,
            criterion_ce,
            criterion_dice,
            DiceLoss2,
            model,
            criterion,
            optimizer,
            scheduler,
            epoch,
            step,
            logger,
            config,
            writer,
        )

        loss = val_one_epoch(
            valloader,
            model,
            criterion,
            criterion_ce,
            criterion_dice,
            epoch,
            logger,
            config,
        )

        if loss < min_loss:
            torch.save(model.state_dict(), os.path.join(checkpoint_dir, 'best.pth'))
            min_loss = loss
            min_epoch = epoch

        torch.save(
            {
                'epoch': epoch,
                'min_loss': min_loss,
                'min_epoch': min_epoch,
                'loss': loss,
                'model_state_dict': model.state_dict(),
                'optimizer_state_dict': optimizer.state_dict(),
                'scheduler_state_dict': scheduler.state_dict(),
            },
            os.path.join(checkpoint_dir, 'latest.pth'),
        )

    if os.path.exists(os.path.join(checkpoint_dir, 'best.pth')):
        print('#----------Testing----------#')
        best_weight = torch.load(config.work_dir + 'checkpoints/best.pth', map_location=torch.device('cpu'))
        model.load_state_dict(best_weight)
        loss = test_one_epoch(
            valloader,
            model,
            criterion,
            criterion_ce,
            logger,
            config,
        )
        os.rename(
            os.path.join(checkpoint_dir, 'best.pth'),
            os.path.join(checkpoint_dir, f'best-epoch{min_epoch}-loss{min_loss:.4f}.pth'),
        )

if __name__ == '__main__':
    config = setting_config
    main(config)

import argparse
import os
from pathlib import Path
from typing import Dict, List, Sequence, Tuple

import numpy as np

def _list_pngs(root: Path) -> List[Path]:
    imgs = [p for p in root.rglob("*.png") if p.is_file()]
    imgs.sort()
    return imgs

def _subject_key_from_rel(rel: Path) -> str:

    parts = rel.parts
    if not parts:
        return ""
    return parts[0]

def _write_txt_pairs(path: Path, img_paths: Sequence[str], mask_paths: Sequence[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as f:
        for a, b in zip(img_paths, mask_paths):
            f.write(f"{a} {b}\n")

def _to_repo_style_data_path(abs_path: Path) -> str:

    s = abs_path.as_posix()
    marker = "/data/"
    if marker in s:
        return "./data/" + s.split(marker, 1)[1]
    return s

def _repo_style_to_abs(images_root: Path, repo_style_path: str) -> Path:
    pass

    s = str(repo_style_path).strip().replace('\\', '/')
    if not s:
        return Path("")
    if s.startswith("./data/"):
        suffix = s[len("./data/"):]

        data_root = images_root
        for _ in range(3):
            data_root = data_root.parent
        return (data_root / suffix).resolve()
    return Path(s).resolve()

def _list_prompt_pairs(prompt_root: Path, images_root: Path) -> List[Tuple[Path, Path]]:
    pass

    out: List[Tuple[Path, Path]] = []
    for label_abs in sorted(prompt_root.rglob("*_label.png")):
        if not label_abs.is_file():
            continue
        frame_dir = label_abs.parent
        rel_dir = frame_dir.relative_to(prompt_root)
        if len(rel_dir.parts) < 3:
            continue

        subject = rel_dir.parts[0]
        video = rel_dir.parts[1]
        frame_folder = rel_dir.parts[2]
        if not frame_folder.endswith("_json"):
            continue
        frame_id = frame_folder[: -len("_json")]

        img_abs = images_root / subject / video / f"{frame_id}.png"
        if not img_abs.exists():
            continue
        out.append((img_abs, label_abs))
    return out

def build_split(
    images_root: Path,
    gt_root: Path,
    sam_soft_root: Path,
    seggpt_soft_root: Path,
    prompt_root: Path,
    output_dir: Path,
    train_subjects: Sequence[str],
    *,
    require_all_masks: bool = True,
) -> None:
    output_dir.mkdir(parents=True, exist_ok=True)

    prompt_pairs = _list_prompt_pairs(prompt_root, images_root)
    if not prompt_pairs:
        raise RuntimeError(f"No prompt labels found under: {prompt_root}")

    train_img, train_gt = [], []
    val_img, val_gt = [], []
    train_sam_soft, train_seggpt_soft = [], []

    missing = 0
    for img_abs, prompt_label_abs in prompt_pairs:
        rel = img_abs.relative_to(images_root)
        subject = _subject_key_from_rel(rel)

        sam_abs = (sam_soft_root / rel).with_suffix(".png")
        seggpt_abs = (seggpt_soft_root / rel).with_suffix(".png")
        if require_all_masks:
            if (not sam_abs.exists()) or (not seggpt_abs.exists()):
                missing += 1
                continue

        img_s = _to_repo_style_data_path(img_abs)
        gt_s = _to_repo_style_data_path(prompt_label_abs)
        sam_s = _to_repo_style_data_path(sam_abs)
        seggpt_s = _to_repo_style_data_path(seggpt_abs)

        if any(ts == subject for ts in train_subjects):
            train_img.append(img_s)
            train_gt.append(gt_s)
            train_sam_soft.append(sam_s)
            train_seggpt_soft.append(seggpt_s)
        else:
            val_img.append(img_s)
            val_gt.append(gt_s)

    if missing:
        print(f"[WARN] skipped {missing} prompt-labeled samples due to missing SAM/SegGPT masks")

    prompt_img_set = {p.as_posix() for (p, _) in prompt_pairs}
    unlabeled_img = []
    for img_abs in _list_pngs(images_root):
        if img_abs.as_posix() in prompt_img_set:
            continue
        unlabeled_img.append(_to_repo_style_data_path(img_abs))

    samseg_img, samseg_sam, samseg_seggpt = [], [], []
    miss_pseudo = 0
    for img_s in unlabeled_img:
        img_abs = _repo_style_to_abs(images_root, img_s)
        rel = img_abs.relative_to(images_root)
        sam_abs = (sam_soft_root / rel).with_suffix(".png")
        seggpt_abs = (seggpt_soft_root / rel).with_suffix(".png")
        if require_all_masks:
            if (not sam_abs.exists()) or (not seggpt_abs.exists()):
                miss_pseudo += 1
                continue
        samseg_img.append(img_s)
        samseg_sam.append(_to_repo_style_data_path(sam_abs))
        samseg_seggpt.append(_to_repo_style_data_path(seggpt_abs))

    if miss_pseudo:
        print(f"[WARN] skipped {miss_pseudo} unlabeled samples due to missing SAM/SegGPT masks")

    np.save(output_dir / "data_train.npy", np.asarray(train_img, dtype=object))
    np.save(output_dir / "mask_train.npy", np.asarray(train_gt, dtype=object))

    np.save(output_dir / "data_test.npy", np.asarray(val_img, dtype=object))

    np.save(output_dir / "mask_test.npy", np.asarray(val_gt, dtype=object))

    np.save(output_dir / "data_val.npy", np.asarray(val_img, dtype=object))
    np.save(output_dir / "mask_val.npy", np.asarray(val_gt, dtype=object))

    np.save(output_dir / "data_train2.npy", np.asarray(samseg_img, dtype=object))
    np.save(output_dir / "mask_train2.npy", np.asarray(samseg_sam, dtype=object))
    np.save(output_dir / "data_train3.npy", np.asarray(samseg_img, dtype=object))
    np.save(output_dir / "mask_train3.npy", np.asarray(samseg_seggpt, dtype=object))

    np.save(output_dir / "data_samseg.npy", np.asarray(samseg_img, dtype=object))
    np.save(output_dir / "mask_samseg_sam.npy", np.asarray(samseg_sam, dtype=object))
    np.save(output_dir / "mask_samseg_seggpt.npy", np.asarray(samseg_seggpt, dtype=object))

    _write_txt_pairs(output_dir / "labeled.txt", train_img, train_gt)
    _write_txt_pairs(output_dir / "unlabeled.txt", unlabeled_img, ["" for _ in unlabeled_img])
    _write_txt_pairs(output_dir / "valtest.txt", val_img, val_gt)

def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser("Build VM-UNet US 1by1 splits with GT + SAM-soft + SegGPT-soft")

    p.add_argument(
        "--images_root",
        type=str,
        default="./data/US/xiong_data/images",
    )
    p.add_argument(
        "--gt_root",
        type=str,
        default="./data/US/xiong_data/masks",
    )
    p.add_argument(
        "--sam_soft_root",
        type=str,
        default="./data/US/xiong_data/sammed2d_pseudo",
    )
    p.add_argument(
        "--seggpt_soft_root",
        type=str,
        default="./data/US/xiong_data/seggpt_soft_pseudo",
    )

    p.add_argument(
        "--prompt_root",
        type=str,
        default="./data/US/xiong_prompt",
    )

    p.add_argument(
        "--output_root",
        type=str,
        default="./US_DATA/train1_other_test_samseg_1by1",
    )

    p.add_argument(
        "--train_k",
        type=int,
        default=1,
        help="Number of consecutive subjects (cyclic) used as training set for each split S{i}.",
    )

    p.add_argument(
        "--subjects",
        type=str,
        default="001-right,002-left,003-right,004-left,005-right,006-right,007-left,008-right,009-left,010-right,011-left,012-right,013-left,014-right,015-left,016-right,017-right,018-right,019-right,020-right,021-left,022-right,023-right,024-right,025-right",
        help="Comma-separated subject folder names under images_root.",
    )
    p.add_argument(
        "--require_all_masks",
        action="store_true",
        help="If set, skip samples missing any of GT/SAM-soft/SegGPT-soft.",
    )

    p.add_argument(
        "--sanity_check",
        action="store_true",
        help="If set, load generated files per split and print length consistency checks.",
    )

    return p.parse_args()

def main() -> None:
    args = parse_args()

    images_root = Path(args.images_root)
    gt_root = Path(args.gt_root)
    sam_soft_root = Path(args.sam_soft_root)
    seggpt_soft_root = Path(args.seggpt_soft_root)
    prompt_root = Path(args.prompt_root)
    output_root = Path(args.output_root)

    subjects = [s.strip() for s in args.subjects.split(",") if s.strip()]
    if not subjects:
        raise RuntimeError("Empty subjects list")

    train_k = int(args.train_k)
    if train_k < 1:
        raise ValueError("--train_k must be >= 1")
    if train_k > len(subjects):
        raise ValueError("--train_k must be <= number of subjects")

    def _count_lines(path: Path) -> int:
        if not path.exists():
            return -1
        with path.open("r", encoding="utf-8") as f:
            return sum(1 for _ in f)

    def _len_npy(path: Path) -> int:
        if not path.exists():
            return -1
        arr = np.load(str(path), allow_pickle=True)
        return int(len(arr))

    def _print_sanity(split_dir: Path) -> None:
        n_train = _len_npy(split_dir / "data_train.npy")
        n_train_gt = _len_npy(split_dir / "mask_train.npy")
        n_test = _len_npy(split_dir / "data_test.npy")
        n_test_gt = _len_npy(split_dir / "mask_test.npy")
        n_val = _len_npy(split_dir / "data_val.npy")
        n_val_gt = _len_npy(split_dir / "mask_val.npy")

        n_train2 = _len_npy(split_dir / "data_train2.npy")
        n_sam = _len_npy(split_dir / "mask_train2.npy")
        n_train3 = _len_npy(split_dir / "data_train3.npy")
        n_seggpt = _len_npy(split_dir / "mask_train3.npy")

        n_labeled = _count_lines(split_dir / "labeled.txt")
        n_unlabeled = _count_lines(split_dir / "unlabeled.txt")
        n_valtest = _count_lines(split_dir / "valtest.txt")

        print(f"[SanityCheck] dir={split_dir}")
        print(
            f"  train: data={n_train} gt={n_train_gt} sam={n_sam} seggpt={n_seggpt} "
            f"(data==gt:{n_train==n_train_gt}, data==sam:{n_train==n_sam}, data==seggpt:{n_train==n_seggpt})"
        )
        print(
            f"  test : data={n_test} gt={n_test_gt} (data==gt:{n_test==n_test_gt})"
        )
        print(
            f"  val  : data={n_val} gt={n_val_gt} (data==gt:{n_val==n_val_gt})"
        )
        print(
            f"  txt  : labeled={n_labeled} unlabeled={n_unlabeled} valtest={n_valtest} "
            f"(labeled==train:{n_labeled==n_train}, unlabeled==test:{n_unlabeled==n_test}, valtest==val:{n_valtest==n_val})"
        )
        print(
            f"  train2/3: data_train2={n_train2} data_train3={n_train3} "
            f"(train2==test:{n_train2==n_test}, train3==test:{n_train3==n_test})"
        )

    for i in range(len(subjects)):
        out_dir = output_root / f"S{i}"
        train_subjects = [subjects[(i + j) % len(subjects)] for j in range(train_k)]
        print(f"[Split S{i}] train_subjects={','.join(train_subjects)}")
        build_split(
            images_root,
            gt_root,
            sam_soft_root,
            seggpt_soft_root,
            prompt_root,
            out_dir,
            train_subjects,
            require_all_masks=bool(args.require_all_masks),
        )

        if bool(args.sanity_check):
            _print_sanity(out_dir)

if __name__ == "__main__":
    main()

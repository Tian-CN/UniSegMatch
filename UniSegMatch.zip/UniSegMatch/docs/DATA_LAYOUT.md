# Data layout

UniSegMatch uses `.npy` object arrays as path manifests. Each entry stores a path to an image or mask file.

Paths may be absolute, repository-relative, or split-directory-relative.

## eFAST

Default directory structure:

```text
data_splits/
└── efast/
    ├── train1/
    │   ├── S0/
    │   ├── S1/
    │   └── ...
    └── train20/
        ├── S0/
        ├── S1/
        └── ...
```

Each split directory contains:

| Manifest | Content |
|---|---|
| `data_train.npy` | labeled training images |
| `mask_train.npy` | ground-truth masks for `data_train.npy` |
| `data_train2.npy` | images paired with cached pseudo-labels |
| `mask_train2.npy` | SAM pseudo-labels |
| `mask_train3.npy` | SegGPT pseudo-labels |
| `data_test.npy` | unlabeled training images |
| `mask_test.npy` | masks paired with `data_test.npy` |
| `data_val.npy` | validation images |
| `mask_val.npy` | validation masks |

Arrays used as pairs or triplets must have matching lengths.

## ISIC 2017

Default directory structure:

```text
data_splits/
└── isic2017/
    ├── data_train.npy
    ├── mask_train.npy
    ├── data_test.npy
    ├── mask_test.npy
    ├── mask2_test.npy
    └── mask3_test.npy
```

| Manifest | Content |
|---|---|
| `data_train.npy` | labeled training images |
| `mask_train.npy` | labeled training masks |
| `data_test.npy` | unlabeled/evaluation image list |
| `mask_test.npy` | evaluation masks |
| `mask2_test.npy` | SAM pseudo-labels |
| `mask3_test.npy` | SegGPT pseudo-labels |

## Validate manifests

```bash
python tools/validate_split.py --dataset efast --data-dir data_splits/efast/train1/S0 --check-files
python tools/validate_split.py --dataset isic2017 --data-dir data_splits/isic2017 --check-files
```

Without `--check-files`, the validator checks manifest presence and array lengths. With `--check-files`, it also verifies referenced files.

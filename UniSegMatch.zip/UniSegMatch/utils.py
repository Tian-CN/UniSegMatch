from __future__ import annotations

import logging
import logging.handlers
import math
import os
import random
from pathlib import Path

import matplotlib
import numpy as np
import torch
import torch.backends.cudnn as cudnn

matplotlib.use("Agg")
from matplotlib import pyplot as plt


def set_seed(seed: int) -> None:
    os.environ["PYTHONHASHSEED"] = str(seed)
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    cudnn.benchmark = False
    cudnn.deterministic = True


def get_logger(name: str, log_dir: str | Path) -> logging.Logger:
    log_dir = Path(log_dir)
    log_dir.mkdir(parents=True, exist_ok=True)
    logger = logging.getLogger(name)
    logger.setLevel(logging.INFO)
    logger.propagate = False
    if not logger.handlers:
        handler = logging.handlers.TimedRotatingFileHandler(
            log_dir / f"{name}.info.log", when="D", encoding="utf-8"
        )
        handler.setLevel(logging.INFO)
        handler.setFormatter(logging.Formatter("%(asctime)s - %(message)s", datefmt="%Y-%m-%d %H:%M:%S"))
        logger.addHandler(handler)
    return logger


def log_config_info(config, logger: logging.Logger) -> None:
    logger.info("#----------Config info----------#")
    for key, value in sorted(vars(config).items()):
        if not key.startswith("_"):
            logger.info("%s: %s", key, value)


def get_optimizer(config, model):
    if config.opt != "AdamW":
        raise ValueError(f"Expected optimizer AdamW, got {config.opt!r}")
    return torch.optim.AdamW(
        model.parameters(),
        lr=config.lr,
        betas=config.betas,
        eps=config.eps,
        weight_decay=config.weight_decay,
        amsgrad=config.amsgrad,
    )


def get_scheduler(config, optimizer):
    if config.sch != "CosineAnnealingLR":
        raise ValueError(f"Expected scheduler CosineAnnealingLR, got {config.sch!r}")
    return torch.optim.lr_scheduler.CosineAnnealingLR(
        optimizer,
        T_max=config.T_max,
        eta_min=config.eta_min,
        last_epoch=config.last_epoch,
    )


def save_imgs(img, mask, pred, index, save_path, datasets, threshold=0.5, test_data_name=None):
    img = img.squeeze(0).permute(1, 2, 0).detach().cpu().numpy()
    img = img / 255.0 if img.max() > 1.1 else img
    mask = np.where(np.squeeze(mask, axis=0) > 0.5, 1, 0)
    pred = np.where(np.squeeze(pred, axis=0) > threshold, 1, 0)

    plt.figure(figsize=(7, 15))
    for subplot, array, cmap in [(1, img, None), (2, mask, "gray"), (3, pred, "gray")]:
        plt.subplot(3, 1, subplot)
        plt.imshow(array, cmap=cmap)
        plt.axis("off")
    prefix = f"{test_data_name}_" if test_data_name is not None else ""
    Path(save_path).mkdir(parents=True, exist_ok=True)
    plt.savefig(Path(save_path) / f"{prefix}{index}.png")
    plt.close()


def log_model_size(model, input_size: int, logger: logging.Logger) -> None:
    total = sum(p.numel() for p in model.parameters())
    logger.info("Total parameters: %.4f M", total / 1e6)
    print(f"Total params: {total / 1e6:.2f}M")
    try:
        from thop import profile  # optional
    except ImportError:
        logger.info("THOP not installed; FLOP count skipped.")
        return
    sample = torch.randn(1, 3, input_size, input_size, device=next(model.parameters()).device)
    flops, params = profile(model, inputs=(sample,), verbose=False)
    logger.info("FLOPs: %.4f G; THOP params: %.4f M", flops / 1e9, params / 1e6)
    print(f"FLOPs: {flops / 1e9:.2f}G")

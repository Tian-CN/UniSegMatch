from torchvision import transforms
from utils import *

from datetime import datetime

class setting_config:
    network = 'vmunet'
    model_config = {
        'num_classes': 2,
        'input_channels': 3,
        'depths': [2, 2, 2, 2],
        'depths_decoder': [2, 2, 2, 1],
        'drop_path_rate': 0.2,
        'load_ckpt_path': './pre_trained_weights/vmamba_small_e238_ema.pth',
    }

    datasets = 'isic17'
    data_path = './isic2017_data/isic2017_seggpt0.01top5/isic2017_seggpt/'
    criterion = BceDiceLoss(wb=1, wd=1)

    pretrained_path = './pre_trained/'
    num_classes = 2
    input_size_h = 256
    input_size_w = 256
    input_channels = 3
    distributed = False
    local_rank = -1
    num_workers = 2

    seed = 42
    world_size = None
    rank = None
    amp = False
    gpu_id = '0'
    batch_size = 2
    epochs = 20

    early_stop_patience = 0
    early_stop_min_delta = 0.0
    early_stop_start_epoch = 1

    work_dir = 'results/' + network + '_' + datasets + '_' + datetime.now().strftime('%A_%d_%B_%Y_%Hh_%Mm_%Ss') + '/'

    print_interval = 20
    val_interval = 1
    save_interval = 20
    threshold = 0.5

    loss_use_dice = True
    loss_weight_x  = 1.0
    loss_weight_x2 = 0.05
    loss_weight_x3 = 0.05
    loss_weight_u_s1 = 0.25
    loss_weight_u_s2 = 0.25
    loss_weight_u_fp = 0.25
    loss_normalize_by_weight_sum = True

    samseg_gating_mode = 'boundary+conf'
    samseg_conf_threshold = 0.85
    samseg_boundary_ks = 11
    samseg_boundary_source = 'consensus'
    samseg_min_keep_ratio = 0.0

    samseg_target_mode = 'consensus'

    samseg_weight_ramp_enable = True
    samseg_weight_start = 0.2
    samseg_weight_end = 1.0
    samseg_weight_warmup_epochs = 2
    samseg_weight_ramp_epochs = 8

    ssl_weight_ramp_enable = True
    ssl_weight_start = 0.2
    ssl_weight_end = 1.0
    ssl_weight_warmup_epochs = 2
    ssl_weight_ramp_epochs = 8

    ssl_min_keep_ratio = 0.02

    ssl_adapt_max_drop = 0.07

    ssl_weighting_mode = 'soft'
    ssl_soft_margin = 0.05

    ssl_agree_enable = True
    ssl_agree_fp_enable = False
    ssl_agree_foreground_only = True
    ssl_agree_min_weight = 0.2

    loss_weight_x2 = 0.05
    loss_weight_x3 = 0.05

    conf_threshold = 0.90

    conf_threshold_schedule = True
    conf_threshold_start = 0.95
    conf_threshold_end = 0.90
    conf_threshold_warmup_epochs = 5
    conf_threshold_ramp_epochs = 20

    train_transformer = transforms.Compose([
        myNormalize(datasets, train=True),
        myToTensor(),
        myRandomHorizontalFlip(p=0.5),
        myRandomVerticalFlip(p=0.5),
        myRandomRotation(p=0.5, degree=[0, 360]),
        myResize(input_size_h, input_size_w),
    ])
    test_transformer = transforms.Compose([
        myNormalize(datasets, train=False),
        myToTensor(),
        myResize(input_size_h, input_size_w),
    ])

    opt = 'AdamW'
    assert opt in ['Adadelta', 'Adagrad', 'Adam', 'AdamW', 'Adamax', 'ASGD', 'RMSprop', 'Rprop', 'SGD'], 'Unsupported optimizer!'
    if opt == 'Adadelta':
        lr = 0.01
        rho = 0.9
        eps = 1e-6
        weight_decay = 0.05
    elif opt == 'Adagrad':
        lr = 0.01
        lr_decay = 0
        eps = 1e-10
        weight_decay = 0.05
    elif opt == 'Adam':
        lr = 0.001
        betas = (0.9, 0.999)
        eps = 1e-8
        weight_decay = 0.0001
        amsgrad = False
    elif opt == 'AdamW':
        lr = 0.0001
        betas = (0.9, 0.999)
        eps = 1e-8
        weight_decay = 1e-2
        amsgrad = False
    elif opt == 'Adamax':
        lr = 2e-3
        betas = (0.9, 0.999)
        eps = 1e-8
        weight_decay = 0
    elif opt == 'ASGD':
        lr = 0.01
        lambd = 1e-4
        alpha = 0.75
        t0 = 1e6
        weight_decay = 0
    elif opt == 'RMSprop':
        lr = 1e-2
        momentum = 0
        alpha = 0.99
        eps = 1e-8
        centered = False
        weight_decay = 0
    elif opt == 'Rprop':
        lr = 1e-2
        etas = (0.5, 1.2)
        step_sizes = (1e-6, 50)
    elif opt == 'SGD':
        lr = 0.01
        momentum = 0.9
        weight_decay = 0.05
        dampening = 0
        nesterov = False

    sch = 'CosineAnnealingLR'
    if sch == 'CosineAnnealingLR':
        T_max = 50
        eta_min = 0.00001

        last_epoch = -1

from configs.base import BaseConfig


class Config(BaseConfig):
    dataset_name = "isic2017"
    datasets = "isic2017"
    data_path = "./data_splits/isic2017"

from __future__ import annotations


class BaseConfig:
    network = "vmunet"
    model_config = {
        "num_classes": 2,
        "input_channels": 3,
        "depths": [2, 2, 2, 2],
        "depths_decoder": [2, 2, 2, 1],
        "drop_path_rate": 0.2,
        "load_ckpt_path": "./pre_trained_weights/vmamba_small_e238_ema.pth",
    }

    num_classes = 2
    crop_size = 256
    input_size_h = 256
    input_size_w = 256
    input_channels = 3

    num_workers = 2
    seed = 42
    gpu_id = "0"
    batch_size = 2
    epochs = 20

    early_stop_patience = 0
    early_stop_min_delta = 0.0
    early_stop_start_epoch = 1

    print_interval = 20
    val_interval = 1
    save_interval = 20
    threshold = 0.5

    ema_teacher_enable = True
    ema_decay = 0.999
    ema_warmup_steps = 200

    loss_use_dice = True
    loss_weight_x = 1.0
    loss_weight_x2 = 0.05
    loss_weight_x3 = 0.05
    loss_weight_u_s1 = 0.25
    loss_weight_u_s2 = 0.25
    loss_weight_u_fp = 0.25
    loss_normalize_by_weight_sum = True

    samseg_gating_mode = "boundary+conf"
    samseg_conf_threshold = 0.85
    samseg_boundary_ks = 11
    samseg_boundary_source = "consensus"
    samseg_min_keep_ratio = 0.0
    samseg_target_mode = "consensus"

    samseg_weight_ramp_enable = True
    samseg_weight_start = 0.2
    samseg_weight_end = 1.0
    samseg_weight_warmup_epochs = 2
    samseg_weight_ramp_epochs = 8

    ssl_weight_ramp_enable = True
    ssl_weight_start = 0.2
    ssl_weight_end = 1.0
    ssl_weight_warmup_epochs = 2
    ssl_weight_ramp_epochs = 8

    ssl_min_keep_ratio = 0.02
    ssl_adapt_max_drop = 0.07
    ssl_weighting_mode = "soft"
    ssl_soft_margin = 0.05

    ssl_agree_enable = True
    ssl_agree_fp_enable = False
    ssl_agree_foreground_only = True
    ssl_agree_min_weight = 0.2

    conf_threshold = 0.90
    conf_threshold_schedule = True
    conf_threshold_start = 0.95
    conf_threshold_end = 0.90
    conf_threshold_warmup_epochs = 5
    conf_threshold_ramp_epochs = 20

    opt = "AdamW"
    lr = 1e-4
    betas = (0.9, 0.999)
    eps = 1e-8
    weight_decay = 1e-2
    amsgrad = False

    sch = "CosineAnnealingLR"
    T_max = 50
    eta_min = 1e-5
    last_epoch = -1

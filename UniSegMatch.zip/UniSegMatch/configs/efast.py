from configs.base import BaseConfig


class Config(BaseConfig):
    dataset_name = "efast"
    datasets = "efast"
    data_path = "./data_splits/efast/train1/S0"

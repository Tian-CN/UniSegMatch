# Ablation experiments

The eFAST ablation runner provides the following variants:

- `full`
- `seggpt_only`
- `sam_only`
- `no_gating`
- `agreement_only`
- `boundary_only`
- `no_confidence`

Example:

```bash
python ablations/run_ablation.py \
  --regimes 1 20 \
  --folds 0 \
  --variants seggpt_only sam_only no_gating \
  --epochs 10
```

By default, eFAST split directories are read from `data_splits/efast/train{1|20}/S{fold}` and VMamba weights from `pre_trained_weights/vmamba_small_e238_ema.pth`. Both locations can be overridden from the command line.

The runner writes per-run metrics, checkpoints, and aggregate summaries to the selected output directory.

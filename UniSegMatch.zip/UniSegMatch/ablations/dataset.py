"""Dataset variant for eFAST ablation experiments."""

import random
from PIL import Image, ImageEnhance

from datasets.efast import EFASTDataset


class EFASTAblationDataset(EFASTDataset):
    """eFAST loader with photometric strong augmentation."""

    def _strong_aug(self, img: Image.Image) -> Image.Image:
        if random.random() < 0.8:
            img = ImageEnhance.Brightness(img).enhance(random.uniform(0.7, 1.3))
        if random.random() < 0.8:
            img = ImageEnhance.Contrast(img).enhance(random.uniform(0.7, 1.3))
        if random.random() < 0.8:
            img = ImageEnhance.Color(img).enhance(random.uniform(0.7, 1.3))
        return img

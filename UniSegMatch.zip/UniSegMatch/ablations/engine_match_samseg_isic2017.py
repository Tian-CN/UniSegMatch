import numpy as np
import sys
from tqdm import tqdm
import torch
import torch.nn.functional as F
from torch.cuda.amp import autocast as autocast
from sklearn.metrics import confusion_matrix
from utils import save_imgs
from util_match.utils import AverageMeter, count_params, init_log, DiceLoss

def train_one_epoch(trainloader_l,
                    trainloader_l_samseg,
                    trainloader_u,
                    trainloader_u_mix,
                    previous_best,
                    criterion_ce,
                    criterion_dice,
                    DiceLoss2,
                    model,
                    criterion,
                    optimizer,
                    scheduler,
                    epoch,
                    step,
                    logger,
                    config,
                    writer):
    pass

    logger.info('===========> Epoch: {:}, LR: {:.5f}, Previous best: {:.2f}'.format(
        epoch, optimizer.param_groups[0]['lr'], previous_best))
    mean_dice_train = 0
    total_loss = AverageMeter()
    total_loss_x = AverageMeter()

    total_loss_x2 = AverageMeter()
    total_loss_x3 = AverageMeter()

    total_loss_s = AverageMeter()
    total_loss_w_fp = AverageMeter()
    total_mask_ratio = AverageMeter()

    model.train()

    loss_list = []
    loss_x_list = []
    loss_x2_list = []
    loss_x3_list = []
    loss_u_s1_list = []
    loss_u_s2_list = []
    loss_u_w_fp_list = []
    loader = zip(trainloader_l, trainloader_l_samseg, trainloader_u, trainloader_u_mix)
    for i, ((img_x, mask_x),
            (img_x2, mask_x2, mask_x3),
            (img_u_w, img_u_s1, img_u_s2, cutmix_box1, cutmix_box2),
            (img_u_w_mix, img_u_s1_mix, img_u_s2_mix, _, _)) in tqdm(enumerate(loader),
                                                                     total=min(len(trainloader_l),
                                                                               len(trainloader_l_samseg),
                                                                               len(trainloader_u),
                                                                               len(trainloader_u_mix)),
                                                                     mininterval=120.0,
                                                                     maxinterval=360.0,
                                                                     miniters=400):
        step += i
        img_x, mask_x = img_x.cuda(non_blocking=True), mask_x.cuda(non_blocking=True)
        img_x2, mask_x2, mask_x3 = img_x2.cuda(non_blocking=True), mask_x2.cuda(non_blocking=True), mask_x3.cuda(non_blocking=True)
        img_u_w = img_u_w.cuda(non_blocking=True)
        img_u_s1, img_u_s2 = img_u_s1.cuda(non_blocking=True), img_u_s2.cuda(non_blocking=True)
        cutmix_box1, cutmix_box2 = cutmix_box1.cuda(non_blocking=True), cutmix_box2.cuda(non_blocking=True)
        img_u_w_mix = img_u_w_mix.cuda(non_blocking=True)
        img_u_s1_mix, img_u_s2_mix = img_u_s1_mix.cuda(non_blocking=True), img_u_s2_mix.cuda(non_blocking=True)
        with torch.no_grad():
            model.eval()

            pred_u_w_mix = model(img_u_w_mix).detach()
            conf_u_w_mix = pred_u_w_mix.softmax(dim=1).max(dim=1)[0]
            mask_u_w_mix = pred_u_w_mix.argmax(dim=1)

        B, C, H, W = img_u_s1.shape

        if cutmix_box1.dim() == 1 and cutmix_box1.shape[0] == 4:

            x1, y1, x2, y2 = cutmix_box1[0].item(), cutmix_box1[1].item(), \
                             cutmix_box1[2].item(), cutmix_box1[3].item()

            cutmix_box1 = torch.zeros((B, 1, H, W), device=img_u_s1.device, dtype=torch.float32)
            cutmix_box2 = torch.zeros((B, 1, H, W), device=img_u_s1.device, dtype=torch.float32)

            x1, y1 = max(0, int(x1 * W)), max(0, int(y1 * H))
            x2, y2 = min(W, int(x2 * W)), min(H, int(y2 * H))

            cutmix_box1[:, :, y1:y2, x1:x2] = 1.0
            cutmix_box2[:, :, y1:y2, x1:x2] = 1.0

        elif len(cutmix_box1.shape) == 2:

            cutmix_box1 = cutmix_box1.unsqueeze(0).unsqueeze(0).float()
            cutmix_box2 = cutmix_box2.unsqueeze(0).unsqueeze(0).float()

            if cutmix_box1.shape[-2:] != (H, W):
                cutmix_box1 = F.interpolate(cutmix_box1, size=(H, W), mode='nearest')
                cutmix_box2 = F.interpolate(cutmix_box2, size=(H, W), mode='nearest')

            cutmix_box1 = cutmix_box1.expand(B, -1, -1, -1)
            cutmix_box2 = cutmix_box2.expand(B, -1, -1, -1)

        elif len(cutmix_box1.shape) == 3:

            cutmix_box1 = cutmix_box1.unsqueeze(1).float()
            cutmix_box2 = cutmix_box2.unsqueeze(1).float()

            if cutmix_box1.shape[-2:] != (H, W):
                cutmix_box1 = F.interpolate(cutmix_box1, size=(H, W), mode='nearest')
                cutmix_box2 = F.interpolate(cutmix_box2, size=(H, W), mode='nearest')

        img_u_s1 = img_u_s1 * (1 - cutmix_box1) + img_u_s1_mix * cutmix_box1
        img_u_s2 = img_u_s2 * (1 - cutmix_box2) + img_u_s2_mix * cutmix_box2
        model.train()

        optimizer.zero_grad()

        num_lb, num_ulb = img_x.shape[0], img_u_w.shape[0]

        preds, preds_fp = model(torch.cat((img_x, img_u_w)), True)
        pred_x, pred_u_w = preds.split([num_lb, num_ulb])
        pred_u_w_fp = preds_fp[num_lb:]

        pred_x2 = model(img_x2)

        if img_u_s1.shape[1] != img_u_s2.shape[1]:
            if img_u_s1.shape[1] == 4 and img_u_s2.shape[1] == 3:
                img_u_s1 = img_u_s1[:, :3, :, :]
            elif img_u_s1.shape[1] == 3 and img_u_s2.shape[1] == 4:
                img_u_s2 = img_u_s2[:, :3, :, :]

        preds = model(torch.cat((img_u_s1, img_u_s2)))
        pred_u_s1, pred_u_s2 = preds.chunk(2)

        pred_u_w = pred_u_w.detach()
        conf_u_w = pred_u_w.softmax(dim=1).max(dim=1)[0]
        mask_u_w = pred_u_w.argmax(dim=1)

        mask_u_w_cutmixed1, conf_u_w_cutmixed1 = mask_u_w.clone(), conf_u_w.clone()
        mask_u_w_cutmixed2, conf_u_w_cutmixed2 = mask_u_w.clone(), conf_u_w.clone()

        cutmix_box1_mask = cutmix_box1.squeeze(1) == 1
        cutmix_box2_mask = cutmix_box2.squeeze(1) == 1

        mask_u_w_cutmixed1[cutmix_box1_mask] = mask_u_w_mix[cutmix_box1_mask]
        conf_u_w_cutmixed1[cutmix_box1_mask] = conf_u_w_mix[cutmix_box1_mask]

        mask_u_w_cutmixed2[cutmix_box2_mask] = mask_u_w_mix[cutmix_box2_mask]
        conf_u_w_cutmixed2[cutmix_box2_mask] = conf_u_w_mix[cutmix_box2_mask]

        loss_x = (criterion_ce(pred_x, mask_x) + criterion_dice(pred_x.softmax(dim=1), mask_x.unsqueeze(1).float())) / 2.0

        loss_x2 = (criterion_ce(pred_x2, mask_x2) + criterion_dice(pred_x2.softmax(dim=1),
                                                                mask_x2.unsqueeze(1).float())) / 2.0
        loss_x3 = (criterion_ce(pred_x2, mask_x3) + criterion_dice(pred_x2.softmax(dim=1),
                                                                mask_x3.unsqueeze(1).float())) / 2.0

        loss_u_s1 = criterion_dice(pred_u_s1, mask_u_w_cutmixed1.unsqueeze(1).float(),
                                   ignore=(conf_u_w_cutmixed1 < 0.95).float())

        loss_u_s2 = criterion_dice(pred_u_s2, mask_u_w_cutmixed2.unsqueeze(1).float(),
                                   ignore=(conf_u_w_cutmixed2 < 0.95).float())

        loss_u_w_fp = criterion_dice(pred_u_w_fp, mask_u_w.unsqueeze(1).float(),
                                     ignore=(conf_u_w < 0.95).float())

        loss = (loss_x * 1. + loss_x2 * 0.5 + loss_x3 * 0.5 + loss_u_s1 * 0.5 + loss_u_s2 * 0.5 + loss_u_w_fp * 0.5) / 3.5

        loss.backward()
        optimizer.step()

        loss_list.append(loss.item())
        loss_x_list.append(loss_x.item())
        loss_x2_list.append(loss_x2.item())
        loss_x3_list.append(loss_x3.item())
        loss_u_s1_list.append(loss_u_s1.item())
        loss_u_s2_list.append(loss_u_s2.item())
        loss_u_w_fp_list.append(loss_u_w_fp.item())

        now_lr = optimizer.state_dict()['param_groups'][0]['lr']

        writer.add_scalar('loss', loss, global_step=step)
        writer.add_scalar('loss_x', loss_x, global_step=step)
        writer.add_scalar('loss_x2', loss_x2, global_step=step)
        writer.add_scalar('loss_x3', loss_x3, global_step=step)
        writer.add_scalar('loss_u_s1', loss_u_s1, global_step=step)
        writer.add_scalar('loss_u_s2', loss_u_s2, global_step=step)
        writer.add_scalar('loss_u_w_fp', loss_u_w_fp, global_step=step)

        if i % config.print_interval == 0:
            log_info = f'train: epoch {epoch}, iter:{i}, loss: {np.mean(loss_list):.4f}, lr: {now_lr}, loss_x:{np.mean(loss_x_list):.4f}, loss_x2:{np.mean(loss_x2_list):.4f}, loss_x3:{np.mean(loss_x3_list):.4f}, s1:{np.mean(loss_u_s1_list):.4f}, s2:{np.mean(loss_u_s2_list):.4f}, fp:{np.mean(loss_u_w_fp_list):.4f}'
            print(log_info)
            logger.info(log_info)
    scheduler.step()
    return step

def val_one_epoch(test_loader,
                    model,
                    criterion,
                    criterion_ce,
                    criterion_dice,
                    epoch,
                    logger,
                    config):

    model.eval()
    preds = []
    gts = []
    loss_list = []
    with torch.no_grad():
        for data in tqdm(test_loader,
                         mininterval=30.0,
                         maxinterval=120.0,
                         miniters=400):
            img, msk = data
            img, msk = img.cuda(non_blocking=True), msk.cuda(non_blocking=True)

            out = model(img)

            loss = criterion_ce(out, msk)

            max_logits, pred_classes = torch.max(out, dim=1, keepdim=True)

            loss_list.append(loss.item())
            gts.append(msk.squeeze(1).cpu().detach().numpy())
            if type(out) is tuple:
                out = pred_classes[0]
            out = pred_classes.squeeze(1).cpu().detach().numpy()
            preds.append(out)

    if epoch % config.val_interval == 0:
        preds = np.array(preds).reshape(-1)
        gts = np.array(gts).reshape(-1)

        y_pre = np.where(preds>=config.threshold, 1, 0)

        y_true = np.where(gts>=0.5, 1, 0)

        confusion = confusion_matrix(y_true, y_pre)
        TN, FP, FN, TP = confusion[0,0], confusion[0,1], confusion[1,0], confusion[1,1]

        accuracy = float(TN + TP) / float(np.sum(confusion)) if float(np.sum(confusion)) != 0 else 0
        sensitivity = float(TP) / float(TP + FN) if float(TP + FN) != 0 else 0
        specificity = float(TN) / float(TN + FP) if float(TN + FP) != 0 else 0
        f1_or_dsc = float(2 * TP) / float(2 * TP + FP + FN) if float(2 * TP + FP + FN) != 0 else 0
        miou = float(TP) / float(TP + FP + FN) if float(TP + FP + FN) != 0 else 0

        log_info = f'val epoch: {epoch}, loss: {np.mean(loss_list):.4f}, miou: {miou}, f1_or_dsc: {f1_or_dsc}, accuracy: {accuracy}, \
                specificity: {specificity}, sensitivity: {sensitivity}, confusion_matrix: {confusion}'
        print(log_info)
        logger.info(log_info)

    else:
        log_info = f'val epoch: {epoch}, loss: {np.mean(loss_list):.4f}'
        print(log_info)
        logger.info(log_info)

    return np.mean(loss_list)

def test_one_epoch(test_loader,
                    model,
                    criterion,
                    criterion_ce,
                    logger,
                    config,
                    test_data_name=None):

    model.eval()
    preds = []
    gts = []
    loss_list = []
    with torch.no_grad():
        for i, data in enumerate(tqdm(test_loader,
                                        mininterval=30.0,
                                        maxinterval=120.0,
                                        miniters=400)):
            img, msk = data
            img, msk = img.cuda(non_blocking=True), msk.cuda(non_blocking=True)

            out = model(img)

            loss = criterion_ce(out, msk)

            max_logits, pred_classes = torch.max(out, dim=1, keepdim=True)

            loss_list.append(loss.item())
            msk = msk.squeeze(1).cpu().detach().numpy()
            gts.append(msk)
            if type(out) is tuple:
                out = pred_classes[0]
            out = pred_classes.squeeze(1).cpu().detach().numpy()
            preds.append(out)
            if i % config.save_interval == 0:
                save_imgs(img, msk, out, i, config.work_dir + 'outputs/', config.datasets, config.threshold, test_data_name=test_data_name)

        preds = np.array(preds).reshape(-1)
        gts = np.array(gts).reshape(-1)

        y_pre = np.where(preds>=config.threshold, 1, 0)
        y_true = np.where(gts>=0.5, 1, 0)

        confusion = confusion_matrix(y_true, y_pre)
        TN, FP, FN, TP = confusion[0,0], confusion[0,1], confusion[1,0], confusion[1,1]

        accuracy = float(TN + TP) / float(np.sum(confusion)) if float(np.sum(confusion)) != 0 else 0
        sensitivity = float(TP) / float(TP + FN) if float(TP + FN) != 0 else 0
        specificity = float(TN) / float(TN + FP) if float(TN + FP) != 0 else 0
        f1_or_dsc = float(2 * TP) / float(2 * TP + FP + FN) if float(2 * TP + FP + FN) != 0 else 0
        miou = float(TP) / float(TP + FP + FN) if float(TP + FP + FN) != 0 else 0

        if test_data_name is not None:
            log_info = f'test_datasets_name: {test_data_name}'
            print(log_info)
            logger.info(log_info)
        log_info = f'test of best model, loss: {np.mean(loss_list):.4f},miou: {miou}, f1_or_dsc: {f1_or_dsc}, accuracy: {accuracy}, \
                specificity: {specificity}, sensitivity: {sensitivity}, confusion_matrix: {confusion}'
        print(log_info)
        logger.info(log_info)

    return np.mean(loss_list)

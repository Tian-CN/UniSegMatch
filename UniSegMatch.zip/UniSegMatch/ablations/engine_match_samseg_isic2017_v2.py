import numpy as np
from tqdm import tqdm
import torch
from sklearn.metrics import confusion_matrix

from engine_match_samseg_isic2017 import train_one_epoch
from utils import save_imgs

def _prepare_targets_for_ce(msk: torch.Tensor) -> torch.Tensor:
    if msk.dim() == 4 and msk.size(1) == 1:
        msk = msk.squeeze(1)
    return msk.long()

def _prepare_probs(out: torch.Tensor) -> torch.Tensor:
    if out.dim() == 4 and out.size(1) == 2:
        return torch.softmax(out, dim=1)[:, 1:2]
    if out.dim() == 4 and out.size(1) == 1:
        return torch.sigmoid(out)
    raise ValueError(f"Unexpected output shape: {tuple(out.shape)}")

def val_one_epoch(test_loader,
                  model,
                  criterion,
                  criterion_ce,
                  criterion_dice,
                  epoch,
                  logger,
                  config):
    model.eval()
    preds = []
    gts = []
    loss_list = []

    with torch.no_grad():
        for data in tqdm(test_loader,
                         mininterval=30.0,
                         maxinterval=120.0,
                         miniters=400):
            img, msk = data
            img, msk = img.cuda(non_blocking=True), msk.cuda(non_blocking=True)

            out = model(img)
            if isinstance(out, tuple):
                out = out[0]

            target = _prepare_targets_for_ce(msk)
            loss = criterion_ce(out, target)
            loss_list.append(loss.item())

            probs = _prepare_probs(out)
            preds.append(probs.squeeze(1).cpu().numpy())
            gts.append(msk.squeeze(1).cpu().numpy())

    if epoch % config.val_interval == 0:
        preds = np.array(preds).reshape(-1)
        gts = np.array(gts).reshape(-1)

        y_pre = np.where(preds >= config.threshold, 1, 0)
        y_true = np.where(gts >= 0.5, 1, 0)

        confusion = confusion_matrix(y_true, y_pre)
        TN, FP, FN, TP = confusion[0, 0], confusion[0, 1], confusion[1, 0], confusion[1, 1]

        accuracy = float(TN + TP) / float(np.sum(confusion)) if float(np.sum(confusion)) != 0 else 0
        sensitivity = float(TP) / float(TP + FN) if float(TP + FN) != 0 else 0
        specificity = float(TN) / float(TN + FP) if float(TN + FP) != 0 else 0
        f1_or_dsc = float(2 * TP) / float(2 * TP + FP + FN) if float(2 * TP + FP + FN) != 0 else 0
        miou = float(TP) / float(TP + FP + FN) if float(TP + FP + FN) != 0 else 0

        log_info = f'val epoch: {epoch}, loss: {np.mean(loss_list):.4f}, miou: {miou}, f1_or_dsc: {f1_or_dsc}, accuracy: {accuracy}, \
                specificity: {specificity}, sensitivity: {sensitivity}, confusion_matrix: {confusion}'
        print(log_info)
        logger.info(log_info)
    else:
        log_info = f'val epoch: {epoch}, loss: {np.mean(loss_list):.4f}'
        print(log_info)
        logger.info(log_info)

    return np.mean(loss_list)

def test_one_epoch(test_loader,
                   model,
                   criterion,
                   criterion_ce,
                   logger,
                   config,
                   test_data_name=None):
    model.eval()
    preds = []
    gts = []
    loss_list = []

    with torch.no_grad():
        for i, data in enumerate(tqdm(test_loader,
                                     mininterval=30.0,
                                     maxinterval=120.0,
                                     miniters=400)):
            img, msk = data
            img, msk = img.cuda(non_blocking=True), msk.cuda(non_blocking=True)

            out = model(img)
            if isinstance(out, tuple):
                out = out[0]

            target = _prepare_targets_for_ce(msk)
            loss = criterion_ce(out, target)
            loss_list.append(loss.item())

            probs = _prepare_probs(out)
            out_bin = (probs >= config.threshold).float().squeeze(1).cpu().numpy()

            msk_np = msk.squeeze(1).cpu().numpy()
            preds.append(out_bin)
            gts.append(msk_np)

            if i % config.save_interval == 0:
                save_imgs(img, msk_np, out_bin, i, config.work_dir + 'outputs/', config.datasets, config.threshold,
                          test_data_name=test_data_name)

        preds = np.array(preds).reshape(-1)
        gts = np.array(gts).reshape(-1)

        y_pre = np.where(preds >= config.threshold, 1, 0)
        y_true = np.where(gts >= 0.5, 1, 0)

        confusion = confusion_matrix(y_true, y_pre)
        TN, FP, FN, TP = confusion[0, 0], confusion[0, 1], confusion[1, 0], confusion[1, 1]

        accuracy = float(TN + TP) / float(np.sum(confusion)) if float(np.sum(confusion)) != 0 else 0
        sensitivity = float(TP) / float(TP + FN) if float(TP + FN) != 0 else 0
        specificity = float(TN) / float(TN + FP) if float(TN + FP) != 0 else 0
        f1_or_dsc = float(2 * TP) / float(2 * TP + FP + FN) if float(2 * TP + FP + FN) != 0 else 0
        miou = float(TP) / float(TP + FP + FN) if float(TP + FP + FN) != 0 else 0

        if test_data_name is not None:
            log_info = f'test_datasets_name: {test_data_name}'
            print(log_info)
            logger.info(log_info)

        log_info = f'test of best model, loss: {np.mean(loss_list):.4f},miou: {miou}, f1_or_dsc: {f1_or_dsc}, accuracy: {accuracy}, \
                specificity: {specificity}, sensitivity: {sensitivity}, confusion_matrix: {confusion}'
        print(log_info)
        logger.info(log_info)

    return np.mean(loss_list)

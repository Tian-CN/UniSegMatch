import argparse
import csv
import hashlib
import json
import logging
import math
import os
from pathlib import Path
import random
import shutil
import sys
import time
from types import SimpleNamespace

import numpy as np
import torch
from torch.utils.data import DataLoader, Subset
from tensorboardX import SummaryWriter

from datasets.dataset_ablation import USXiongNPYDataset
from engine_ablation import train_one_epoch, _get_samseg_keep_mask, _get_samseg_target_and_keep, _conf_to_soft_weight
from models.vmunet.swinvmunet_match_v2 import VMUNet
from util_match.utils import DiceLoss

ROOT = Path(__file__).resolve().parent.parent
VARIANTS = ['full', 'seggpt_only', 'sam_only', 'no_gating', 'agreement_only', 'boundary_only', 'no_confidence']
METRICS = ['miou', 'dsc', 'accuracy', 'precision', 'sensitivity', 'specificity']

def atomic_json(path, obj):
    temp = path.with_suffix(path.suffix + '.tmp')
    temp.write_text(json.dumps(obj, indent=2, allow_nan=False))
    os.replace(temp, path)

def config_for(variant, epochs=10):
    return SimpleNamespace(
        variant=variant, epochs=epochs, crop_size=256,
        loss_use_dice=True, loss_weight_x=1.0,
        loss_weight_x2=0.05, loss_weight_x3=0.05,
        loss_weight_u_s1=0.25, loss_weight_u_s2=0.25, loss_weight_u_fp=0.25,
        loss_normalize_by_weight_sum=True, samseg_boundary_ks=11,
        samseg_min_keep_ratio=0.0,
        samseg_weight_ramp_enable=True, samseg_weight_start=0.2,
        samseg_weight_end=1.0, samseg_weight_warmup_epochs=2, samseg_weight_ramp_epochs=8,
        ssl_weight_ramp_enable=True, ssl_weight_start=0.2, ssl_weight_end=1.0,
        ssl_weight_warmup_epochs=2, ssl_weight_ramp_epochs=8,
        ssl_min_keep_ratio=0.02, ssl_adapt_max_drop=0.07,
        ssl_weighting_mode='soft', ssl_soft_margin=0.05,
        ssl_agree_enable=True, ssl_agree_fp_enable=False,
        ssl_agree_foreground_only=True, ssl_agree_min_weight=0.2,
        conf_threshold=0.90, conf_threshold_schedule=True,
        conf_threshold_start=0.95, conf_threshold_end=0.90,
        conf_threshold_warmup_epochs=5, conf_threshold_ramp_epochs=20,
        print_interval=20, max_steps=0,
    )

def check_storage():
    for path, gib in [(str(ROOT), 40)]:
        if shutil.disk_usage(path).free < gib * 1024**3:
            raise RuntimeError('Storage reserve reached: ' + path)

def seed_all(seed):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.benchmark = False
    torch.backends.cudnn.deterministic = True

def make_loaders(cfg, regime, fold, workers, smoke):
    path = str(ROOT / 'US_DATA' / f'train{regime}_other_test_samseg_1by1' / f'S{fold}')

    labeled = USXiongNPYDataset(path, cfg, train_l=True)
    pseudo = USXiongNPYDataset(path, cfg, train_l=True, samseg=True)
    unlabeled = USXiongNPYDataset(path, cfg, train_u=True)
    evaluation = USXiongNPYDataset(path, cfg, Valtest=True)
    sizes = {'labeled': len(labeled), 'pseudo': len(pseudo), 'unlabeled': len(unlabeled), 'evaluation': len(evaluation)}
    if smoke:
        labeled, pseudo, unlabeled, evaluation = [Subset(d, list(range(min(2, len(d))))) for d in (labeled, pseudo, unlabeled, evaluation)]
    def loader(d, shuffle, batch=2, drop=False):
        return DataLoader(d, batch_size=batch, shuffle=shuffle, num_workers=workers,
                          pin_memory=True, drop_last=drop)
    loaders = [loader(labeled, True), loader(pseudo, True), loader(unlabeled, True),
               loader(unlabeled, False, drop=True)]
    if min(map(len, loaders)) < 1:
        raise RuntimeError('Empty training stream')
    return loaders, loader(evaluation, False, batch=1), sizes

@torch.no_grad()
def evaluate(model, loader):
    model.eval()
    cm = torch.zeros(4, dtype=torch.int64, device='cuda')
    for x, y in loader:
        logits = model(x.cuda(non_blocking=True))
        if not torch.isfinite(logits).all():
            raise FloatingPointError('Non-finite evaluation logits')
        pred = logits.argmax(1)
        code = y.cuda(non_blocking=True).flatten() * 2 + pred.flatten()
        cm += torch.bincount(code, minlength=4)
    tn, fp, fn, tp = map(int, cm.cpu().tolist())
    def ratio(n, d):
        return n / d if d else 0.0
    return dict(miou=ratio(tp,tp+fp+fn), dsc=ratio(2*tp,2*tp+fp+fn),
                accuracy=ratio(tp+tn,tp+tn+fp+fn), precision=ratio(tp,tp+fp),
                sensitivity=ratio(tp,tp+fn), specificity=ratio(tn,tn+fp),
                confusion=[tn,fp,fn,tp])

def aggregate(out):
    rows = []
    for regime in (1,20):
        for variant in VARIANTS:
            items = []
            for fold in range(25):
                p = out / f'train{regime}' / f'S{fold:02d}' / variant / 'complete.json'
                if p.exists():
                    items.append(json.loads(p.read_text()))
            if not items:
                continue
            row = dict(regime=regime,variant=variant,n=len(items),expected_n=25,complete=len(items)==25)
            for metric in METRICS:
                vals = np.array([x['metrics'][metric] for x in items])
                row[metric+'_mean'] = float(vals.mean())
                row[metric+'_std_population'] = float(vals.std(ddof=0))
                row[metric+'_std_sample'] = float(vals.std(ddof=1)) if len(vals)>1 else None
                final_vals = np.array([x['final']['metrics'][metric] for x in items])
                row['final_'+metric+'_mean'] = float(final_vals.mean())
                row['final_'+metric+'_std_population'] = float(final_vals.std(ddof=0))
                row['final_'+metric+'_std_sample'] = float(final_vals.std(ddof=1)) if len(vals)>1 else None
            rows.append(row)
    atomic_json(out/'summary.json', rows)
    if rows:
        tmp = out/'summary.csv.tmp'
        with tmp.open('w', newline='') as f:
            writer = csv.DictWriter(f, fieldnames=list(rows[0]))
            writer.writeheader()
            writer.writerows(rows)
        os.replace(tmp, out/'summary.csv')

def record_best_table(out):
    pass
    rows = []
    for p in sorted(out.glob('train*/S*/*/best.json')):
        best = json.loads(p.read_text())
        last = json.loads((p.parent/'last.json').read_text())
        rows.append(dict(regime=int(p.parents[2].name[5:]), fold=int(p.parents[1].name[1:]),
                         variant=p.parent.name, completed=(p.parent/'complete.json').exists(),
                         best_epoch=best['epoch'], **{m:best['metrics'][m] for m in METRICS},
                         last_epoch=last['epoch'], **{'last_'+m:last['metrics'][m] for m in METRICS}))
    if rows:
        temp = out/'best_by_fold.csv.tmp'
        with temp.open('w', newline='') as f:
            writer = csv.DictWriter(f, fieldnames=list(rows[0]))
            writer.writeheader()
            writer.writerows(rows)
        os.replace(temp, out/'best_by_fold.csv')

def run_one(args, regime, fold, variant):
    check_storage()
    out = Path(args.output).resolve()
    folder = out/f'train{regime}'/f'S{fold:02d}'/variant
    folder.mkdir(parents=True, exist_ok=True)
    if (folder/'complete.json').exists():
        print('SKIP completed', folder, flush=True)
        return
    seed_all(42)
    cfg = config_for(variant, 1 if args.smoke else args.epochs)
    cfg.max_steps = 1 if args.smoke else 0
    loaders, ev, sizes = make_loaders(cfg,regime,fold,args.workers,args.smoke)
    protocol = dict(vars(cfg), regime=regime, fold=fold, seed=42, sizes=sizes,
                    optimizer='AdamW', lr=1e-4, weight_decay=1e-2, cosine_T_max=50,
                    eta_min=1e-5, batch_size=2, ema=False, model='swinvmunet_match_v2',
                    init='vmamba_small_e238_ema.pth', depths=[2,2,2,2], depths_decoder=[2,2,2,1],
                    preprocessing='v5 grayscale RGB /255; bilinear image, nearest mask',
                    augmentation='v5 photometric only + spatially aligned CutMix',
                    pl_fusion='equal-weight dual loss; same-label losses coincide under agreement',
                    pl_confidence_gate=False, boundary_source='SegGPT',
                    epoch_steps=min(map(len,loaders)),
                    selection='maximum evaluation foreground IoU over epochs; target-unlabeled protocol',
                    historical_reproduction=False, smoke=args.smoke)
    p = folder/'config.json'
    if p.exists() and json.loads(p.read_text()) != protocol:
        raise RuntimeError('Configuration mismatch in existing run: ' + str(folder))
    atomic_json(p,protocol)
    logger=logging.getLogger('ablation')
    logger.setLevel(logging.INFO)
    handler=logging.FileHandler(folder/'train.log')
    handler.setFormatter(logging.Formatter('%(asctime)s %(message)s'))
    logger.addHandler(handler)
    writer=SummaryWriter(str(folder/'tensorboard'))
    model=VMUNet(num_classes=2,input_channels=3,depths=[2,2,2,2],depths_decoder=[2,2,2,1],drop_path_rate=0.2,
                  load_ckpt_path=str(ROOT/'pre_trained_weights/vmamba_small_e238_ema.pth'))
    model.load_from()
    model=model.cuda()
    optimizer=torch.optim.AdamW(model.parameters(),lr=1e-4,weight_decay=1e-2)
    scheduler=torch.optim.lr_scheduler.CosineAnnealingLR(optimizer,T_max=50,eta_min=1e-5)
    best=None; step=0; start=1
    latest=folder/'latest.pth'
    if latest.exists():
        state=torch.load(latest,map_location='cpu')
        model.load_state_dict(state['model']);optimizer.load_state_dict(state['optimizer']);scheduler.load_state_dict(state['scheduler'])
        best=state['best'];step=state['step'];start=state['epoch']+1
        random.setstate(state['random']);np.random.set_state(state['numpy']);torch.set_rng_state(state['torch'])
        torch.cuda.set_rng_state_all(state['cuda'])
        del state
    criterion_ce=torch.nn.CrossEntropyLoss();criterion_dice=DiceLoss(n_classes=2)
    try:
        for epoch in range(start,cfg.epochs+1):
            check_storage();t=time.time();torch.cuda.reset_peak_memory_stats()
            step=train_one_epoch(*loaders, best['metrics']['miou'] if best else 0.,criterion_ce,criterion_dice,None,
                                 model,None,optimizer,scheduler,epoch,step,logger,cfg,writer)
            metrics=evaluate(model,ev)
            row=dict(epoch=epoch,metrics=metrics,train=model._last_train_stats,
                     elapsed_seconds=time.time()-t,peak_gpu_bytes=torch.cuda.max_memory_allocated())
            atomic_json(folder/f'epoch_{epoch:02d}.json',row)
            atomic_json(folder/'last.json',row)
            if best is None or metrics['miou']>best['metrics']['miou']:
                best=dict(epoch=epoch,metrics=metrics)
                torch.save(model.state_dict(),folder/'best.pth.tmp');os.replace(folder/'best.pth.tmp',folder/'best.pth')
                atomic_json(folder/'best.json',best)
            record_best_table(out)
            for name in METRICS:
                writer.add_scalar('evaluation/'+name, metrics[name], epoch)
            writer.add_scalar('evaluation/best_miou', best['metrics']['miou'], epoch)
            state=dict(model=model.state_dict(),optimizer=optimizer.state_dict(),scheduler=scheduler.state_dict(),
                       best=best,step=step,epoch=epoch,random=random.getstate(),numpy=np.random.get_state(),
                       torch=torch.get_rng_state(),cuda=torch.cuda.get_rng_state_all())
            torch.save(state,folder/'latest.pth.tmp');os.replace(folder/'latest.pth.tmp',latest)
            logger.info('EPOCH_RESULT %s',json.dumps(row));writer.flush()
            print(f'TRAIN{regime} S{fold:02d} {variant} epoch={epoch} miou={metrics["miou"]:.6f} best={best["metrics"]["miou"]:.6f} best_epoch={best["epoch"]} seconds={row["elapsed_seconds"]:.1f} metrics={json.dumps(metrics)}',flush=True)
            atomic_json(out/'status.json',dict(status='running',regime=regime,fold=fold,variant=variant,epoch=epoch,best=best))
        atomic_json(folder/'complete.json',dict(best,regime=regime,fold=fold,variant=variant,
                                               final=json.loads((folder/'last.json').read_text()),
                                               stop_reason='planned_epochs_completed'))
        record_best_table(out)
        latest.unlink(missing_ok=True)
    finally:
        writer.close();logger.removeHandler(handler);handler.close()

def main():
    torch.set_num_threads(4)
    p=argparse.ArgumentParser()
    p.add_argument('--regimes',nargs='+',type=int,default=[1],choices=[1,20])
    p.add_argument('--folds',nargs='+',type=int,default=list(range(25)))
    p.add_argument('--variants',nargs='+',choices=VARIANTS,default=[v for v in VARIANTS if v != 'full'])
    p.add_argument('--epochs',type=int,default=10)
    p.add_argument('--workers',type=int,default=2)
    p.add_argument('--output',default=str(ROOT/'runs'))
    p.add_argument('--smoke',action='store_true')
    args=p.parse_args()
    if any(f<0 or f>24 for f in args.folds):p.error('folds must be 0..24')
    if args.smoke and Path(args.output).resolve()==(ROOT/'runs').resolve():p.error('smoke needs separate output')
    os.chdir(ROOT);out=Path(args.output).resolve();out.mkdir(parents=True,exist_ok=True)
    import fcntl
    lock=(out/'run.lock').open('w')
    fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
    atomic_json(out/'plan.json',dict(regimes=args.regimes,folds=args.folds,variants=args.variants,epochs=args.epochs,smoke=args.smoke))
    hashes={str(f.relative_to(ROOT)):hashlib.sha256(f.read_bytes()).hexdigest() for f in ROOT.rglob('*.py') if 'runs' not in f.parts}
    manifest=out/'code_manifest.json'
    if manifest.exists() and json.loads(manifest.read_text())!=hashes:raise RuntimeError('Code changed since run creation; use a new output directory')
    atomic_json(manifest,hashes)
    try:
        for fold in args.folds:
            for regime in args.regimes:
                for variant in args.variants:
                    run_one(args,regime,fold,variant)
                    aggregate(out)
                    torch.cuda.empty_cache()
        atomic_json(out/'status.json',dict(status='complete'))
    except Exception as exc:
        atomic_json(out/'status.json',dict(status='failed',error=repr(exc)))
        raise

if __name__=='__main__':main()

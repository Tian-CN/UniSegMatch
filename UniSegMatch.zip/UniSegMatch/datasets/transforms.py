"""Augmentation helpers used by the training loaders."""

import random

import numpy as np
import torch


def obtain_cutmix_box(
    img_size: int,
    p: float = 0.5,
    size_min: float = 0.02,
    size_max: float = 0.4,
    ratio_1: float = 0.3,
    ratio_2: float = 1 / 0.3,
) -> torch.Tensor:
    """Sample a square CutMix mask."""
    mask = torch.zeros(img_size, img_size)
    if random.random() > p:
        return mask

    area = np.random.uniform(size_min, size_max) * img_size * img_size
    while True:
        ratio = np.random.uniform(ratio_1, ratio_2)
        cutmix_w = int(np.sqrt(area / ratio))
        cutmix_h = int(np.sqrt(area * ratio))
        x = np.random.randint(0, img_size)
        y = np.random.randint(0, img_size)
        if x + cutmix_w <= img_size and y + cutmix_h <= img_size:
            break

    mask[y : y + cutmix_h, x : x + cutmix_w] = 1
    return mask

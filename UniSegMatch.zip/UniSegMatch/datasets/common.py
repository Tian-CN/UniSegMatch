from __future__ import annotations

from pathlib import Path
from typing import Iterable

import numpy as np


REPO_ROOT = Path(__file__).resolve().parents[1]


def load_path_array(path: str | Path, split_dir: str | Path) -> np.ndarray:
    """Load a path manifest and resolve entries to usable filesystem paths."""
    arr = np.load(str(path), allow_pickle=True)
    return normalize_path_array(arr, split_dir)


def normalize_path_array(arr: Iterable[object], split_dir: str | Path) -> np.ndarray:
    split_dir = Path(split_dir).resolve()
    out: list[str] = []
    for value in arr:
        if value is None:
            out.append("")
            continue
        out.append(resolve_manifest_path(str(value), split_dir))
    return np.asarray(out, dtype=object)


def resolve_manifest_path(value: str, split_dir: Path) -> str:
    """Resolve absolute, repository-relative, and split-relative manifest paths."""
    raw = value.strip().replace("\\", "/")
    if not raw:
        return ""

    p = Path(raw)
    candidates: list[Path] = []

    if p.is_absolute():
        candidates.append(p)
    else:
        clean = raw[2:] if raw.startswith("./") else raw
        candidates.extend(
            [
                (REPO_ROOT / clean),
                (split_dir / clean),
                (Path.cwd() / clean),
            ]
        )

    # Also support manifests whose paths contain a /data/ segment.
    marker = "/data/"
    normalized = "/" + raw.lstrip("/")
    if marker in normalized:
        suffix = normalized.split(marker, 1)[1]
        candidates.insert(0, REPO_ROOT / "data" / suffix)

    for candidate in candidates:
        if candidate.exists():
            return str(candidate.resolve())

    if candidates:
        return str(candidates[0].resolve())
    return raw


def require_same_length(**arrays: np.ndarray) -> None:
    lengths = {name: len(arr) for name, arr in arrays.items()}
    if len(set(lengths.values())) != 1:
        raise ValueError(f"Split arrays have inconsistent lengths: {lengths}")

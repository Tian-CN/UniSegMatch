import os
import random

import numpy as np
import torch
from PIL import Image, ImageEnhance, ImageOps
from torch.utils.data import Dataset

from datasets.transform import obtain_cutmix_box

class ISIC2017NPYDataset(Dataset):
    def __init__(
        self,
        path_Data,
        config,
        train_l=False,
        train_u=False,
        Valtest=False,
        nsample=None,
        samseg=False,
    ):
        super().__init__()
        self.size = getattr(config, 'crop_size', 256)
        if isinstance(self.size, (tuple, list)):
            self.size = int(self.size[0])
        self.train_l = train_l
        self.train_u = train_u
        self.Valtest = Valtest
        self.samseg = samseg

        if self.train_l:
            if self.samseg:
                self.data = np.load(os.path.join(path_Data, 'data_test.npy'), allow_pickle=True)
                self.mask2 = np.load(os.path.join(path_Data, 'mask2_test.npy'), allow_pickle=True)
                self.mask3 = np.load(os.path.join(path_Data, 'mask3_test.npy'), allow_pickle=True)
                if nsample is not None:
                    self.data = self.data.repeat(int(np.ceil(nsample / len(self.data))), axis=0)[:nsample]
                    self.mask2 = self.mask2.repeat(int(np.ceil(nsample / len(self.mask2))), axis=0)[:nsample]
                    self.mask3 = self.mask3.repeat(int(np.ceil(nsample / len(self.mask3))), axis=0)[:nsample]
            else:
                self.data = np.load(os.path.join(path_Data, 'data_train.npy'), allow_pickle=True)
                self.mask = np.load(os.path.join(path_Data, 'mask_train.npy'), allow_pickle=True)

                if nsample is not None:
                    self.data = self.data.repeat(int(np.ceil(nsample / len(self.data))), axis=0)[:nsample]
                    self.mask = self.mask.repeat(int(np.ceil(nsample / len(self.mask))), axis=0)[:nsample]

        else:
            if self.train_u:
                self.data = np.load(os.path.join(path_Data, 'data_test.npy'), allow_pickle=True)
                self.mask = np.load(os.path.join(path_Data, 'mask_test.npy'), allow_pickle=True)

                if nsample is not None:
                    self.data = self.data.repeat(int(np.ceil(nsample / len(self.data))), axis=0)[:nsample]
                    self.mask = self.mask.repeat(int(np.ceil(nsample / len(self.mask))), axis=0)[:nsample]
            else:
                self.data = np.load(os.path.join(path_Data, 'data_test.npy'), allow_pickle=True)
                self.mask = np.load(os.path.join(path_Data, 'mask_test.npy'), allow_pickle=True)

        if self.train_l and self.samseg:
            self.mask2 = self._normalize_path_array(self.mask2)
            self.mask3 = self._normalize_path_array(self.mask3)
        else:
            self.data = self._normalize_path_array(self.data)
            self.mask = self._normalize_path_array(self.mask)

    @staticmethod
    def _normalize_path_array(arr):

        if arr is None:
            return arr
        out = []
        for x in arr:
            if x is None:
                out.append('')
                continue
            s = str(x)
            out.append(s.replace('\\\\', '/'))
        return np.asarray(out, dtype=object)

    def __len__(self):
        return len(self.data)

    def _load_rgb(self, path: str) -> Image.Image:
        return Image.open(path).convert('RGB')

    def _load_mask(self, path: str) -> np.ndarray:
        m = Image.open(path).convert('L')
        m = m.resize((self.size, self.size), resample=Image.NEAREST)
        m = np.array(m)
        m = (m > 0).astype(np.uint8)
        return m

    def _img_to_tensor(self, img: Image.Image) -> torch.Tensor:
        img = img.resize((self.size, self.size), resample=Image.BILINEAR)
        arr = np.array(img).astype(np.float32) / 255.0
        arr = np.transpose(arr, (2, 0, 1))
        return torch.from_numpy(arr)

    def _strong_aug(self, img: Image.Image) -> Image.Image:
        if random.random() < 0.5:
            img = ImageOps.mirror(img)
        if random.random() < 0.5:
            img = ImageOps.flip(img)

        if random.random() < 0.8:
            img = ImageEnhance.Brightness(img).enhance(random.uniform(0.7, 1.3))
        if random.random() < 0.8:
            img = ImageEnhance.Contrast(img).enhance(random.uniform(0.7, 1.3))
        if random.random() < 0.8:
            img = ImageEnhance.Color(img).enhance(random.uniform(0.7, 1.3))

        return img

    def __getitem__(self, indx):
        img_path = str(self.data[indx])

        img = self._load_rgb(img_path)

        if self.Valtest:
            mask_path = str(self.mask[indx])
            m = self._load_mask(mask_path)
            return self._img_to_tensor(img).float(), torch.from_numpy(m).long()

        if self.train_l:
            if self.samseg:
                m2 = self._load_mask(str(self.mask2[indx]))
                m3 = self._load_mask(str(self.mask3[indx]))
                return (
                    self._img_to_tensor(img).float(),
                    torch.from_numpy(m2).long(),
                    torch.from_numpy(m3).long(),
                )
            else:
                mask_path = str(self.mask[indx])
                m = self._load_mask(mask_path)
                return self._img_to_tensor(img).float(), torch.from_numpy(m).long()

        img_w = self._img_to_tensor(img).float()
        img_s1 = self._img_to_tensor(self._strong_aug(img.copy())).float()
        img_s2 = self._img_to_tensor(self._strong_aug(img.copy())).float()
        cutmix_box1 = obtain_cutmix_box(self.size, p=0.5)
        cutmix_box2 = obtain_cutmix_box(self.size, p=0.5)

        return img_w, img_s1, img_s2, cutmix_box1, cutmix_box2

from torch.utils.data import Dataset
import numpy as np
import os
from PIL import Image

import random
import h5py
import torch
from scipy import ndimage
from scipy.ndimage.interpolation import zoom
from torch.utils.data import Dataset
from scipy import ndimage
from PIL import Image, ImageOps, ImageEnhance

import cv2
from datasets.transform import random_rot_flip, random_rotate, blur, obtain_cutmix_box
from torchvision import transforms
from copy import deepcopy
import math
class NPY_datasets(Dataset):
    def __init__(self, path_Data, config, train=True):
        super(NPY_datasets, self)
        if train:
            images_list = sorted(os.listdir(path_Data+'train/images/'))
            masks_list = sorted(os.listdir(path_Data+'train/masks/'))
            self.data = []
            for i in range(len(images_list)):
                img_path = path_Data+'train/images/' + images_list[i]
                mask_path = path_Data+'train/masks/' + masks_list[i]
                self.data.append([img_path, mask_path])
            self.transformer = config.train_transformer
        else:
            images_list = sorted(os.listdir(path_Data+'val/images/'))
            masks_list = sorted(os.listdir(path_Data+'val/masks/'))
            self.data = []
            for i in range(len(images_list)):
                img_path = path_Data+'val/images/' + images_list[i]
                mask_path = path_Data+'val/masks/' + masks_list[i]
                self.data.append([img_path, mask_path])
            self.transformer = config.test_transformer

    def __getitem__(self, indx):
        img_path, msk_path = self.data[indx]
        img = np.array(Image.open(img_path).convert('RGB'))
        msk = np.expand_dims(np.array(Image.open(msk_path).convert('L')), axis=2) / 255
        img, msk = self.transformer((img, msk))
        return img, msk

    def __len__(self):
        return len(self.data)

def random_rot_flip(image, label):
    k = np.random.randint(0, 4)
    image = np.rot90(image, k)
    label = np.rot90(label, k)
    axis = np.random.randint(0, 2)
    image = np.flip(image, axis=axis).copy()
    label = np.flip(label, axis=axis).copy()
    return image, label

def random_rotate(image, label):
    angle = np.random.randint(-20, 20)
    image = ndimage.rotate(image, angle, order=0, reshape=False)
    label = ndimage.rotate(label, angle, order=0, reshape=False)
    return image, label

class RandomGenerator(object):
    def __init__(self, output_size):
        self.output_size = output_size

    def __call__(self, sample):
        image, label = sample['image'], sample['label']

        if random.random() > 0.5:
            image, label = random_rot_flip(image, label)
        elif random.random() > 0.5:
            image, label = random_rotate(image, label)
        x, y = image.shape
        if x != self.output_size[0] or y != self.output_size[1]:
            image = zoom(image, (self.output_size[0] / x, self.output_size[1] / y), order=3)
            label = zoom(label, (self.output_size[0] / x, self.output_size[1] / y), order=0)
        image = torch.from_numpy(image.astype(np.float32)).unsqueeze(0)
        label = torch.from_numpy(label.astype(np.float32))
        sample = {'image': image, 'label': label.long()}
        return sample

class Synapse_dataset(Dataset):
    def __init__(self, base_dir, list_dir, split, transform=None):
        self.transform = transform
        self.split = split
        self.sample_list = open(os.path.join(list_dir, self.split+'.txt')).readlines()
        self.data_dir = base_dir

    def __len__(self):
        return len(self.sample_list)

    def __getitem__(self, idx):
        if self.split == "train":
            slice_name = self.sample_list[idx].strip('\n')
            data_path = os.path.join(self.data_dir, slice_name+'.npz')
            data = np.load(data_path)
            image, label = data['image'], data['label']
        else:
            vol_name = self.sample_list[idx].strip('\n')
            filepath = self.data_dir + "/{}.npy.h5".format(vol_name)
            data = h5py.File(filepath)
            image, label = data['image'][:], data['label'][:]

        sample = {'image': image, 'label': label}
        if self.transform:
            sample = self.transform(sample)
        sample['case_name'] = self.sample_list[idx].strip('\n')
        return sample

def dataset_normalized_one_image(imgs):
    imgs_normalized = np.empty(imgs.shape)
    imgs_std = np.std(imgs)
    imgs_mean = np.mean(imgs)
    imgs_normalized = (imgs - imgs_mean) / imgs_std
    imgs_normalized = ((imgs_normalized - np.min(imgs_normalized)) / (np.max(imgs_normalized)-np.min(imgs_normalized)))*255
    return imgs_normalized
class ImageEnhancer:

    def random_contrast(self, image_np, scale_range=(0.5, 2)):
        scale = np.random.uniform(*scale_range)
        mean = np.mean(image_np)
        enhanced_image = cv2.multiply(image_np, scale) + mean * (1 - scale)
        return np.clip(enhanced_image, 0, 255)

    def histogram_equalization(self, image_np):
        if image_np.dtype != np.uint8:
            image_np = image_np.astype(np.uint8)
        return cv2.equalizeHist(image_np)

    def clahe(self, image_np):

        if image_np.dtype != np.uint8:
            image_np = image_np.astype(np.uint8)

        clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8))
        return clahe.apply(image_np)

    def edge_enhancement(self, image_np):
        kernel = np.array([[-1, -1, -1], [-1, 8, -1], [-1, -1, -1]])
        enhanced_image = cv2.filter2D(image_np, -1, kernel)
        return np.clip(enhanced_image, 0, 255)

    def sharpening(self, image_np):
        kernel = np.array([[-1, -1, -1], [-1, 9, -1], [-1, -1, -1]])
        sharpened_image = cv2.filter2D(image_np, -1, kernel)
        return np.clip(sharpened_image, 0, 255)

    def morphology_closing(self, image_np, kernel_size=5):
        kernel = np.ones((kernel_size, kernel_size), np.uint8)
        closed_image = cv2.morphologyEx(image_np, cv2.MORPH_CLOSE, kernel)
        return closed_image

    def morphology_erosion(self, image_np, kernel_size=3):
        kernel = np.ones((kernel_size, kernel_size), np.uint8)
        return cv2.erode(image_np, kernel)

    def morphology_dilation(self, image_np, kernel_size=3):
        kernel = np.ones((kernel_size, kernel_size), np.uint8)
        return cv2.dilate(image_np, kernel)

    def random_enhance(self, image_np, morph_kernel_sizes=[3, 5]):
        enhancements = [
            self.random_contrast,
            self.histogram_equalization,
            self.clahe,
            self.edge_enhancement,
            self.sharpening
        ]
        chosen_enhancement = np.random.choice(enhancements)

        enhanced_image = chosen_enhancement(image_np)

        operations = ['morphology_closing', 'morphology_erosion', 'morphology_dilation']
        chosen_operation = np.random.choice(operations)
        kernel_size = random.choice(morph_kernel_sizes)
        enhanced_image = getattr(self, chosen_operation)(enhanced_image, kernel_size=kernel_size)

        return enhanced_image
class USDataset(Dataset):
    def __init__(self, path_Data, config, train_l=False, train_u=False, Valtest=False, nsample=None, samseg=False):
        super(USDataset, self)
        self.height = 256
        self.width = 256
        self.size = 256
        self.channels = 3
        self.train_l = train_l
        self.train_u = train_u
        self.Valtest = Valtest
        self.samseg = samseg
        self.transformer_T = ImageEnhancer()

        self.kernel = np.ones((3, 3), np.uint8)

        if train_l:
            if samseg:
                self.data = np.load(path_Data + 'data_train2.npy')
                self.mask = np.load(path_Data + 'mask_train2.npy')
                self.mask3 = np.load(path_Data + 'mask_train3.npy')

                self.mask3 = np.char.replace(self.mask3, "\\", "/")

                self.mask3 = np.char.replace(self.mask3, "./data", "./data")

            else:

                self.data = np.load(path_Data + 'data_train.npy')
                self.mask = np.load(path_Data + 'mask_train.npy')
                if nsample is not None:

                    self.data = self.data.repeat(math.ceil(nsample / len(self.data)), axis=0)
                    self.mask = self.mask.repeat(math.ceil(nsample / len(self.mask)), axis=0)
                    self.data = self.data[:nsample]
                    self.mask = self.mask[:nsample]

        else:
            if train_u:
                self.data = np.load(path_Data + 'data_test.npy')
                self.mask = np.load(path_Data + 'mask_test.npy')

                if nsample is not None:

                    self.data = self.data.repeat(math.ceil(nsample / len(self.data)), axis=0)
                    self.mask = self.mask.repeat(math.ceil(nsample / len(self.mask)), axis=0)
                    self.data = self.data[:nsample]
                    self.mask = self.mask[:nsample]
            else:
                self.data = np.load(path_Data + 'data_val.npy')
                self.mask = np.load(path_Data + 'mask_val.npy')

        self.data = np.char.replace(self.data, "\\", "/")
        self.mask = np.char.replace(self.mask, "\\", "/")

        self.data = np.char.replace(self.data, "./data", "./data")
        self.mask = np.char.replace(self.mask, "./data", "./data")

    def random_brightness(self, image, delta=0.2):
        enhancer = ImageEnhance.Brightness(image)
        delta = random.uniform(-delta, delta)
        return enhancer.enhance(1 + delta)

    def random_contrast(self, image, scale_range=(0.5, 2)):
        enhancer = ImageEnhance.Contrast(image)
        scale = random.uniform(*scale_range)
        return enhancer.enhance(scale)

    def random_erosion_dilation(self, image, kernel_size=3, erosion_prob=0.5):
        kernel = np.ones((kernel_size, kernel_size), np.uint8)
        if random.random() < erosion_prob:
            return Image.fromarray(cv2.erode(np.array(image), kernel))
        else:
            return Image.fromarray(cv2.dilate(np.array(image), kernel))
    def __getitem__(self, indx):
        img_path = self.data[indx]
        seg_path = self.mask[indx]

        img = Image.open(img_path).convert('L')
        img = img.resize([self.height, self.width])
        img = np.array(img)

        seg = Image.open(seg_path).convert('L')
        seg = seg.resize([self.height, self.width])
        seg = np.array(seg)

        seg[seg < 10] = 0
        seg[seg > 9] = 1

        img = dataset_normalized_one_image(img)

        if self.Valtest:
            return torch.from_numpy(img).unsqueeze(0).float(), torch.from_numpy(seg).long()

        x, y = img.shape
        img = zoom(img, (self.size / x, self.size / y), order=0)
        seg = zoom(seg, (self.size / x, self.size / y), order=0)
        if self.train_l:
            if self.samseg:
                seg_path3 = self.mask3[indx]
                seg3 = Image.open(seg_path3).convert('L')
                seg3 = seg3.resize([self.height, self.width])
                seg3 = np.array(seg3)
                seg3[seg3 < 10] = 0
                seg3[seg3 > 9] = 1
                seg3 = zoom(seg3, (self.size / x, self.size / y), order=0)

                return torch.from_numpy(img).unsqueeze(0).float(), torch.from_numpy(np.array(seg)).long(), torch.from_numpy(np.array(seg3)).long()
            else:
                return torch.from_numpy(img).unsqueeze(0).float(), torch.from_numpy(np.array(seg)).long()

        img = Image.fromarray((img).astype(np.uint8))
        img_s1, img_s2 = deepcopy(img), deepcopy(img)
        img = torch.from_numpy(np.array(img)).unsqueeze(0).float() / 255.0

        if random.random() < 0.5:
            img_s1 = ImageOps.mirror(img_s1)

        if random.random() < 0.5:
            factor = random.uniform(0.5, 1.5)
            img_s1 = ImageEnhance.Brightness(img_s1).enhance(factor)

        if random.random() < 0.5:
            factor = random.uniform(0.5, 1.5)
            img_s1 = ImageEnhance.Color(img_s1).enhance(factor)

        cutmix_box1 = obtain_cutmix_box(self.size, p=0.5)
        img_s1 = torch.from_numpy(np.array(img_s1)).unsqueeze(0).float() / 255.0

        if random.random() < 0.5:
            img_s2 = ImageOps.mirror(img_s2)

        if random.random() < 0.5:
            factor = random.uniform(0.5, 1.5)
            img_s2 = ImageEnhance.Brightness(img_s2).enhance(factor)

        if random.random() < 0.5:
            factor = random.uniform(0.5, 1.5)
            img_s2 = ImageEnhance.Color(img_s2).enhance(factor)

        if random.random() < 0.8:
            img_s2 = transforms.ColorJitter(0.5, 0.5, 0.5, 0.25)(img_s2)

        cutmix_box2 = obtain_cutmix_box(self.size, p=0.5)
        img_s2 = torch.from_numpy(np.array(img_s2)).unsqueeze(0).float() / 255.0

        return img, img_s1, img_s2, cutmix_box1, cutmix_box2

    def __len__(self):
        return len(self.data)

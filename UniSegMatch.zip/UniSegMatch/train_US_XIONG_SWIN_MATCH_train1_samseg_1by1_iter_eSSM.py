from tensorboardX import SummaryWriter
import torch
from torch.utils.data import DataLoader
import timm
from datasets.dataset_match_samseg import NPY_datasets, USDataset

from models.vmunet.vmunet_match import VMUNet

from engine_match_samseg_eSSM import *
import os
import sys

from utils import *
from configs.config_setting_US_XIONG_match_samseg_train1 import setting_config

import warnings

from util_match.utils import AverageMeter, count_params, init_log, DiceLoss

warnings.filterwarnings("ignore")

def main(config, testsubjects):

    print("testsubjects =", testsubjects)

    data_path = "US_DATA/train1_other_test_samseg_1by1/S" + str(testsubjects) + "/"

    save_path = "results/US_T/vmunet/train1_other_test_samseg_eSSM_241125_1by1_iter/S" + str(testsubjects) + "/"
    if not os.path.exists(save_path):

        os.makedirs(save_path)
        print(f"文件夹 '{save_path}' 已创建。")
    else:
        print(f"文件夹 '{save_path}' 已存在。")

    config.work_dir = save_path
    config.data_path = data_path

    print('#----------Creating logger----------#')
    sys.path.append(config.work_dir + '/')
    log_dir = os.path.join(config.work_dir, 'log')
    checkpoint_dir = os.path.join(config.work_dir, 'checkpoints')
    resume_model = os.path.join(checkpoint_dir, 'latest.pth')
    outputs = os.path.join(config.work_dir, 'outputs')
    if not os.path.exists(checkpoint_dir):
        os.makedirs(checkpoint_dir)
    if not os.path.exists(outputs):
        os.makedirs(outputs)

    global logger
    logger = get_logger('train', log_dir)
    global writer
    writer = SummaryWriter(config.work_dir + 'summary')

    log_config_info(config, logger)

    print('#----------GPU init----------#')
    os.environ["CUDA_VISIBLE_DEVICES"] = config.gpu_id
    set_seed(config.seed)
    torch.cuda.empty_cache()

    print('#----------Preparing dataset----------#')

    trainset_l_samseg = USDataset(config.data_path, config, train_l=True, train_u=False, Valtest=False,
                                  samseg=True)
    trainloader_l_samseg = DataLoader(trainset_l_samseg,
                                      batch_size=config.batch_size,
                                      shuffle=True,
                                      pin_memory=True,
                                      num_workers=config.num_workers)

    trainset_u = USDataset(config.data_path, config, train_l=False, train_u=True, Valtest=False)
    trainloader_u = DataLoader(trainset_u,
                                batch_size=config.batch_size,
                                shuffle=True,
                                pin_memory=True,
                                num_workers=config.num_workers
                                )

    trainset_l = USDataset(config.data_path, config, train_l=True, train_u=False, Valtest=False)
    trainloader_l = DataLoader(trainset_l,
                               batch_size=config.batch_size,
                               shuffle=True,
                               pin_memory=True,
                               num_workers=config.num_workers)
    trainloader_u_mix = DataLoader(trainset_u, batch_size=config.batch_size,
                                   pin_memory=True, num_workers=1, drop_last=True)

    valset = USDataset(config.data_path, config, train_l=False, train_u=False, Valtest=True)
    valloader = DataLoader(valset,
                            batch_size=1,
                            shuffle=False,
                            pin_memory=True,
                            num_workers=config.num_workers,
                            drop_last=True)

    print('#----------Prepareing Model----------#')
    model_cfg = config.model_config
    if config.network == 'vmunet':
        model = VMUNet(
            num_classes=model_cfg['num_classes'],
            input_channels=model_cfg['input_channels'],
            depths=model_cfg['depths'],
            depths_decoder=model_cfg['depths_decoder'],
            drop_path_rate=model_cfg['drop_path_rate'],
            load_ckpt_path=model_cfg['load_ckpt_path'],
        )
        model.load_from()

    else: raise Exception('network in not right!')
    model = model.cuda()

    cal_params_flops(model, 256, logger)

    print('#----------Prepareing loss, opt, sch and amp----------#')
    criterion = config.criterion
    DiceLoss2 = DiceLoss_T(wd=1)
    optimizer = get_optimizer(config, model)
    scheduler = get_scheduler(config, optimizer)

    criterion_ce = nn.CrossEntropyLoss()
    criterion_dice = DiceLoss(n_classes=2)

    print('#----------Set other params----------#')
    min_loss = 999
    start_epoch = 1
    min_epoch = 1

    total_iters = len(trainloader_u) * config.epochs
    previous_best = 0.0

    step = 0
    print('#----------Training----------#')
    for epoch in range(start_epoch, config.epochs + 1):

        torch.cuda.empty_cache()

        step = train_one_epoch(
            trainloader_l,
            trainloader_l_samseg,
            trainloader_u,
            trainloader_u_mix,
            previous_best,
            criterion_ce,
            criterion_dice,
            DiceLoss2,
            model,
            criterion,
            optimizer,
            scheduler,
            epoch,
            step,
            logger,
            config,
            writer
        )

        loss = val_one_epoch(
                valloader,
                model,
                criterion,
                criterion_ce,
                criterion_dice,
                epoch,
                logger,
                config
            )

        if loss < min_loss:
            torch.save(model.state_dict(), os.path.join(checkpoint_dir, 'best.pth'))
            min_loss = loss
            min_epoch = epoch
            print("best val_loss")

        torch.save(
            {
                'epoch': epoch,
                'min_loss': min_loss,
                'min_epoch': min_epoch,
                'loss': loss,
                'model_state_dict': model.state_dict(),
                'optimizer_state_dict': optimizer.state_dict(),
                'scheduler_state_dict': scheduler.state_dict(),
            }, os.path.join(checkpoint_dir, 'latest.pth'))

    if os.path.exists(os.path.join(checkpoint_dir, 'best.pth')):
        print('#----------Testing----------#')
        best_weight = torch.load(config.work_dir + 'checkpoints/best.pth', map_location=torch.device('cpu'))
        model.load_state_dict(best_weight)
        loss = test_one_epoch(
                valloader,
                model,
                criterion,
                criterion_ce,
                logger,
                config,
            )
        os.rename(
            os.path.join(checkpoint_dir, 'best.pth'),
            os.path.join(checkpoint_dir, f'best-epoch{min_epoch}-loss{min_loss:.4f}.pth')
        )

if __name__ == '__main__':
    config = setting_config

    for testsubjects in range(23, 25):

        main(config, testsubjects)

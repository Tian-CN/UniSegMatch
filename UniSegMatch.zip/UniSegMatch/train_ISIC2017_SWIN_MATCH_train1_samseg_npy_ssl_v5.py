import os
import sys
import warnings
import copy

import torch
from tensorboardX import SummaryWriter
from torch import nn
from torch.utils.data import DataLoader

from configs.config_setting_ISIC2017_match_samseg_npy_v5 import setting_config
from datasets.dataset_isic2017_npy_match_samseg import ISIC2017NPYDataset
from engine_match_samseg_isic2017_v5 import train_one_epoch, val_one_epoch, val_one_epoch_metrics, test_one_epoch
from models.vmunet.swinvmunet_match_v2 import VMUNet
from util_match.utils import DiceLoss as MatchDiceLoss
from utils import *

warnings.filterwarnings("ignore")

def _build_ema_model(model: torch.nn.Module) -> torch.nn.Module:
    model_ema = copy.deepcopy(model)
    for p in model_ema.parameters():
        p.requires_grad_(False)
    model_ema.eval()
    return model_ema

def main(config):
    save_path = config.work_dir
    if not os.path.exists(save_path):
        os.makedirs(save_path)

    print('#----------Creating logger----------#')
    sys.path.append(config.work_dir + '/')
    log_dir = os.path.join(config.work_dir, 'log')
    checkpoint_dir = os.path.join(config.work_dir, 'checkpoints')
    outputs = os.path.join(config.work_dir, 'outputs')
    if not os.path.exists(checkpoint_dir):
        os.makedirs(checkpoint_dir)
    if not os.path.exists(outputs):
        os.makedirs(outputs)

    logger = get_logger('train', log_dir)
    writer = SummaryWriter(config.work_dir + 'summary')

    log_config_info(config, logger)

    print('#----------GPU init----------#')
    os.environ["CUDA_VISIBLE_DEVICES"] = config.gpu_id
    set_seed(config.seed)
    torch.cuda.empty_cache()

    print('#----------Preparing dataset----------#')
    data_path = config.data_path
    if not data_path.endswith('/'):
        data_path += '/'

    trainset_l_samseg = ISIC2017NPYDataset(data_path, config, train_l=True, train_u=False, Valtest=False, samseg=True)
    trainloader_l_samseg = DataLoader(trainset_l_samseg, batch_size=config.batch_size, shuffle=True, pin_memory=True,
                                      num_workers=config.num_workers, drop_last=True)

    trainset_u = ISIC2017NPYDataset(data_path, config, train_l=False, train_u=True, Valtest=False)
    trainloader_u = DataLoader(trainset_u, batch_size=config.batch_size, shuffle=True, pin_memory=True,
                               num_workers=config.num_workers, drop_last=True)

    trainset_l = ISIC2017NPYDataset(
        data_path,
        config,
        train_l=True,
        train_u=False,
        Valtest=False,
        nsample=len(trainset_u),
        samseg=False,
    )
    trainloader_l = DataLoader(trainset_l, batch_size=config.batch_size, shuffle=True, pin_memory=True,
                               num_workers=config.num_workers, drop_last=True)

    trainloader_u_mix = DataLoader(trainset_u, batch_size=config.batch_size, pin_memory=True, num_workers=1,
                                   drop_last=True)

    valset = ISIC2017NPYDataset(data_path, config, train_l=False, train_u=False, Valtest=True)
    valloader = DataLoader(valset, batch_size=1, shuffle=False, pin_memory=True,
                           num_workers=config.num_workers, drop_last=True)

    print('#----------Prepareing Model----------#')
    model_cfg = config.model_config
    if config.network == 'vmunet':
        model = VMUNet(num_classes=model_cfg['num_classes'], input_channels=model_cfg['input_channels'],
                      depths=model_cfg['depths'], depths_decoder=model_cfg['depths_decoder'],
                      drop_path_rate=model_cfg['drop_path_rate'], load_ckpt_path=model_cfg['load_ckpt_path'])
        model.load_from()
    else:
        raise Exception('network in not right!')

    model = model.cuda()
    cal_params_flops(model, 256, logger)

    model_ema = None
    if bool(getattr(config, 'ema_teacher_enable', False)):
        model_ema = _build_ema_model(model)
        model._ema_teacher = model_ema
        logger.info(f"EMA teacher enabled: decay={float(getattr(config, 'ema_decay', 0.999))}, warmup_steps={int(getattr(config, 'ema_warmup_steps', 0))}")

    print('#----------Prepareing loss, opt, sch and amp----------#')
    criterion = config.criterion
    DiceLoss2 = DiceLoss_T(wd=1)
    optimizer = get_optimizer(config, model)
    scheduler = get_scheduler(config, optimizer)

    criterion_ce = nn.CrossEntropyLoss()
    criterion_dice = MatchDiceLoss(2)

    print('#----------Set other params----------#')
    min_loss = 999
    start_epoch = 1
    min_epoch = 1

    best_miou = -1
    best_miou_epoch = 1

    early_patience = int(getattr(config, 'early_stop_patience', 0))
    early_min_delta = float(getattr(config, 'early_stop_min_delta', 0.0))
    early_start_epoch = int(getattr(config, 'early_stop_start_epoch', 1))
    early_bad_epochs = 0

    previous_best = 0.0

    step = 0
    print('#----------Training----------#')
    for epoch in range(start_epoch, config.epochs + 1):
        torch.cuda.empty_cache()

        step = train_one_epoch(
            trainloader_l,
            trainloader_l_samseg,
            trainloader_u,
            trainloader_u_mix,
            previous_best,
            criterion_ce,
            criterion_dice,
            DiceLoss2,
            model,
            criterion,
            optimizer,
            scheduler,
            epoch,
            step,
            logger,
            config,
            writer,
            model_ema=model_ema,
        )

        loss, miou, f1_or_dsc = val_one_epoch_metrics(valloader, model, criterion, criterion_ce, criterion_dice, epoch,
                                                      logger, config)

        if loss < min_loss:
            torch.save(model.state_dict(), os.path.join(checkpoint_dir, 'best.pth'))
            min_loss = loss
            min_epoch = epoch

        if miou > best_miou:
            torch.save(model.state_dict(), os.path.join(checkpoint_dir, 'best_miou.pth'))
            best_miou = miou
            best_miou_epoch = epoch

            early_bad_epochs = 0

            last_stats = getattr(model, '_last_train_stats', None)
            if isinstance(last_stats, dict):
                best_msg = (
                    f'BEST_MIOU updated: epoch {best_miou_epoch}, '
                    f'val_miou:{best_miou:.6f}, val_loss:{loss:.4f}, val_f1:{f1_or_dsc:.6f}, '
                    f"conf_th:{last_stats.get('conf_th')}, samseg_keep:{last_stats.get('samseg_keep')}, "
                    f"ssl_keep:{last_stats.get('ssl_keep')}, ssl_w_mean:{last_stats.get('ssl_w_mean')}, "
                    f"ssl_th_eff:{last_stats.get('ssl_th_eff')}, ssl_adapt:{last_stats.get('ssl_adapt')}, "
                    f"ssl_mode:{last_stats.get('ssl_mode')}, ssl_soft_margin:{last_stats.get('ssl_soft_margin')}, "
                    f"ema_teacher:{last_stats.get('ema_teacher')}, ema_decay:{last_stats.get('ema_decay')}"
                )
            else:
                best_msg = (
                    f'BEST_MIOU updated: epoch {best_miou_epoch}, '
                    f'val_miou:{best_miou:.6f}, val_loss:{loss:.4f}, val_f1:{f1_or_dsc:.6f}'
                )

            print(best_msg)
            logger.info(best_msg)

            try:
                writer.add_scalar('best/miou', float(best_miou), global_step=epoch)
                writer.add_scalar('best/epoch', float(best_miou_epoch), global_step=epoch)
                writer.add_text('best/summary', best_msg, global_step=epoch)
                if isinstance(last_stats, dict):
                    if last_stats.get('ssl_keep') is not None:
                        writer.add_scalar('best/ssl_keep', float(last_stats.get('ssl_keep')), global_step=epoch)
                    if last_stats.get('ssl_w_mean') is not None:
                        writer.add_scalar('best/ssl_w_mean', float(last_stats.get('ssl_w_mean')), global_step=epoch)
                    if last_stats.get('samseg_keep') is not None:
                        writer.add_scalar('best/samseg_keep', float(last_stats.get('samseg_keep')), global_step=epoch)
                    if last_stats.get('conf_th') is not None:
                        writer.add_scalar('best/conf_th', float(last_stats.get('conf_th')), global_step=epoch)
                    if last_stats.get('ssl_th_eff') is not None:
                        writer.add_scalar('best/ssl_th_eff', float(last_stats.get('ssl_th_eff')), global_step=epoch)
                    if last_stats.get('ssl_adapt') is not None:
                        writer.add_scalar('best/ssl_adapt', float(last_stats.get('ssl_adapt')), global_step=epoch)
                    if last_stats.get('ema_decay') is not None:
                        writer.add_scalar('best/ema_decay', float(last_stats.get('ema_decay')), global_step=epoch)
            except Exception:
                pass

        else:
            if early_patience > 0 and epoch >= early_start_epoch:
                if float(miou) < float(best_miou) + float(early_min_delta):
                    early_bad_epochs += 1
                else:
                    early_bad_epochs = 0

        if early_patience > 0 and epoch >= early_start_epoch and early_bad_epochs >= early_patience:
            stop_msg = (
                f'EARLY_STOP: epoch {epoch}, best_epoch {best_miou_epoch}, '
                f'best_miou {best_miou:.6f}, patience {early_patience}, '
                f'bad_epochs {early_bad_epochs}'
            )
            print(stop_msg)
            logger.info(stop_msg)
            break

        torch.save(
            {
                'epoch': epoch,
                'min_loss': min_loss,
                'min_epoch': min_epoch,
                'best_miou': best_miou,
                'best_miou_epoch': best_miou_epoch,
                'loss': loss,
                'miou': miou,
                'f1_or_dsc': f1_or_dsc,
                'model_state_dict': model.state_dict(),
                'optimizer_state_dict': optimizer.state_dict(),
                'scheduler_state_dict': scheduler.state_dict(),
            },
            os.path.join(checkpoint_dir, 'latest.pth'),
        )

    best_path = None
    if os.path.exists(os.path.join(checkpoint_dir, 'best_miou.pth')):
        best_path = os.path.join(checkpoint_dir, 'best_miou.pth')
    elif os.path.exists(os.path.join(checkpoint_dir, 'best.pth')):
        best_path = os.path.join(checkpoint_dir, 'best.pth')

    if best_path is not None:
        print('#----------Testing----------#')
        best_weight = torch.load(best_path, map_location=torch.device('cpu'))
        model.load_state_dict(best_weight)
        _ = test_one_epoch(valloader, model, criterion, criterion_ce, logger, config)

        if os.path.exists(os.path.join(checkpoint_dir, 'best_miou.pth')):
            os.rename(os.path.join(checkpoint_dir, 'best_miou.pth'),
                      os.path.join(checkpoint_dir, f'best-miou-epoch{best_miou_epoch}-miou{best_miou:.4f}.pth'))
        if os.path.exists(os.path.join(checkpoint_dir, 'best.pth')):
            os.rename(os.path.join(checkpoint_dir, 'best.pth'),
                      os.path.join(checkpoint_dir, f'best-loss-epoch{min_epoch}-loss{min_loss:.4f}.pth'))

if __name__ == '__main__':
    config = setting_config
    main(config)
